# W-Smart Rider — Android starter project

Starter project Android native (Kotlin) using the supplied W-Smart Rider logo. Includes a fading logo splash screen, dashboard concept, BLE scan for nearby Chronos/ESP32/W-Smart devices, GPS speed display, session distance, Google Maps navigation launch, and notification-listener permission entry point.

## Build APK using GitHub (Android Studio is not required)

1. Sign in to GitHub and create a **new repository** (Public or Private).
2. Extract this ZIP on your computer.
3. Open the extracted `wsr_project` folder. Upload the **contents** of that folder to the root of your GitHub repository, including the hidden `.github` folder. Easiest: use GitHub's **Add file → Upload files** page and drag in the project files. If the browser upload doesn't include hidden files/folders, create `.github/workflows/build-apk.yml` in GitHub and paste the workflow from this project.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build W-Smart Rider APK** and, if needed, click **Run workflow**.
6. Wait for the workflow to finish with a green check mark.
7. Open the completed run and download **W-Smart-Rider-debug-APK** from **Artifacts**. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
8. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that source.

The workflow builds a **debug APK**, not a Play Store release. GitHub Actions must be enabled for the repository. The first build can take several minutes.

## Prototype limitations

- This is a starter source project, not a tested/signed release APK. The GitHub workflow has been added, but a successful build has not been verified in this environment.
- BLE scanning is present; persistent GATT connection, Chronos protocol compatibility, notification forwarding, and music commands still need implementation and testing against the exact device firmware.
- ChronosESP32 is ESP32 BLE peripheral firmware, not an Android app, and does not itself provide a Wi-Fi connection. Its UUIDs are Nordic-UART-style service `6e400001-b5a3-f393-e0a9-e50e24dcca9e`, RX `6e400002-b5a3-f393-e0a9-e50e24dcca9e`, TX `6e400003-b5a3-f393-e0a9-e50e24dcca9e`.
- Speed uses Android GPS. Distance shown is per current app session; a persistent odometer needs explicit storage and a reset/calibration policy.
- Weather needs a provider/API key. Turn-by-turn instructions require an integration that exposes navigation notifications/data; opening Google Maps alone does not mirror its instructions into this app.
- Notification access is sensitive and must be explicitly granted by the phone owner in Android Settings.
- The supplied logo is included in the Android resources.
