package com.wsmartrider.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Starter listener: Android requires the user to explicitly grant notification access in Settings. */
class RiderNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // TODO: filter selected apps (e.g. WhatsApp) and forward title/text to the connected rider display.
        // Do not log or store private notification content by default.
    }
}
