package com.wsmartrider.app

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), LocationListener {
    private val blue = Color.rgb(25, 184, 242)
    private val bg = Color.rgb(7, 19, 33)
    private val panel = Color.rgb(14, 35, 55)
    private lateinit var root: LinearLayout
    private lateinit var connectionText: TextView
    private lateinit var speedText: TextView
    private lateinit var distanceText: TextView
    private lateinit var statusText: TextView
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var locationManager: LocationManager? = null
    private var lastLocation: Location? = null
    private var totalKm = 0.0
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        bluetoothAdapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        showSplash()
    }

    private fun showSplash() {
        val splash = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.WHITE) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.wsr_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
        splash.addView(logo, LinearLayout.LayoutParams(-1, 0, 1f))
        val label = TextView(this).apply { text = "W-SMART RIDER"; textSize = 22f; setTextColor(Color.rgb(7, 35, 58)); gravity = Gravity.CENTER; letterSpacing = .12f }
        splash.addView(label, LinearLayout.LayoutParams(-1, 70))
        setContentView(splash)
        splash.alpha = 1f
        splash.postDelayed({
            ObjectAnimator.ofFloat(splash, View.ALPHA, 1f, 0f).apply {
                duration = 850; interpolator = DecelerateInterpolator()
                addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(animation: Animator) { buildDashboard() } })
                start()
            }
        }, 1200)
    }

    private fun buildDashboard() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 18, 18, 16) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        val heading = TextView(this).apply { text = "W-SMART RIDER"; textSize = 25f; setTextColor(Color.WHITE); letterSpacing = .06f; gravity = Gravity.CENTER_VERTICAL }
        content.addView(heading, lp(WRAP, 52))
        val sub = TextView(this).apply { text = "SMART COCKPIT  •  RIDE CONNECTED"; textSize = 11f; setTextColor(blue); letterSpacing = .08f }
        content.addView(sub, lp(WRAP, 30))
        connectionText = TextView(this).apply { text = "●  Bluetooth belum terhubung"; textSize = 14f; setTextColor(Color.LTGRAY) }
        content.addView(card(connectionText), lp(MATCH, 64))
        val connect = button("CARI PERANGKAT BLUETOOTH") { startBleScan() }
        content.addView(connect, lp(MATCH, 52))

        val speedCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(12, 22, 12, 22); background = rounded(panel, 24) }
        val small = TextView(this).apply { text = "KECEPATAN SAAT INI"; textSize = 12f; setTextColor(blue); letterSpacing = .12f }
        speedCard.addView(small)
        speedText = TextView(this).apply { text = "0"; textSize = 76f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, 1) }
        speedCard.addView(speedText)
        speedCard.addView(TextView(this).apply { text = "km/jam  •  berdasarkan GPS"; textSize = 12f; setTextColor(Color.LTGRAY) })
        content.addView(speedCard, lp(MATCH, 210).apply { topMargin = 14; bottomMargin = 12 })

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val odo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 16, 14, 16); background = rounded(panel, 18) }
        odo.addView(TextView(this).apply { text = "JARAK PERJALANAN"; textSize = 10f; setTextColor(blue) })
        distanceText = TextView(this).apply { text = "0.00 km"; textSize = 25f; setTextColor(Color.WHITE); setPadding(0, 10, 0, 4) }
        odo.addView(distanceText)
        odo.addView(TextView(this).apply { text = "Odometer sesi GPS"; textSize = 11f; setTextColor(Color.LTGRAY) })
        stats.addView(odo, LinearLayout.LayoutParams(0, -2, 1f))
        val weather = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 16, 14, 16); background = rounded(panel, 18) }
        weather.addView(TextView(this).apply { text = "CUACA"; textSize = 10f; setTextColor(blue) })
        weather.addView(TextView(this).apply { text = "—°"; textSize = 25f; setTextColor(Color.WHITE); setPadding(0, 10, 0, 4) })
        weather.addView(TextView(this).apply { text = "Perlu API cuaca"; textSize = 11f; setTextColor(Color.LTGRAY) })
        val statLp = LinearLayout.LayoutParams(0, -2, 1f); statLp.marginStart = 10
        stats.addView(weather, statLp)
        content.addView(stats, lp(MATCH, WRAP))

        content.addView(section("FITUR CEPAT"), lp(WRAP, 42))
        content.addView(button("♫   Kontrol musik   •   Sebelumnya / Putar / Berikutnya") { toast("Kontrol musik akan aktif setelah protokol perangkat diintegrasikan") }, lp(MATCH, 50))
        content.addView(button("➤   Navigasi belokan demi belokan") { openMaps() }, lp(MATCH, 50))
        content.addView(button("☁   Cuaca dan lokasi") { openWeatherInfo() }, lp(MATCH, 50))
        content.addView(button("▣   Notifikasi WhatsApp dan aplikasi") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, lp(MATCH, 50))
        statusText = TextView(this).apply { text = "GPS siap diaktifkan. Kecepatan dan jarak hanya dihitung saat izin lokasi diberikan."; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(4, 16, 4, 20) }
        content.addView(statusText, lp(MATCH, WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        requestNeededPermissions()
        startGps()
    }

    private fun startBleScan() {
        val adapter = bluetoothAdapter
        if (adapter == null) { toast("Ponsel ini tidak mendukung Bluetooth"); return }
        if (!adapter.isEnabled) { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 101); return
        }
        if (scanning) return
        scanning = true
        connectionText.text = "●  Mencari perangkat BLE..."
        val scanner = adapter.bluetoothLeScanner ?: run { scanning = false; toast("Bluetooth scanner tidak tersedia"); return }
        try {
            scanner.startScan(object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val name = try { result.device.name } catch (_: SecurityException) { null }
                    if (name != null && (name.contains("Chronos", true) || name.contains("ESP32", true) || name.contains("W-Smart", true))) {
                        runOnUiThread { connectionText.text = "●  Ditemukan: $name  •  ${result.device.address}"; statusText.text = "Perangkat ditemukan. Koneksi GATT dan protokol data perlu diselesaikan untuk sinkronisasi penuh." }
                    }
                }
                override fun onScanFailed(errorCode: Int) { scanning = false; runOnUiThread { connectionText.text = "●  Scan gagal ($errorCode)" } }
            })
            root.postDelayed({ try { scanner.stopScan(object : ScanCallback() {}) } catch (_: Exception) {}; scanning = false; if (connectionText.text.toString().contains("Mencari")) connectionText.text = "●  Perangkat tidak ditemukan — coba lagi" }, 12000)
        } catch (_: SecurityException) { scanning = false; toast("Izinkan akses Bluetooth terlebih dahulu") }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) { needed.add(Manifest.permission.BLUETOOTH_SCAN); needed.add(Manifest.permission.BLUETOOTH_CONNECT) }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) requestPermissions(needed.distinct().toTypedArray(), 100)
    }

    private fun startGps() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, this)
            statusText.text = "GPS aktif — data diperbarui saat lokasi tersedia."
        } catch (e: Exception) { statusText.text = "GPS belum tersedia. Periksa izin dan pengaturan lokasi." }
    }

    override fun onLocationChanged(location: Location) {
        val speed = if (location.hasSpeed()) location.speed * 3.6f else 0f
        speedText.text = String.format(Locale.getDefault(), "%.0f", speed)
        lastLocation?.let { previous ->
            val delta = previous.distanceTo(location)
            if (delta in 2f..1000f) totalKm += delta / 1000.0
        }
        lastLocation = location
        distanceText.text = String.format(Locale.getDefault(), "%.2f km", totalKm)
    }
    @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { if (::statusText.isInitialized) statusText.text = "Aktifkan GPS untuk melihat speedometer." }
    override fun onResume() { super.onResume(); if (::root.isInitialized) startGps() }
    override fun onPause() { super.onPause(); try { locationManager?.removeUpdates(this) } catch (_: Exception) {} }

    private fun openMaps() {
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("google.navigation:q="))
        intent.setPackage("com.google.android.apps.maps")
        try { startActivity(intent) } catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://maps.google.com"))) }
    }
    private fun openWeatherInfo() { toast("Modul cuaca membutuhkan API cuaca dan izin internet.") }
    private fun section(s: String) = TextView(this).apply { text = s; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; letterSpacing = .08f }
    private fun card(view: View) = LinearLayout(this).apply { setPadding(14, 8, 14, 8); gravity = Gravity.CENTER_VERTICAL; background = rounded(panel, 16); addView(view) }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.rgb(17, 54, 78), 14); setOnClickListener { action() } }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); setStroke(1, Color.rgb(27, 79, 106)) }
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    companion object { const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT; const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT }
}
