package com.wsmartrider.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;
import java.util.Locale;

/** Membaca notifikasi HP (WhatsApp, dll) untuk diteruskan ke W-Smart Rider. */
public class NotifService extends NotificationListenerService {
    interface Sink {
        void onNotif(int icon, String title, String text);

        /** Panggilan WhatsApp: ringing = true saat berdering, false saat selesai/diangkat/ditolak. */
        void onWaCall(boolean ringing, boolean video, String name);
    }

    /** Navigasi Google Maps yang dibaca dari notifikasinya (seperti Chronos). */
    static final class GNav {
        String dist = "", directions = "", duration = "", total = "", eta = "";
        byte[] icon;           // 288 byte, boleh null
        long at;
    }

    static volatile GNav gnav;
    static volatile Sink sink;
    static volatile StatusBarNotification waCall;
    static volatile String lastCallTitle = "";
    static volatile boolean waRinging = false;
    static volatile String waRingKey = "";
    static volatile long lastCallTitleAt = 0;

    private final HashMap<String, String> seen = new HashMap<>();

    private static String str(CharSequence s) {
        return s == null ? "" : s.toString();
    }

    static int iconFor(String pkg) {
        switch (pkg) {
            case "com.whatsapp": return 0x0A;
            case "com.whatsapp.w4b": return 0x20;
            case "org.telegram.messenger": return 0x18;
            case "com.instagram.android": return 0x12;
            case "com.facebook.katana": return 0x10;
            case "com.facebook.orca": return 0x11;
            case "com.google.android.gm": return 0x0B;
            case "jp.naver.line.android": return 0x0E;
            case "com.twitter.android": return 0x0F;
            case "com.tencent.mm": return 0x09;
            case "com.viber.voip": return 0x16;
            case "com.skype.raider": return 0x08;
            default: return 0x03;
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception ignored) {
        }
    }

    private void handle(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        String pkg = sbn.getPackageName();
        if (n == null || pkg == null || pkg.equals(getPackageName())) return;
        boolean wa = pkg.equals("com.whatsapp") || pkg.equals("com.whatsapp.w4b");
        boolean isCall = Notification.CATEGORY_CALL.equals(n.category);
        Bundle ex = n.extras;
        if (ex == null) return;
        String title = str(ex.getCharSequence(Notification.EXTRA_TITLE));
        String text = str(ex.getCharSequence(Notification.EXTRA_TEXT));
        if (text.isEmpty()) text = str(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));

        if (pkg.equals("com.google.android.apps.maps") && (n.flags & Notification.FLAG_ONGOING_EVENT) != 0) {
            parseMaps(n, ex, title, text);
            return;
        }

        if (wa) {
            String low = (title + " " + text).toLowerCase(Locale.ROOT);
            boolean missed = low.contains("tidak terjawab") || low.contains("tak terjawab") || low.contains("missed");
            boolean phraseIn = low.contains("telepon suara masuk") || low.contains("telepon video masuk")
                    || low.contains("panggilan suara masuk") || low.contains("panggilan video masuk")
                    || low.contains("incoming voice call") || low.contains("incoming video call");
            boolean hasAnswer = hasAction(n, "(?i).*(answer|jawab|angkat|terima|accept).*");
            boolean hasHangup = hasAction(n, "(?i).*(hang|end call|akhiri|tutup|selesai).*");
            boolean ongoingCall = low.contains("berlangsung") || low.contains("ongoing");
            if (isCall || phraseIn) {
                if (missed) {
                    endWaCall();                       // lanjut: diteruskan sebagai notifikasi "tidak terjawab"
                } else if (ongoingCall || (hasHangup && !hasAnswer)) {
                    endWaCall();                       // panggilan sudah diangkat / sedang berlangsung
                    return;
                } else {
                    waCall = sbn;                      // panggilan masuk: tampilkan layar panggilan di W-Smart Rider
                    ringWa(sbn.getKey(), low.contains("video"), title);
                    return;
                }
            }
        }
        if (isCall && !wa) {
            lastCallTitle = title;
            lastCallTitleAt = System.currentTimeMillis();
            return;
        }
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if (!isCall && (n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;
        if (Notification.CATEGORY_TRANSPORT.equals(n.category)) return;
        if (Notification.CATEGORY_PROGRESS.equals(n.category)) return;
        if (title.isEmpty() && text.isEmpty()) return;

        String key = sbn.getKey();
        String sig = title + "|" + text;
        synchronized (seen) {
            if (sig.equals(seen.get(key))) return;
            if (seen.size() > 200) seen.clear();
            seen.put(key, sig);
        }
        Sink s = sink;
        if (s != null) s.onNotif(iconFor(pkg), title, text);
    }

    private static final java.util.regex.Pattern DIST = java.util.regex.Pattern.compile(
            "^\\s*\\d+([.,]\\d+)?\\s*(m|km|meter|kilometer|ft|feet|mi|mile|miles|yd)\\b.*",
            java.util.regex.Pattern.CASE_INSENSITIVE);
    private static final java.util.regex.Pattern CLOCK = java.util.regex.Pattern.compile("\\d{1,2}[:.]\\d{2}");

    private static boolean isDist(String s) {
        return DIST.matcher(s).matches();
    }

    private void parseMaps(Notification n, Bundle ex, String title, String text) {
        String sub = str(ex.getCharSequence(Notification.EXTRA_SUB_TEXT));
        String info = str(ex.getCharSequence(Notification.EXTRA_INFO_TEXT));
        GNav g = new GNav();
        String t = title.trim(), x = text.trim();

        // jarak ke belokan & instruksi bisa ada di judul atau teks
        if (isDist(t) && !isDist(x)) {
            g.dist = t;
            g.directions = x;
        } else if (isDist(x) && !isDist(t)) {
            g.dist = x;
            g.directions = t;
        } else if (isDist(t)) {
            String[] parts = t.split("\\s[\\u00B7\\u2022\\-]\\s", 2);
            g.dist = parts[0];
            g.directions = parts.length > 1 ? parts[1] : x;
        } else {
            g.dist = "";
            g.directions = t.isEmpty() ? x : t;
        }

        // ringkasan perjalanan: durasi, jarak total, jam tiba
        String all = sub.isEmpty() ? (info.isEmpty() ? x : info) : sub;
        for (String tok : all.split("\\s*[\\u00B7\\u2022|]\\s*")) {
            String k = tok.trim();
            if (k.isEmpty()) continue;
            if (CLOCK.matcher(k).find() && !k.toLowerCase().contains("km")) g.eta = k;
            else if (isDist(k)) g.total = k;
            else if (k.matches("(?i).*\\d.*(mnt|min|menit|jam|hr|h|detik).*")) g.duration = k;
        }

        // ikon panah dari notifikasi
        try {
            Bitmap bmp = null;
            Icon ic = n.getLargeIcon();
            if (ic != null) {
                Drawable d = ic.loadDrawable(this);
                if (d != null) {
                    Bitmap b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
                    Canvas cv = new Canvas(b);
                    d.setBounds(0, 0, 96, 96);
                    d.draw(cv);
                    bmp = b;
                }
            }
            if (bmp == null) {
                Object o = ex.get(Notification.EXTRA_LARGE_ICON);
                if (o instanceof Bitmap) bmp = (Bitmap) o;
            }
            g.icon = NavIcon.fromBitmap(bmp);
        } catch (Exception ignored) {
        }

        g.at = System.currentTimeMillis();
        if (g.dist.isEmpty() && g.directions.isEmpty()) return;
        gnav = g;
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn != null && "com.google.android.apps.maps".equals(sbn.getPackageName())
                && (sbn.getNotification().flags & Notification.FLAG_ONGOING_EVENT) != 0) {
            gnav = null;
        }
        StatusBarNotification w = waCall;
        if (w != null && sbn != null && w.getKey().equals(sbn.getKey())) endWaCall();
    }

    private static boolean hasAction(Notification n, String re) {
        Notification.Action[] acts = n.actions;
        if (acts == null) return false;
        for (Notification.Action a : acts) {
            CharSequence t = a.title;
            if (t != null && t.toString().matches(re)) return true;
        }
        return false;
    }

    private static void ringWa(String key, boolean video, String name) {
        if (waRinging && key.equals(waRingKey)) return;      // pembaruan dari notifikasi yang sama
        waRinging = true;
        waRingKey = key;
        Sink s = sink;
        if (s != null) s.onWaCall(true, video, name);
    }

    private static void endWaCall() {
        waCall = null;
        if (!waRinging) return;
        waRinging = false;
        waRingKey = "";
        Sink s = sink;
        if (s != null) s.onWaCall(false, false, "");
    }

    /** Tekan tombol Jawab / Tolak pada notifikasi panggilan WhatsApp. */
    static boolean actWaCall(boolean answer) {
        StatusBarNotification w = waCall;
        if (w == null) return false;
        Notification.Action[] acts = w.getNotification().actions;
        if (acts == null) return false;
        String re = answer
                ? "(?i).*(answer|jawab|angkat|terima|accept).*"
                : "(?i).*(decline|tolak|reject|abaikan|hang|tutup|dismiss).*";
        for (Notification.Action a : acts) {
            CharSequence t = a.title;
            if (t != null && a.actionIntent != null && t.toString().matches(re)) {
                try {
                    a.actionIntent.send();
                    return true;
                } catch (PendingIntent.CanceledException ignored) {
                }
            }
        }
        return false;
    }
}
