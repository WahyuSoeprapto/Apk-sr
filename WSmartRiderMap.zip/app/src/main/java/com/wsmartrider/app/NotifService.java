package com.wsmartrider.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;

/** Membaca notifikasi HP (WhatsApp, dll) untuk diteruskan ke W-Smart Rider. */
public class NotifService extends NotificationListenerService {
    interface Sink {
        void onNotif(int icon, String title, String text);
    }

    static volatile Sink sink;
    static volatile StatusBarNotification waCall;
    static volatile String lastCallTitle = "";
    static volatile long lastCallTitleAt = 0;

    private final HashMap<String, String> seen = new HashMap<>();

    private static String str(CharSequence s) {
        return s == null ? "" : s.toString();
    }

    static int iconFor(String pkg) {
        switch (pkg) {
            case "com.whatsapp": return 0x0A;
            case "com.whatsapp.w4b": return 0x20;
            case "org.telegram.messenger": return 0x18;
            case "com.instagram.android": return 0x12;
            case "com.facebook.katana": return 0x10;
            case "com.facebook.orca": return 0x11;
            case "com.google.android.gm": return 0x0B;
            case "jp.naver.line.android": return 0x0E;
            case "com.twitter.android": return 0x0F;
            case "com.tencent.mm": return 0x09;
            case "com.viber.voip": return 0x16;
            case "com.skype.raider": return 0x08;
            default: return 0x03;
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception ignored) {
        }
    }

    private void handle(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        String pkg = sbn.getPackageName();
        if (n == null || pkg == null || pkg.equals(getPackageName())) return;
        boolean wa = pkg.equals("com.whatsapp") || pkg.equals("com.whatsapp.w4b");
        boolean isCall = Notification.CATEGORY_CALL.equals(n.category);
        Bundle ex = n.extras;
        if (ex == null) return;
        String title = str(ex.getCharSequence(Notification.EXTRA_TITLE));
        String text = str(ex.getCharSequence(Notification.EXTRA_TEXT));
        if (text.isEmpty()) text = str(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));

        if (isCall && wa) waCall = sbn;
        if (isCall && !wa) {
            lastCallTitle = title;
            lastCallTitleAt = System.currentTimeMillis();
            return;
        }
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if (!isCall && (n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;
        if (Notification.CATEGORY_TRANSPORT.equals(n.category)) return;
        if (Notification.CATEGORY_PROGRESS.equals(n.category)) return;
        if (title.isEmpty() && text.isEmpty()) return;

        String key = sbn.getKey();
        String sig = title + "|" + text;
        synchronized (seen) {
            if (sig.equals(seen.get(key))) return;
            if (seen.size() > 200) seen.clear();
            seen.put(key, sig);
        }
        Sink s = sink;
        if (s != null) s.onNotif(iconFor(pkg), title, text);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        StatusBarNotification w = waCall;
        if (w != null && sbn != null && w.getKey().equals(sbn.getKey())) waCall = null;
    }

    /** Tekan tombol Jawab / Tolak pada notifikasi panggilan WhatsApp. */
    static boolean actWaCall(boolean answer) {
        StatusBarNotification w = waCall;
        if (w == null) return false;
        Notification.Action[] acts = w.getNotification().actions;
        if (acts == null) return false;
        String re = answer
                ? "(?i).*(answer|jawab|angkat|terima|accept).*"
                : "(?i).*(decline|tolak|reject|abaikan|hang|tutup|dismiss).*";
        for (Notification.Action a : acts) {
            CharSequence t = a.title;
            if (t != null && a.actionIntent != null && t.toString().matches(re)) {
                try {
                    a.actionIntent.send();
                    return true;
                } catch (PendingIntent.CanceledException ignored) {
                }
            }
        }
        return false;
    }
}
