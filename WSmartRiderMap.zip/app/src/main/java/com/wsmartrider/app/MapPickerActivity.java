package com.wsmartrider.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;

/** Peta untuk memilih titik tujuan (OpenStreetMap lewat Leaflet di WebView). */
public class MapPickerActivity extends Activity {
    private double pLat = Double.NaN, pLon = Double.NaN;
    private TextView tv;
    private Button ok;

    private class Bridge {
        @JavascriptInterface
        public void pick(final double la, final double lo) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pLat = la;
                    pLon = lo;
                    tv.setText(String.format(Locale.US, "Titik: %.5f, %.5f", la, lo));
                    ok.setEnabled(true);
                }
            });
        }
    }

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "<html><body>Gagal memuat peta</body></html>";
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        double la = in.getDoubleExtra("lat", -6.2);
        double lo = in.getDoubleExtra("lon", 106.8);
        boolean has = in.getBooleanExtra("has", false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        WebView wv = new WebView(this);
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        wv.setWebChromeClient(new WebChromeClient());
        wv.addJavascriptInterface(new Bridge(), "Android");
        root.addView(wv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        tv = new TextView(this);
        tv.setText("Ketuk peta untuk memilih titik tujuan");
        tv.setPadding(24, 16, 24, 8);
        root.addView(tv);

        ok = new Button(this);
        ok.setText("Pilih titik ini");
        ok.setEnabled(false);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent r = new Intent();
                r.putExtra("lat", pLat);
                r.putExtra("lon", pLon);
                setResult(RESULT_OK, r);
                finish();
            }
        });
        root.addView(ok);

        setContentView(root);

        String html = readAsset("picker.html")
                .replace("__LAT__", String.valueOf(la))
                .replace("__LON__", String.valueOf(lo))
                .replace("__HAS__", has ? "true" : "false");
        wv.loadDataWithBaseURL("https://wsmartrider.local/", html, "text/html", "UTF-8", null);
    }
}
