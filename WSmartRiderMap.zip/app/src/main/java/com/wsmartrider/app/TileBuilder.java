package com.wsmartrider.app;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Mengubah aliran jalan/air/taman/SPBU (dari berkas peta) menjadi petak cache RoadCache.
 * Tahap 1 (add*): tiap fitur dipecah per petak dan ditulis ke berkas sementara per baris lintang (hemat memori).
 * Tahap 2 (finish): tiap baris dibaca ulang, dikelompokkan per petak, lalu disimpan sebagai petak cache.
 */
final class TileBuilder {
    static final int MAJOR = 0, MINOR = 1, ALLEY = 2, WATER = 3, PARK = 4, STREAM = 5, FUEL = 6;

    interface Progress {
        void on(int done, int total);
    }

    private final File dir;
    private final HashMap<Integer, DataOutputStream> bands = new HashMap<>();
    double obsMinLa = 1e9, obsMinLo = 1e9, obsMaxLa = -1e9, obsMaxLo = -1e9;   // sebaran data yang terlihat
    long records = 0;

    TileBuilder(File spillDir) {
        dir = spillDir;
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();
    }

    private DataOutputStream band(int ix) throws Exception {
        DataOutputStream o = bands.get(ix);
        if (o == null) {
            o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File(dir, "band_" + ix + ".tmp")), 1 << 16));
            bands.put(ix, o);
        }
        return o;
    }

    private void write(int kind, int tx, int ty, double[] p, int s, int e) throws Exception {
        int m = Math.min(65535, e - s + 1);
        if (m < 2) return;
        DataOutputStream o = band(tx);
        double la0 = tx * Geo.TILE, lo0 = ty * Geo.TILE;
        o.writeByte(kind);
        o.writeInt(tx);
        o.writeInt(ty);
        o.writeShort(m);
        for (int i = 0; i < m; i++) {
            o.writeFloat((float) (p[2 * (s + i)] - la0));
            o.writeFloat((float) (p[2 * (s + i) + 1] - lo0));
        }
        records++;
    }

    private void seen(double la, double lo) {
        if (la < obsMinLa) obsMinLa = la;
        if (la > obsMaxLa) obsMaxLa = la;
        if (lo < obsMinLo) obsMinLo = lo;
        if (lo > obsMaxLo) obsMaxLo = lo;
    }

    /** Garis (jalan, sungai): dipotong per petak; tiap potongan menyertakan 1 titik tetangga agar tersambung. */
    void addLine(int kind, double[] p) throws Exception {
        int n = p.length / 2;
        if (n < 2) return;
        seen(p[0], p[1]);
        seen(p[2 * n - 2], p[2 * n - 1]);
        int i = 0;
        while (i < n) {
            int tx = Geo_tile(p[2 * i]), ty = Geo_tile(p[2 * i + 1]);
            int j = i;
            while (j + 1 < n && Geo_tile(p[2 * (j + 1)]) == tx && Geo_tile(p[2 * (j + 1) + 1]) == ty) j++;
            write(kind, tx, ty, p, Math.max(0, i - 1), Math.min(n - 1, j + 1));
            i = j + 1;
        }
    }

    /** Area tertutup (air, taman): cincin utuh disimpan di setiap petak yang disentuh. */
    void addRing(int kind, double[] p) throws Exception {
        int n = p.length / 2;
        if (n < 4 || n > 65535) return;
        HashSet<Long> tiles = new HashSet<>();
        for (int i = 0; i < n; i++) {
            int tx = Geo_tile(p[2 * i]), ty = Geo_tile(p[2 * i + 1]);
            if (tiles.add(((long) tx << 32) ^ (ty & 0xffffffffL)) && tiles.size() > 200) return;   // terlalu besar: lewati
        }
        for (long k : tiles) write(kind, (int) (k >> 32), (int) k, p, 0, n - 1);
    }

    void addFuel(double la, double lo, String name) throws Exception {
        int tx = Geo_tile(la), ty = Geo_tile(lo);
        DataOutputStream o = band(tx);
        o.writeByte(FUEL);
        o.writeInt(tx);
        o.writeInt(ty);
        o.writeDouble(la);
        o.writeDouble(lo);
        o.writeUTF(name == null || name.isEmpty() ? "SPBU" : name);
        records++;
    }

    private static int Geo_tile(double deg) {
        return (int) Math.floor(deg / Geo.TILE);
    }

    /** Tahap 2. Hanya petak yang SELURUHNYA berada di dalam kotak (minLa..maxLa, minLo..maxLo) yang disimpan
     *  (termasuk yang kosong, mis. laut), agar tidak ada petak setengah jadi yang dianggap lengkap. Mengembalikan jumlah petak. */
    int finish(double minLa, double minLo, double maxLa, double maxLo, Progress pr) throws Exception {
        for (DataOutputStream o : bands.values()) o.close();
        int x0 = Geo_tile(minLa), x1 = Geo_tile(maxLa), y0 = Geo_tile(minLo), y1 = Geo_tile(maxLo);
        int saved = 0, done = 0, total = x1 - x0 + 1;
        final double eps = 1e-9;
        for (int ix = x0; ix <= x1; ix++, done++) {
            if (pr != null) pr.on(done, total);
            File f = new File(dir, "band_" + ix + ".tmp");
            boolean rowIn = ix * Geo.TILE >= minLa - eps && (ix + 1) * Geo.TILE <= maxLa + eps;
            if (!rowIn) {
                f.delete();
                continue;
            }
            HashMap<Integer, RoadSet[]> tiles = new HashMap<>();
            if (f.exists()) readBand(f, tiles);
            f.delete();
            for (int iy = y0; iy <= y1; iy++) {
                boolean colIn = iy * Geo.TILE >= minLo - eps && (iy + 1) * Geo.TILE <= maxLo + eps;
                if (!colIn) continue;
                RoadSet[] t = tiles.get(iy);
                RoadSet base = t != null ? t[0] : new RoadSet();
                RoadSet alley = t != null ? t[1] : new RoadSet();
                RoadCache.importTile(false, ix, iy, base);
                RoadCache.importTile(true, ix, iy, alley);
                saved++;
            }
        }
        RoadCache.bump();
        return saved;
    }

    private static void readBand(File f, Map<Integer, RoadSet[]> tiles) throws Exception {
        DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f), 1 << 16));
        try {
            while (true) {
                int kind = in.readUnsignedByte();
                int tx = in.readInt(), ty = in.readInt();
                RoadSet[] t = tiles.get(ty);
                if (t == null) {
                    t = new RoadSet[]{new RoadSet(), new RoadSet()};
                    tiles.put(ty, t);
                }
                if (kind == FUEL) {
                    double la = in.readDouble(), lo = in.readDouble();
                    t[0].fuel.add(new String[]{String.valueOf(la), String.valueOf(lo), in.readUTF()});
                    continue;
                }
                int m = in.readUnsignedShort();
                double la0 = tx * Geo.TILE, lo0 = ty * Geo.TILE;
                double[] w = new double[m * 2];
                for (int k = 0; k < m; k++) {
                    w[2 * k] = la0 + in.readFloat();
                    w[2 * k + 1] = lo0 + in.readFloat();
                }
                switch (kind) {
                    case MAJOR: t[0].major.add(w); break;
                    case MINOR: t[0].minor.add(w); break;
                    case ALLEY: t[1].alley.add(w); break;
                    case WATER: t[0].water.add(w); break;
                    case PARK: t[0].park.add(w); break;
                    case STREAM: t[0].stream.add(w); break;
                    default: break;
                }
            }
        } catch (EOFException end) {
            // selesai
        } finally {
            in.close();
        }
    }
}
