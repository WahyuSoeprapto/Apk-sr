package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Menjaga unduhan peta area / impor berkas peta tetap berjalan walau aplikasi ditutup atau layar mati.
 * Menampilkan notifikasi progres dengan tombol "Berhenti", dan berhenti sendiri bila pekerjaan selesai.
 */
public class MapDlService extends Service {
    private static final int NID = 2;
    private static volatile boolean up = false;
    private PowerManager.WakeLock wl;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, MapDlService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            RoadCache.stopPrefetch();
            GpkgImport.cancel = true;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (up) return START_NOT_STICKY;
        up = true;
        final NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("mapdl", "Unduhan peta", NotificationManager.IMPORTANCE_LOW));
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, notif("Menyiapkan unduhan peta...", 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NID, notif("Menyiapkan unduhan peta...", 0, true));
            }
        } catch (Throwable e) {
            up = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wsr:mapdl");
            wl.acquire(6L * 60 * 60 * 1000);
        } catch (Throwable ignored) {
        }
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                monitor(nm);
            }
        }, "mapdl-monitor");
        t.setDaemon(true);
        t.start();
        return START_NOT_STICKY;
    }

    private void monitor(NotificationManager nm) {
        String last = "";
        int idle = 0;
        while (true) {
            boolean imp = GpkgImport.running;
            boolean pf = RoadCache.pfActive && !RoadCache.pfFinished();
            if (!imp && !pf) {
                if (++idle >= 2) break;                       // beri kesempatan 2 siklus (pekerjaan baru saja dimulai)
            } else {
                idle = 0;
            }
            String text;
            int pct;
            if (imp) {
                text = GpkgImport.status;
                pct = GpkgImport.percent;
            } else {
                pct = RoadCache.pfPercent();
                text = "Area " + pct + "% - berhasil " + RoadCache.pfDone.get() + " dari " + RoadCache.pfTotal
                        + ", gagal " + RoadCache.pfFail.get();
            }
            if (!text.equals(last)) {
                last = text;
                try {
                    nm.notify(NID, notif(text, pct, true));
                } catch (Throwable ignored) {
                }
            }
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                break;
            }
        }
        String fin;
        if (GpkgImport.error != null) fin = "Impor gagal: " + GpkgImport.error;
        else if (RoadCache.pfFinished()) fin = "Unduhan peta selesai. Berhasil " + RoadCache.pfDone.get() + ", gagal " + RoadCache.pfFail.get() + ".";
        else fin = "Unduhan peta berhenti. Yang sudah terunduh tetap tersimpan.";
        try {
            stopForeground(false);
            nm.notify(NID, notif(fin, 100, false));
        } catch (Throwable ignored) {
        }
        stopSelf();
    }

    private Notification notif(String text, int pct, boolean ongoing) {
        Intent stop = new Intent(this, MapDlService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "mapdl") : new Notification.Builder(this);
        b.setContentTitle("Peta W-Smart Rider")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true);
        if (ongoing) {
            b.setProgress(100, Math.max(0, Math.min(100, pct)), false);
            b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi);
        }
        return b.build();
    }

    @Override
    public void onDestroy() {
        up = false;
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }
}
