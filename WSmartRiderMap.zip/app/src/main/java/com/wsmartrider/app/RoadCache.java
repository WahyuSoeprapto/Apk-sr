package com.wsmartrider.app;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Peta offline per petak (tile) 0,02 derajat (~2,2 km), disimpan di memori HP.
 * - Petak yang sudah pernah diunduh langsung tampil (dibaca dari file, tanpa internet).
 * - Petak baru diunduh PARALEL lewat 3 server Overpass sekaligus, petak di bawah posisi diunduh paling dulu.
 * - Jalan utama dulu (cepat), gang & jalan setapak menyusul.
 * - Bisa mengunduh seluruh area (mis. satu Jakarta) di latar belakang, sekali saja.
 */
final class RoadCache {
    private static final int MAGIC = 0x57534D32;
    private static final int WORKERS = 3;
    private static final double VIEW_MAJOR_M = 2500.0;     // jalan yang dikirim ke renderer: radius dari posisi
    private static final double VIEW_ALLEY_M = 1200.0;

    // jenis tugas
    private static final int BASE = 0, ALLEY = 1;

    private static final class Task implements Comparable<Task> {
        final int ix, iy, kind;
        final double prio;
        final long seq;
        final boolean prefetch;
        int tries;

        Task(int ix, int iy, int kind, double prio, long seq, boolean prefetch) {
            this.ix = ix;
            this.iy = iy;
            this.kind = kind;
            this.prio = prio;
            this.seq = seq;
            this.prefetch = prefetch;
        }

        @Override
        public int compareTo(Task o) {
            if (prio != o.prio) return prio < o.prio ? -1 : 1;
            return seq < o.seq ? -1 : (seq > o.seq ? 1 : 0);
        }
    }

    private static File dir;
    private static boolean started = false;
    private static final PriorityBlockingQueue<Task> queue = new PriorityBlockingQueue<>();
    private static final Map<String, Boolean> pending = new ConcurrentHashMap<>();   // tugas yang sudah antre / berjalan
    private static final Map<String, Long> failAt = new ConcurrentHashMap<>();
    private static final AtomicInteger seq = new AtomicInteger();
    private static final AtomicInteger version = new AtomicInteger();
    private static final AtomicInteger running = new AtomicInteger();

    // progres unduh area besar
    static volatile int pfTotal = 0;
    static final AtomicInteger pfDone = new AtomicInteger();
    static volatile boolean pfActive = false;

    // cache memori (maks 40 petak)
    private static final LinkedHashMap<String, RoadSet> mem = new LinkedHashMap<String, RoadSet>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, RoadSet> e) {
            return size() > 40;
        }
    };

    // tampilan gabungan di sekitar posisi
    private static RoadSet lastView = null;
    private static int lastViewVer = -1;
    private static double lastLa = 0, lastLo = 0;
    private static long lastWant = 0;
    private static int lastWantIx = Integer.MIN_VALUE, lastWantIy = Integer.MIN_VALUE;

    private RoadCache() {
    }

    static synchronized void init(File filesDir) {
        if (started) return;
        dir = new File(filesDir, "tiles");
        dir.mkdirs();
        started = true;
        for (int i = 0; i < WORKERS; i++) {
            final int id = i;
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    work(id);
                }
            }, "road-dl-" + i);
            t.setDaemon(true);
            t.start();
        }
    }

    // ---------------------------------------------------------------- util

    private static String key(int kind, int ix, int iy) {
        return (kind == BASE ? "b_" : "a_") + ix + "_" + iy;
    }

    private static File file(int kind, int ix, int iy) {
        return new File(dir, key(kind, ix, iy) + ".bin");
    }

    static int tileOf(double deg) {
        return (int) Math.floor(deg / Geo.TILE);
    }

    private static boolean have(int kind, int ix, int iy) {
        return file(kind, ix, iy).exists();
    }

    private static void enqueue(int kind, int ix, int iy, double prio, boolean prefetch) {
        String k = key(kind, ix, iy);
        if (have(kind, ix, iy)) return;
        Long fa = failAt.get(k);
        if (fa != null && System.currentTimeMillis() - fa < 30000L) return;
        if (pending.put(k, Boolean.TRUE) != null) return;
        queue.add(new Task(ix, iy, kind, prio, seq.incrementAndGet(), prefetch));
    }

    // ---------------------------------------------------------------- unduh

    private static void work(int id) {
        while (true) {
            Task t;
            try {
                t = queue.take();
            } catch (InterruptedException e) {
                return;
            }
            String k = key(t.kind, t.ix, t.iy);
            running.incrementAndGet();
            boolean ok = false;
            try {
                if (have(t.kind, t.ix, t.iy)) {
                    ok = true;
                } else {
                    RoadSet rs = Geo.fetchTile(t.ix, t.iy, t.kind == ALLEY, id);
                    save(t.kind, t.ix, t.iy, rs);
                    ok = true;
                    version.incrementAndGet();
                }
            } catch (Exception e) {
                ok = false;
            } finally {
                running.decrementAndGet();
            }
            if (ok) {
                failAt.remove(k);
                pending.remove(k);
                if (t.prefetch) pfDone.incrementAndGet();
            } else if (++t.tries < 3) {
                try {
                    Thread.sleep(1500L * t.tries);              // beri napas server, lalu coba lagi
                } catch (InterruptedException ignored) {
                }
                queue.add(t);                                    // tetap 'pending'
            } else {
                failAt.put(k, System.currentTimeMillis());
                pending.remove(k);
                if (t.prefetch) pfDone.incrementAndGet();
            }
            if (t.prefetch) {
                try {
                    Thread.sleep(600L);                          // unduhan massal: sopan ke server
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    /** Minta petak di sekitar posisi (dipanggil tiap siklus; murah). Petak di bawah posisi paling diutamakan. */
    static void want(double la, double lo) {
        if (!started) return;
        int cx = tileOf(la), cy = tileOf(lo);
        long now = System.currentTimeMillis();
        if (cx == lastWantIx && cy == lastWantIy && now - lastWant < 20000L) return;
        lastWantIx = cx;
        lastWantIy = cy;
        lastWant = now;
        // cincin 0: petak sendiri; cincin 1: 8 tetangga; cincin 2: 16 petak luar
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                int ring = Math.max(Math.abs(dx), Math.abs(dy));
                double base = ring == 0 ? 0 : (ring == 1 ? 1 : 4);
                enqueue(BASE, cx + dx, cy + dy, base + (Math.abs(dx) + Math.abs(dy)) * 0.01, false);
                enqueue(ALLEY, cx + dx, cy + dy, base + 2 + (Math.abs(dx) + Math.abs(dy)) * 0.01, false);
            }
        }
    }

    /** Unduh seluruh area (mis. satu Jakarta) di latar belakang, dimulai dari yang terdekat dengan posisi. */
    static void prefetch(double minLa, double minLo, double maxLa, double maxLo, double nearLa, double nearLo) {
        if (!started) return;
        int x0 = tileOf(minLa), x1 = tileOf(maxLa), y0 = tileOf(minLo), y1 = tileOf(maxLo);
        int cx = tileOf(nearLa), cy = tileOf(nearLo);
        ArrayList<int[]> tiles = new ArrayList<>();
        for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) tiles.add(new int[]{x, y});
        final int fx = cx, fy = cy;
        Collections.sort(tiles, new java.util.Comparator<int[]>() {
            @Override
            public int compare(int[] a, int[] b) {
                long da = (long) (a[0] - fx) * (a[0] - fx) + (long) (a[1] - fy) * (a[1] - fy);
                long db = (long) (b[0] - fx) * (b[0] - fx) + (long) (b[1] - fy) * (b[1] - fy);
                return Long.compare(da, db);
            }
        });
        int total = 0, done = 0;
        for (int i = 0; i < tiles.size(); i++) {
            int[] t = tiles.get(i);
            // jalan utama seluruh area dulu (prioritas 10..), gang menyusul (prioritas 20..)
            total += 2;
            if (have(BASE, t[0], t[1])) done++;
            else enqueue(BASE, t[0], t[1], 10 + i * 0.001, true);
            if (have(ALLEY, t[0], t[1])) done++;
            else enqueue(ALLEY, t[0], t[1], 20 + i * 0.001, true);
        }
        pfTotal = total;
        pfDone.set(done);
        pfActive = true;
    }

    /** Unduh area persegi di sekitar satu titik (radius dalam km). Mengembalikan jumlah petak. */
    static int prefetchRadius(double la, double lo, double km) {
        double dLa = km / 110.54, dLo = km / (111.32 * Math.cos(Math.toRadians(la)));
        prefetch(la - dLa, lo - dLo, la + dLa, lo + dLo, la, lo);
        return pfTotal / 2;
    }

    private static Object routeKey = null;

    /** Unduh petak di sepanjang rute (plus 1 petak tetangga di kiri-kanan), diurutkan dari posisi awal rute. */
    static void wantRoute(Object key, double[] lat, double[] lon) {
        if (!started || key == routeKey || lat == null || lat.length == 0) return;
        routeKey = key;
        java.util.LinkedHashSet<Long> seen = new java.util.LinkedHashSet<>();
        ArrayList<int[]> order = new ArrayList<>();
        for (int i = 0; i < lat.length; i++) {
            int x = tileOf(lat[i]), y = tileOf(lon[i]);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    long k = ((long) (x + dx) << 32) ^ ((y + dy) & 0xffffffffL);
                    if (seen.add(k)) order.add(new int[]{x + dx, y + dy});
                }
            }
            if (order.size() > 600) break;                       // batas wajar untuk rute sangat panjang
        }
        for (int i = 0; i < order.size(); i++) {
            int[] t = order.get(i);
            enqueue(BASE, t[0], t[1], 5 + i * 0.001, false);       // jalan utama sepanjang rute dulu
            enqueue(ALLEY, t[0], t[1], 15 + i * 0.001, false);     // gang menyusul
        }
    }

    /** Hentikan unduhan massal (petak yang sudah selesai tetap tersimpan). */
    static void stopPrefetch() {
        pfActive = false;
        ArrayList<Task> keep = new ArrayList<>();
        Task t;
        while ((t = queue.poll()) != null) {
            if (t.prefetch) pending.remove(key(t.kind, t.ix, t.iy));
            else keep.add(t);
        }
        queue.addAll(keep);
    }

    /** Berapa persen area besar yang sudah terunduh (0..100). */
    static int pfPercent() {
        int tot = pfTotal;
        if (tot <= 0) return 0;
        return Math.min(100, pfDone.get() * 100 / tot);
    }

    static boolean pfFinished() {
        return pfTotal > 0 && pfDone.get() >= pfTotal;
    }

    /** Petak jalan di bawah posisi sudah siap? */
    static boolean ready(double la, double lo) {
        return started && have(BASE, tileOf(la), tileOf(lo));
    }

    static int busyCount() {
        return pending.size();
    }

    static int sizeMb() {
        long sum = 0;
        File[] fs = dir == null ? null : dir.listFiles();
        if (fs != null) for (File f : fs) sum += f.length();
        return (int) (sum / (1024 * 1024));
    }

    static int tileCount() {
        File[] fs = dir == null ? null : dir.listFiles();
        return fs == null ? 0 : fs.length;
    }

    static void clear() {
        stopPrefetch();
        File[] fs = dir == null ? null : dir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        synchronized (mem) {
            mem.clear();
        }
        version.incrementAndGet();
    }

    // ---------------------------------------------------------------- tampilan gabungan

    /** Jalan di sekitar posisi, digabung dari petak yang sudah ada. Hasil di-cache sampai posisi bergeser > 300 m
     *  atau ada petak baru. Aman dipanggil tiap siklus. */
    static synchronized RoadSet view(double la, double lo) {
        if (!started) return null;
        int ver = version.get();
        if (lastView != null && ver == lastViewVer && dist(la, lo, lastLa, lastLo) < 300.0) return lastView;

        int cx = tileOf(la), cy = tileOf(lo);
        RoadSet out = new RoadSet();
        out.cLat = la;
        out.cLon = lo;
        double kx = 111320.0 * Math.cos(Math.toRadians(la)), ky = 110540.0;
        boolean any = false;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                RoadSet b = load(BASE, cx + dx, cy + dy);
                if (b != null) {
                    any = true;
                    addNear(out.major, b.major, la, lo, kx, ky, VIEW_MAJOR_M);
                    addNear(out.minor, b.minor, la, lo, kx, ky, VIEW_MAJOR_M);
                    addNear(out.water, b.water, la, lo, kx, ky, VIEW_MAJOR_M);
                    addNear(out.park, b.park, la, lo, kx, ky, VIEW_MAJOR_M);
                    addNear(out.stream, b.stream, la, lo, kx, ky, VIEW_MAJOR_M);
                    out.fuel.addAll(b.fuel);
                }
                RoadSet a = load(ALLEY, cx + dx, cy + dy);
                if (a != null) addNear(out.alley, a.alley, la, lo, kx, ky, VIEW_ALLEY_M);
            }
        }
        lastLa = la;
        lastLo = lo;
        lastViewVer = ver;
        lastView = any ? out : null;
        return lastView;
    }

    private static void addNear(List<double[]> dst, List<double[]> src, double la, double lo, double kx, double ky, double r) {
        for (double[] w : src) {
            for (int i = 0; i + 1 < w.length; i += 2) {
                if (Math.abs((w[i + 1] - lo) * kx) < r && Math.abs((w[i] - la) * ky) < r) {
                    dst.add(w);
                    break;
                }
            }
        }
    }

    private static double dist(double la1, double lo1, double la2, double lo2) {
        double dx = (lo1 - lo2) * 111320.0 * Math.cos(Math.toRadians(la1)), dy = (la1 - la2) * 110540.0;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // ---------------------------------------------------------------- file biner

    private static RoadSet load(int kind, int ix, int iy) {
        String k = key(kind, ix, iy);
        synchronized (mem) {
            RoadSet m = mem.get(k);
            if (m != null) return m;
        }
        File f = file(kind, ix, iy);
        if (!f.exists()) return null;
        DataInputStream in = null;
        try {
            in = new DataInputStream(new BufferedInputStream(new FileInputStream(f), 1 << 16));
            if (in.readInt() != MAGIC) throw new Exception("bad");
            RoadSet rs = new RoadSet();
            double la0 = ix * Geo.TILE, lo0 = iy * Geo.TILE;
            rs.cLat = la0;
            rs.cLon = lo0;
            readList(in, rs.major, la0, lo0);
            readList(in, rs.minor, la0, lo0);
            readList(in, rs.alley, la0, lo0);
            readList(in, rs.water, la0, lo0);
            readList(in, rs.park, la0, lo0);
            readList(in, rs.stream, la0, lo0);
            int nf = in.readInt();
            for (int i = 0; i < nf; i++) {
                double fla = in.readDouble(), flo = in.readDouble();
                String nm = in.readUTF();
                rs.fuel.add(new String[]{String.valueOf(fla), String.valueOf(flo), nm});
            }
            synchronized (mem) {
                mem.put(k, rs);
            }
            return rs;
        } catch (Exception e) {
            f.delete();                                         // file rusak: unduh ulang
            return null;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static void save(int kind, int ix, int iy, RoadSet rs) throws Exception {
        File tmp = new File(dir, key(kind, ix, iy) + ".tmp");
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp), 1 << 16));
        try {
            double la0 = ix * Geo.TILE, lo0 = iy * Geo.TILE;
            out.writeInt(MAGIC);
            writeList(out, rs.major, la0, lo0);
            writeList(out, rs.minor, la0, lo0);
            writeList(out, rs.alley, la0, lo0);
            writeList(out, rs.water, la0, lo0);
            writeList(out, rs.park, la0, lo0);
            writeList(out, rs.stream, la0, lo0);
            out.writeInt(rs.fuel.size());
            for (String[] f : rs.fuel) {
                out.writeDouble(Double.parseDouble(f[0]));
                out.writeDouble(Double.parseDouble(f[1]));
                out.writeUTF(f[2]);
            }
        } finally {
            out.close();
        }
        if (!tmp.renameTo(file(kind, ix, iy))) {
            tmp.delete();
            throw new Exception("simpan gagal");
        }
    }

    private static void writeList(DataOutputStream out, List<double[]> l, double la0, double lo0) throws Exception {
        out.writeInt(l.size());
        for (double[] w : l) {
            out.writeShort(w.length / 2);
            for (int i = 0; i + 1 < w.length; i += 2) {
                out.writeFloat((float) (w[i] - la0));           // selisih dari sudut petak: float cukup (< 1 cm)
                out.writeFloat((float) (w[i + 1] - lo0));
            }
        }
    }

    private static void readList(DataInputStream in, List<double[]> l, double la0, double lo0) throws Exception {
        int n = in.readInt();
        for (int i = 0; i < n; i++) {
            int m = in.readUnsignedShort();
            double[] w = new double[m * 2];
            for (int k = 0; k < m; k++) {
                w[2 * k] = la0 + in.readFloat();
                w[2 * k + 1] = lo0 + in.readFloat();
            }
            l.add(w);
        }
    }
}
