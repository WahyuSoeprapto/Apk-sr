package com.wsmartrider.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

/**
 * Impor peta dari berkas GeoPackage (.gpkg, mis. ekstrak BBBike/GDAL dari OpenStreetMap) langsung di HP.
 * Membaca lapisan lines (jalan, sungai), multipolygons (air, taman, SPBU) dan points (SPBU), lalu mengubahnya
 * menjadi petak cache RoadCache. Berkas .gpkg tidak diubah dan boleh dihapus setelah selesai.
 */
final class GpkgImport {
    static volatile boolean running = false;
    static volatile boolean cancel = false;
    static volatile int percent = 0;
    static volatile String status = "";
    static volatile String error = null;

    private static final int CHUNK = 20000;

    private GpkgImport() {
    }

    static void start(final Context ctx, final Uri uri) {
        if (running) return;
        running = true;
        cancel = false;
        percent = 0;
        error = null;
        status = "Membuka berkas...";
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    doImport(ctx, uri);
                } catch (Throwable e) {
                    error = String.valueOf(e.getMessage() == null ? e.toString() : e.getMessage());
                    status = "Gagal: " + error;
                } finally {
                    running = false;
                }
            }
        }, "gpkg-import");
        t.setDaemon(true);
        t.start();
    }

    private static void doImport(Context ctx, Uri uri) throws Exception {
        RoadCache.init(ctx.getFilesDir());
        RoadCache.stopPrefetch();
        RoadCache.dropEmpty();                      // buang petak kosong sisa impor lama yang keliru
        File copy = null;
        ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
        if (pfd == null) throw new Exception("berkas tidak bisa dibuka");
        SQLiteDatabase db = null;
        try {
            // 1) buka langsung lewat descriptor (tanpa menyalin 1 GB); bila ditolak sistem, salin dulu ke penyimpanan aplikasi
            try {
                db = SQLiteDatabase.openDatabase("/proc/self/fd/" + pfd.getFd(), null, SQLiteDatabase.OPEN_READONLY);
                Cursor c = db.rawQuery("SELECT count(*) FROM sqlite_master", null);
                c.moveToFirst();
                c.close();
            } catch (Throwable e) {
                if (db != null) try {
                    db.close();
                } catch (Throwable ignored) {
                }
                db = null;
            }
            if (db == null) {
                copy = new File(ctx.getCacheDir(), "import.gpkg");
                long size = pfd.getStatSize();
                if (size > 0 && ctx.getCacheDir().getUsableSpace() < size + (300L << 20)) {
                    throw new Exception("penyimpanan kurang (perlu " + (size >> 20) + " MB + ruang kerja)");
                }
                InputStream in = ctx.getContentResolver().openInputStream(uri);
                FileOutputStream out = new FileOutputStream(copy);
                try {
                    byte[] buf = new byte[1 << 20];
                    long done = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cancel) throw new Exception("dibatalkan");
                        out.write(buf, 0, n);
                        done += n;
                        if (size > 0) {
                            percent = (int) (10L * done / size);
                            status = "Menyalin berkas " + (done >> 20) + " / " + (size >> 20) + " MB";
                        }
                    }
                } finally {
                    in.close();
                    out.close();
                }
                db = SQLiteDatabase.openDatabase(copy.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            }

            String tLines = findTable(db, "lines"), tPoly = findTable(db, "multipolygons"), tPts = findTable(db, "points");
            if (tLines == null && tPoly == null && tPts == null) {
                throw new Exception("bukan berkas peta OSM (lapisan lines/multipolygons/points tidak ada)");
            }
            TileBuilder tb = new TileBuilder(new File(ctx.getCacheDir(), "spill"));

            if (tPts != null) points(db, tPts, tb);
            if (tLines != null) lines(db, tLines, tb);
            if (tPoly != null) polys(db, tPoly, tb);

            // kotak area: dari nama berkas BBBike (planet_<lon1>,<lat1>_<lon2>,<lat2>.gpkg); bila tidak ada, dari sebaran data
            // yang terbaca, dikecilkan 2 petak di tiap sisi (petak pinggir tidak dianggap lengkap)
            double minLa, minLo, maxLa, maxLo;
            double[] nb = boxFromName(displayName(ctx, uri));
            if (nb != null) {
                minLo = nb[0];
                minLa = nb[1];
                maxLo = nb[2];
                maxLa = nb[3];
            } else {
                double m = 2 * Geo.TILE;
                minLa = tb.obsMinLa + m;
                minLo = tb.obsMinLo + m;
                maxLa = tb.obsMaxLa - m;
                maxLo = tb.obsMaxLo - m;
            }
            if (minLa >= maxLa || minLo >= maxLo) throw new Exception("tidak ada jalan di berkas ini");
            long nt = (long) Math.ceil((maxLa - minLa) / Geo.TILE + 1) * (long) Math.ceil((maxLo - minLo) / Geo.TILE + 1);
            if (nt > 20000) throw new Exception("area terlalu besar (" + nt + " petak), periksa nama/isi berkas");
            status = "Menyusun petak...";
            final int base = 70;
            int saved = tb.finish(minLa, minLo, maxLa, maxLo, new TileBuilder.Progress() {
                @Override
                public void on(int done, int total) {
                    percent = base + 30 * done / Math.max(1, total);
                    status = "Menyusun petak " + (percent - base) * 100 / 30 + "%";
                }
            });
            percent = 100;
            status = "Selesai: " + saved + " petak tersimpan (" + RoadCache.sizeText() + "). Berkas .gpkg boleh dihapus.";
        } finally {
            try {
                if (db != null) db.close();
            } catch (Throwable ignored) {
            }
            try {
                pfd.close();
            } catch (Throwable ignored) {
            }
            if (copy != null) copy.delete();
            File[] sp = new File(ctx.getCacheDir(), "spill").listFiles();
            if (sp != null) for (File f : sp) f.delete();
        }
    }

    // ------------------------------------------------------------------ pembacaan tabel

    private static String q(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private static String findTable(SQLiteDatabase db, String want) {
        Cursor c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null);
        try {
            while (c.moveToNext()) if (c.getString(0).equalsIgnoreCase(want)) return c.getString(0);
        } finally {
            c.close();
        }
        return null;
    }

    private static HashSet<String> columns(SQLiteDatabase db, String table) {
        HashSet<String> s = new HashSet<>();
        Cursor c = db.rawQuery("PRAGMA table_info(" + q(table) + ")", null);
        try {
            while (c.moveToNext()) s.add(c.getString(1));
        } finally {
            c.close();
        }
        return s;
    }

    private static String geomCol(SQLiteDatabase db, String table) {
        try {
            Cursor c = db.rawQuery("SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?", new String[]{table});
            try {
                if (c.moveToFirst()) return c.getString(0);
            } finally {
                c.close();
            }
        } catch (Throwable ignored) {
        }
        return "geom";
    }

    private static String displayName(Context ctx, Uri uri) {
        try {
            Cursor c = ctx.getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst() && !c.isNull(0)) return c.getString(0);
                } finally {
                    c.close();
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** "planet_106.282,-6.761_107.412,-5.994.gpkg" -> {lon1, lat1, lon2, lat2}. */
    static double[] boxFromName(String name) {
        if (name == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                "(-?\\d+(?:\\.\\d+)?),(-?\\d+(?:\\.\\d+)?)_(-?\\d+(?:\\.\\d+)?),(-?\\d+(?:\\.\\d+)?)").matcher(name);
        if (!m.find()) return null;
        try {
            double[] b = {Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2)),
                    Double.parseDouble(m.group(3)), Double.parseDouble(m.group(4))};
            if (b[0] < b[2] && b[1] < b[3] && b[0] >= -180 && b[2] <= 180 && b[1] >= -90 && b[3] <= 90) return b;
        } catch (Exception ignored) {
        }
        return null;
    }

    /** Nilai tag dari kolom other_tags berformat "kunci"=>"nilai","kunci2"=>"nilai2". */
    static String hs(String other, String key) {
        if (other == null) return null;
        String pat = "\"" + key + "\"=>\"";
        int i = other.indexOf(pat);
        while (i > 0 && other.charAt(i - 1) != ',') i = other.indexOf(pat, i + 1);   // pastikan awal kunci, bukan akhiran kunci lain
        if (i < 0) return null;
        i += pat.length();
        StringBuilder sb = new StringBuilder();
        while (i < other.length()) {
            char ch = other.charAt(i++);
            if (ch == '\\' && i < other.length()) {
                sb.append(other.charAt(i++));
                continue;
            }
            if (ch == '"') break;
            sb.append(ch);
        }
        return sb.toString();
    }

    private static String str(Cursor c, int i) {
        return i < 0 || c.isNull(i) ? null : c.getString(i);
    }

    private static long maxRow(SQLiteDatabase db, String table) {
        Cursor c = db.rawQuery("SELECT max(rowid) FROM " + q(table), null);
        try {
            return c.moveToFirst() ? c.getLong(0) : 0;
        } finally {
            c.close();
        }
    }

    private interface Row {
        void on(Cursor c) throws Exception;
    }

    /** Baca tabel per potongan rowid. Bila satu potongan gagal (mis. baris terlalu besar), ulangi baris per baris. */
    private static void scan(SQLiteDatabase db, String table, String cols, String where, int p0, int p1, String label, Row row) throws Exception {
        long max = maxRow(db, table);
        long n = 0;
        for (long lo = 1; lo <= max; lo += CHUNK) {
            if (cancel) throw new Exception("dibatalkan");
            String range = "rowid >= " + lo + " AND rowid < " + (lo + CHUNK);
            String sql = "SELECT " + cols + " FROM " + q(table) + " WHERE " + range + (where.isEmpty() ? "" : " AND (" + where + ")");
            try {
                Cursor c = db.rawQuery(sql, null);
                try {
                    while (c.moveToNext()) {
                        row.on(c);
                        n++;
                    }
                } finally {
                    c.close();
                }
            } catch (android.database.sqlite.SQLiteException e) {
                for (long r = lo; r < lo + CHUNK && r <= max; r++) {                 // cadangan: satu per satu, lewati yang bermasalah
                    try {
                        Cursor c = db.rawQuery("SELECT " + cols + " FROM " + q(table) + " WHERE rowid = " + r
                                + (where.isEmpty() ? "" : " AND (" + where + ")"), null);
                        try {
                            if (c.moveToFirst()) row.on(c);
                        } finally {
                            c.close();
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }
            percent = p0 + (int) ((p1 - p0) * Math.min(lo + CHUNK, max) / Math.max(1, max));
            status = label + ": " + String.format(Locale.US, "%,d", Math.min(lo + CHUNK, max)) + " dari " + String.format(Locale.US, "%,d", max) + " baris";
        }
    }

    // ------------------------------------------------------------------ per lapisan

    private static void lines(SQLiteDatabase db, String table, final TileBuilder tb) throws Exception {
        HashSet<String> cols = columns(db, table);
        String g = geomCol(db, table);
        final boolean hasHw = cols.contains("highway"), hasWw = cols.contains("waterway"), hasOt = cols.contains("other_tags");
        StringBuilder sel = new StringBuilder(q(g));
        final int iHw = hasHw ? 1 : -1;
        if (hasHw) sel.append(",").append(q("highway"));
        final int iWw = hasWw ? (hasHw ? 2 : 1) : -1;
        if (hasWw) sel.append(",").append(q("waterway"));
        final int iOt = hasOt ? 1 + (hasHw ? 1 : 0) + (hasWw ? 1 : 0) : -1;
        if (hasOt) sel.append(",").append(q("other_tags"));
        String where = (hasHw ? q("highway") + " IS NOT NULL" : (hasOt ? "other_tags LIKE '%\"highway\"=>%'" : "1"))
                + " OR " + (hasWw ? q("waterway") + " IS NOT NULL" : (hasOt ? "other_tags LIKE '%\"waterway\"=>%'" : "0"));
        scan(db, table, sel.toString(), where, 15, 45, "Membaca jalan", new Row() {
            @Override
            public void on(Cursor c) throws Exception {
                String ot = str(c, iOt);
                String hw = str(c, iHw);
                String ww = str(c, iWw);
                if (hw == null && !hasHw) hw = hs(ot, "highway");
                if (ww == null && !hasWw) ww = hs(ot, "waterway");
                int kind = -1;
                if (hw != null && !hw.isEmpty()) kind = classify(hw, ot);
                else if (ww != null && (ww.equals("river") || ww.equals("canal") || ww.equals("stream") || ww.equals("drain"))) kind = TileBuilder.STREAM;
                if (kind < 0) return;
                for (double[] p : GpkgGeom.parse(c.getBlob(0))) tb.addLine(kind, p);
            }
        });
    }

    private static int classify(String hw, String ot) {
        switch (hw) {
            case "motorway": case "trunk": case "primary": case "secondary": case "tertiary":
            case "motorway_link": case "trunk_link": case "primary_link": case "secondary_link": case "tertiary_link":
                return TileBuilder.MAJOR;
            case "residential": case "unclassified": case "living_street":
                return TileBuilder.MINOR;
            case "service": {
                String sv = hs(ot, "service");
                if ("parking_aisle".equals(sv) || "driveway".equals(sv) || "drive-through".equals(sv)) return -1;
                return TileBuilder.ALLEY;
            }
            case "footway": {
                String fw = hs(ot, "footway");
                if ("sidewalk".equals(fw) || "crossing".equals(fw)) return -1;
                return TileBuilder.ALLEY;
            }
            case "track": case "pedestrian": case "path": case "cycleway":
                return TileBuilder.ALLEY;
            default:
                return -1;
        }
    }

    private static void polys(SQLiteDatabase db, String table, final TileBuilder tb) throws Exception {
        HashSet<String> cols = columns(db, table);
        String g = geomCol(db, table);
        String[] want = {"natural", "landuse", "leisure", "amenity", "name", "other_tags"};
        final int[] idx = {-1, -1, -1, -1, -1, -1};
        StringBuilder sel = new StringBuilder(q(g));
        int n = 1;
        for (int i = 0; i < want.length; i++) {
            if (cols.contains(want[i])) {
                sel.append(",").append(q(want[i]));
                idx[i] = n++;
            }
        }
        ArrayList<String> conds = new ArrayList<>();
        for (int i = 0; i < 4; i++) if (idx[i] >= 0) conds.add(q(want[i]) + " IS NOT NULL");
        if (conds.isEmpty()) return;
        StringBuilder w = new StringBuilder();
        for (int i = 0; i < conds.size(); i++) w.append(i > 0 ? " OR " : "").append(conds.get(i));
        scan(db, table, sel.toString(), w.toString(), 45, 70, "Membaca air, taman, SPBU", new Row() {
            @Override
            public void on(Cursor c) throws Exception {
                String nat = str(c, idx[0]), lu = str(c, idx[1]), lei = str(c, idx[2]), am = str(c, idx[3]);
                if ("fuel".equals(am)) {
                    ArrayList<double[]> parts = GpkgGeom.parse(c.getBlob(0));
                    if (!parts.isEmpty()) {
                        double[] p = parts.get(0);
                        double sa = 0, so = 0;
                        int k = p.length / 2;
                        for (int i = 0; i < k; i++) {
                            sa += p[2 * i];
                            so += p[2 * i + 1];
                        }
                        if (k > 0) {
                            String nm = str(c, idx[4]);
                            if (nm == null || nm.isEmpty()) nm = hs(str(c, idx[5]), "brand");
                            tb.addFuel(sa / k, so / k, Geo.clean(nm));
                        }
                    }
                    return;
                }
                int kind = -1;
                if ("water".equals(nat) || "basin".equals(lu) || "reservoir".equals(lu)) kind = TileBuilder.WATER;
                else if ("wood".equals(nat) || "grassland".equals(nat) || "scrub".equals(nat)) kind = TileBuilder.PARK;
                else if (lei != null && (lei.equals("park") || lei.equals("garden") || lei.equals("playground") || lei.equals("pitch")
                        || lei.equals("recreation_ground") || lei.equals("nature_reserve"))) kind = TileBuilder.PARK;
                else if (lu != null && (lu.equals("grass") || lu.equals("recreation_ground") || lu.equals("forest") || lu.equals("meadow")
                        || lu.equals("village_green") || lu.equals("cemetery"))) kind = TileBuilder.PARK;
                if (kind < 0) return;
                for (double[] p : GpkgGeom.parse(c.getBlob(0))) tb.addRing(kind, p);
            }
        });
    }

    private static void points(SQLiteDatabase db, String table, final TileBuilder tb) throws Exception {
        HashSet<String> cols = columns(db, table);
        if (!cols.contains("other_tags") && !cols.contains("amenity")) return;
        String g = geomCol(db, table);
        final boolean hasAm = cols.contains("amenity"), hasNm = cols.contains("name"), hasOt = cols.contains("other_tags");
        StringBuilder sel = new StringBuilder(q(g));
        int n = 1;
        final int iNm = hasNm ? n++ : -1;
        if (hasNm) sel.append(",").append(q("name"));
        final int iOt = hasOt ? n++ : -1;
        if (hasOt) sel.append(",").append(q("other_tags"));
        String where = hasAm ? q("amenity") + "='fuel'" : "other_tags LIKE '%\"amenity\"=>\"fuel\"%'";
        if (hasAm && hasOt) where += " OR other_tags LIKE '%\"amenity\"=>\"fuel\"%'";
        scan(db, table, sel.toString(), where, 10, 15, "Membaca SPBU", new Row() {
            @Override
            public void on(Cursor c) throws Exception {
                String ot = str(c, iOt);
                String nm = str(c, iNm);
                if (nm == null || nm.isEmpty()) nm = hs(ot, "name");
                if (nm == null || nm.isEmpty()) nm = hs(ot, "brand");
                ArrayList<double[]> parts = GpkgGeom.parse(c.getBlob(0));
                if (!parts.isEmpty() && parts.get(0).length >= 2) {
                    tb.addFuel(parts.get(0)[0], parts.get(0)[1], Geo.clean(nm));
                }
            }
        });
    }
}
