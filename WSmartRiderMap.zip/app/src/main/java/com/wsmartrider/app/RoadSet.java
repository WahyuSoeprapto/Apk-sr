package com.wsmartrider.app;

import java.util.ArrayList;

/** Jalan-jalan sekitar posisi (dari OpenStreetMap lewat Overpass). */
final class RoadSet {
    double cLat, cLon;                                   // pusat area yang diunduh
    final ArrayList<double[]> major = new ArrayList<>(); // [lat0,lon0,lat1,lon1,...]
    final ArrayList<double[]> minor = new ArrayList<>();
    final ArrayList<double[]> water = new ArrayList<>();   // area air (danau, kolam, waduk) tertutup
    final ArrayList<double[]> park = new ArrayList<>();    // area taman / rumput / hutan tertutup
    final ArrayList<double[]> stream = new ArrayList<>();  // sungai / kali / kanal (garis)
    final ArrayList<String[]> fuel = new ArrayList<>();    // SPBU di sekitar: {lat, lon, nama} (cache agar pencarian instan)
    final ArrayList<double[]> alley = new ArrayList<>();  // gang / jalan servis / jalan setapak (hanya area dekat)
}
