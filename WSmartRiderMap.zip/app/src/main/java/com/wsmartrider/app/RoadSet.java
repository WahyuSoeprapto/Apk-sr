package com.wsmartrider.app;

import java.util.ArrayList;

/** Jalan-jalan sekitar posisi (dari OpenStreetMap lewat Overpass). */
final class RoadSet {
    double cLat, cLon;                                   // pusat area yang diunduh
    final ArrayList<double[]> major = new ArrayList<>(); // [lat0,lon0,lat1,lon1,...]
    final ArrayList<double[]> minor = new ArrayList<>();
    final ArrayList<double[]> alley = new ArrayList<>();  // gang / jalan servis / jalan setapak (hanya area dekat)
}
