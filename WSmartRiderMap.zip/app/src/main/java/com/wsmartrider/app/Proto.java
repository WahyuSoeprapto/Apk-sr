package com.wsmartrider.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Pembuat paket dalam format protokol Chronos (BLE) dan paket peta. */
final class Proto {
    static byte[] build(int hdr, int fe, int cmd, int sub, byte[] payload) {
        int total = 6 + payload.length;
        int len = total - 3;
        byte[] d = new byte[total];
        d[0] = (byte) hdr;
        d[1] = (byte) (len >> 8);
        d[2] = (byte) (len & 0xFF);
        d[3] = (byte) fe;
        d[4] = (byte) cmd;
        d[5] = (byte) sub;
        System.arraycopy(payload, 0, d, 6, payload.length);
        return d;
    }

    static byte[] ab(int cmd, int sub, byte[] payload) {
        return build(0xAB, 0xFE, cmd, sub, payload);
    }

    /** Teks aman untuk OLED: ASCII saja, tanpa baris baru. */
    static String ascii(String s, int max) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n.length() && sb.length() < max; i++) {
            char c = n.charAt(i);
            if (c == '\n' || c == '\r' || c == '\t') c = ' ';
            if (c >= 32 && c < 127) sb.append(c);
        }
        return sb.toString().trim();
    }

    private static byte[] cat(byte[] head, byte[] tail) {
        byte[] r = new byte[head.length + tail.length];
        System.arraycopy(head, 0, r, 0, head.length);
        System.arraycopy(tail, 0, r, head.length, tail.length);
        return r;
    }

    private static byte[] bytes(String s) {
        byte[] b = new byte[s.length()];
        for (int i = 0; i < b.length; i++) b[i] = (byte) s.charAt(i);
        return b;
    }

    // ---------------- jam ----------------
    static byte[] time() {
        Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR);
        byte[] p = new byte[]{
                0x00, (byte) (y >> 8), (byte) (y & 0xFF),
                (byte) (c.get(Calendar.MONTH) + 1), (byte) c.get(Calendar.DAY_OF_MONTH),
                (byte) c.get(Calendar.HOUR_OF_DAY), (byte) c.get(Calendar.MINUTE), (byte) c.get(Calendar.SECOND)};
        return ab(0x93, 0x80, p);
    }

    // ---------------- notifikasi & telepon ----------------
    static byte[] notification(int icon, String title, String text) {
        String t = ascii(title, 28);
        String m = ascii(text, 150);
        String all = t.isEmpty() ? m : (m.isEmpty() ? t : t + ": " + m);
        return ab(0x72, 0x80, cat(new byte[]{(byte) icon, 0x02}, bytes(all)));
    }

    static byte[] ringer(boolean start, String name) {
        return ab(0x72, 0x80, cat(new byte[]{(byte) (start ? 0x01 : 0x02), 0x00}, bytes(ascii(name, 40))));
    }

    // ---------------- baterai HP ----------------
    static byte[] battery(int level, boolean charging) {
        return ab(0x91, 0x80, new byte[]{(byte) (charging ? 1 : 0), (byte) level});
    }

    // ---------------- musik ----------------
    static byte[] musicInfo(int state, String app, String pkg) {
        byte[] head = new byte[]{(byte) state, 0, 0, 0, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF};
        byte[] a = bytes(ascii(app, 30));
        byte[] p = bytes(ascii(pkg, 60));
        byte[] body = new byte[a.length + 1 + p.length + 1];
        System.arraycopy(a, 0, body, 0, a.length);
        System.arraycopy(p, 0, body, a.length + 1, p.length);
        return ab(0x9D, 0x80, cat(head, body));
    }

    static byte[] musicTitle(String s) {
        return ab(0x9D, 0x81, cat(new byte[]{0x00}, cat(bytes(ascii(s, 80)), new byte[]{0})));
    }

    static byte[] musicArtist(String s) {
        return ab(0x9D, 0x82, cat(new byte[]{0x00}, cat(bytes(ascii(s, 60)), new byte[]{0})));
    }

    // ---------------- cuaca ----------------
    static byte[] city(String city) {
        return build(0xEA, 0xFE, 0x7E, 0x01, cat(new byte[]{0x00}, bytes(ascii(city, 64))));
    }

    // ---------------- navigasi belokan demi belokan (gaya Chronos) ----------------
    private static void put(java.io.ByteArrayOutputStream o, String s) {
        byte[] b = bytes(ascii(s, 60));
        o.write(b, 0, b.length);
        o.write(0);
    }

    /** Data navigasi: title = jarak ke belokan, directions = nama jalan / instruksi. */
    static byte[] navData(boolean hasIcon, int crc, String title, String duration, String distance,
                          String eta, String directions, String speed) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        o.write(hasIcon ? 1 : 0);
        o.write(1);
        o.write((crc >> 24) & 0xFF);
        o.write((crc >> 16) & 0xFF);
        o.write((crc >> 8) & 0xFF);
        o.write(crc & 0xFF);
        put(o, title);
        put(o, duration);
        put(o, distance);
        put(o, eta);
        put(o, directions);
        put(o, speed);
        return ab(0xEF, 0x80, o.toByteArray());
    }

    /** Ikon 48x48 (288 byte) dikirim dalam 3 paket berisi 96 byte. */
    static List<byte[]> navIcon(byte[] icon288, int crc) {
        List<byte[]> out = new ArrayList<>();
        for (int pos = 0; pos < 3; pos++) {
            byte[] pl = new byte[5 + 96];
            pl[0] = (byte) pos;
            pl[1] = (byte) ((crc >> 24) & 0xFF);
            pl[2] = (byte) ((crc >> 16) & 0xFF);
            pl[3] = (byte) ((crc >> 8) & 0xFF);
            pl[4] = (byte) (crc & 0xFF);
            System.arraycopy(icon288, pos * 96, pl, 5, 96);
            out.add(ab(0xEE, 0x80, pl));
        }
        return out;
    }

    static byte[] navOff() {
        return ab(0xEF, 0x00, new byte[0]);
    }

    // ---------------- pemecahan paket (kerangka Chronos) ----------------
    /** Paket mengikuti kerangka library: 20 byte pertama, lalu potongan [urutan + 19 byte]. */
    static List<byte[]> frame(byte[] p, int mtu) {
        List<byte[]> out = new ArrayList<>();
        if (p.length <= Math.max(20, mtu - 3)) {
            out.add(p);
            return out;
        }
        byte[] first = new byte[20];
        System.arraycopy(p, 0, first, 0, 20);
        out.add(first);
        int off = 20;
        int seq = 0;
        while (off < p.length) {
            int n = Math.min(19, p.length - off);
            byte[] c = new byte[n + 1];
            c[0] = (byte) seq++;
            System.arraycopy(p, off, c, 1, n);
            out.add(c);
            off += n;
        }
        return out;
    }

    /** Potongan frame peta (perintah 0xC5) agar muat dalam satu tulis BLE. */
    static List<byte[]> mapChunks(byte[] pkt, int mtu, int frameId) {
        int per = Math.max(10, Math.min(400, mtu - 3 - 10));
        int n = (pkt.length + per - 1) / per;
        List<byte[]> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int off = i * per;
            int len = Math.min(per, pkt.length - off);
            byte[] d = new byte[10 + len];
            int lenField = d.length - 3;
            d[0] = (byte) 0xAB;
            d[1] = (byte) (lenField >> 8);
            d[2] = (byte) (lenField & 0xFF);
            d[3] = (byte) 0xFF;
            d[4] = (byte) 0xC5;
            d[5] = (byte) frameId;
            d[6] = (byte) i;
            d[7] = (byte) n;
            d[8] = (byte) (off >> 8);
            d[9] = (byte) (off & 0xFF);
            System.arraycopy(pkt, off, d, 10, len);
            out.add(d);
        }
        return out;
    }
}
