package com.wsmartrider.app;

/** Rute hasil OSRM: titik-titik jalur + daftar belokan. */
final class Route {
    double[] lat, lon, cum;      // cum[i] = jarak kumulatif (m) dari titik 0
    double totalDist, totalDur;  // meter, detik
    int nSteps;
    int[] stepIdx;
    double[] stepDist;           // jarak (m) dari awal rute ke belokan
    String[] stepType, stepMod, stepName;

    int curSeg = 0;              // segmen terdekat dengan posisi terakhir
    double offDist = 0;          // jarak (m) posisi dari rute

    /** Proyeksikan posisi ke rute. Mengembalikan jarak tempuh (m) di sepanjang rute. */
    double project(double la, double lo, boolean full) {
        int n = lat.length;
        if (n < 2) { offDist = 0; return 0; }
        int from = full ? 0 : Math.max(0, curSeg - 3);
        int to = full ? n - 2 : Math.min(n - 2, curSeg + 150);
        double cl = Math.cos(Math.toRadians(la));
        double best = 1e18, bt = 0;
        int bj = Math.min(curSeg, n - 2);
        for (int j = from; j <= to; j++) {
            double ax = (lon[j] - lo) * 111320.0 * cl, ay = (lat[j] - la) * 110540.0;
            double bx = (lon[j + 1] - lo) * 111320.0 * cl, by = (lat[j + 1] - la) * 110540.0;
            double dx = bx - ax, dy = by - ay;
            double len2 = dx * dx + dy * dy;
            double t = len2 < 1e-9 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / len2));
            double px = ax + t * dx, py = ay + t * dy;
            double d = Math.sqrt(px * px + py * py);
            if (d < best) { best = d; bj = j; bt = t; }
        }
        curSeg = bj;
        offDist = best;
        return cum[bj] + bt * (cum[bj + 1] - cum[bj]);
    }

    /** Arah (derajat dari utara) segmen j. */
    double bearing(int j) {
        int n = lat.length;
        if (n < 2) return 0;
        j = Math.max(0, Math.min(n - 2, j));
        double cl = Math.cos(Math.toRadians(lat[j]));
        double dx = (lon[j + 1] - lon[j]) * cl, dy = lat[j + 1] - lat[j];
        double b = Math.toDegrees(Math.atan2(dx, dy));
        return (b + 360.0) % 360.0;
    }
}
