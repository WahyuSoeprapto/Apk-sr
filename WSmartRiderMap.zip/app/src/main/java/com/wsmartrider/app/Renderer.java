package com.wsmartrider.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;

/** Menggambar peta 128x64 hitam-putih, hasilnya format XBM (1024 byte) untuk U8g2. */
final class Renderer {
    static final int W = 128, H = 64, TOP = 15, CX = 64, CY = 47;

    private final Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
    private final Canvas c = new Canvas(bmp);
    private final int[] px = new int[W * H];

    private final Paint majorP = stroke(Color.WHITE, 1f);
    private final Paint minorP = stroke(Color.WHITE, 1f);
    private final Paint routeBlack = stroke(Color.BLACK, 5f);
    private final Paint routeWhite = stroke(Color.WHITE, 3f);
    private final Paint thin = stroke(Color.WHITE, 1f);
    private final Paint arrowLine = stroke(Color.WHITE, 2f);
    private final Paint fillWhite = fill(Color.WHITE);
    private final Paint fillBlack = fill(Color.BLACK);

    // parameter proyeksi untuk satu frame
    private double la0, lo0, kx, ky, sinH, cosH, scale;
    private final float[] o = new float[2];

    Renderer() {
        minorP.setPathEffect(new DashPathEffect(new float[]{2f, 3f}, 0f));
    }

    private static Paint stroke(int color, float w) {
        Paint p = new Paint();
        p.setAntiAlias(false);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(w);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeCap(Paint.Cap.ROUND);
        return p;
    }

    private static Paint fill(int color) {
        Paint p = new Paint();
        p.setAntiAlias(false);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    private void proj(double la, double lo) {
        double dx = (lo - lo0) * kx;
        double dy = (la - la0) * ky;
        o[0] = (float) (CX + (dx * cosH - dy * sinH) / scale);
        o[1] = (float) (CY - (dx * sinH + dy * cosH) / scale);
    }

    private Path wayPath(double[] pts) {
        Path p = new Path();
        for (int i = 0; i + 1 < pts.length; i += 2) {
            proj(pts[i], pts[i + 1]);
            if (i == 0) p.moveTo(o[0], o[1]);
            else p.lineTo(o[0], o[1]);
        }
        return p;
    }

    /**
     * @param arrowKind 0 = tanpa ikon, 1 = panah (arrowAngle derajat, 0 = lurus, 90 = kanan), 2 = tiba
     */
    byte[] render(double la, double lo, double headingDeg, double metersPerPx,
                  RoadSet roads, Route rt, int curSeg, double progress,
                  int arrowKind, float arrowAngle) {
        la0 = la;
        lo0 = lo;
        kx = 111320.0 * Math.cos(Math.toRadians(la));
        ky = 110540.0;
        double hr = Math.toRadians(headingDeg);
        sinH = Math.sin(hr);
        cosH = Math.cos(hr);
        scale = metersPerPx;

        c.drawColor(Color.BLACK);

        // ---- area peta ----
        c.save();
        c.clipRect(0, TOP, W, H);

        if (roads != null) {
            for (double[] w : roads.minor) c.drawPath(wayPath(w), minorP);
            for (double[] w : roads.major) c.drawPath(wayPath(w), majorP);
        }

        if (rt != null) {
            Path rp = new Path();
            rp.moveTo(CX, CY);
            int n = rt.lat.length;
            for (int i = Math.max(0, curSeg + 1); i < n; i++) {
                if (rt.cum[i] > progress + 3000.0) break;
                proj(rt.lat[i], rt.lon[i]);
                rp.lineTo(o[0], o[1]);
            }
            c.drawPath(rp, routeBlack);
            c.drawPath(rp, routeWhite);
        }

        // penanda posisi (segitiga menghadap atas)
        c.drawCircle(CX, CY, 7f, fillBlack);
        Path tri = new Path();
        tri.moveTo(CX, CY - 6);
        tri.lineTo(CX + 5, CY + 5);
        tri.lineTo(CX, CY + 2);
        tri.lineTo(CX - 5, CY + 5);
        tri.close();
        c.drawPath(tri, fillWhite);
        c.restore();

        // ---- banner atas ----
        c.drawRect(0, 0, W, TOP - 1, fillBlack);
        c.drawLine(0, TOP - 1, W, TOP - 1, thin);

        if (arrowKind == 1) {
            c.save();
            c.translate(8f, 7f);
            c.rotate(arrowAngle);
            c.drawLine(0f, 5f, 0f, -3f, arrowLine);
            Path head = new Path();
            head.moveTo(0f, -6f);
            head.lineTo(-4f, -1f);
            head.lineTo(4f, -1f);
            head.close();
            c.drawPath(head, fillWhite);
            c.restore();
        } else if (arrowKind == 2) {
            c.drawCircle(8f, 7f, 5f, thin);
            c.drawCircle(8f, 7f, 2f, fillWhite);
        }

        // ---- ke XBM ----
        bmp.getPixels(px, 0, W, 0, 0, W, H);
        byte[] out = new byte[W * H / 8];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if ((px[y * W + x] & 0xFF) > 127) {
                    out[y * (W / 8) + (x >> 3)] |= (byte) (1 << (x & 7));
                }
            }
        }
        return out;
    }
}
