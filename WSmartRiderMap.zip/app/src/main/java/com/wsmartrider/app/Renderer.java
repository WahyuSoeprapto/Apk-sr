package com.wsmartrider.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import java.util.Locale;

/** Menggambar peta 128x64 hitam-putih, hasilnya format XBM (1024 byte) untuk U8g2. */
final class Renderer {
    static final int W = 128, H = 64, TOP = 15, CX = 64, CY = 47;

    private final Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
    private final Canvas c = new Canvas(bmp);
    private final int[] px = new int[W * H];

    private final Paint majorP = stroke(Color.WHITE, 1f);
    private final Paint minorP = stroke(Color.WHITE, 1f);
    private final Paint routeBlack = stroke(Color.BLACK, 5f);
    private final Paint routeWhite = stroke(Color.WHITE, 3f);
    private final Paint thin = stroke(Color.WHITE, 1f);
    private final Paint arrowLine = stroke(Color.WHITE, 2f);
    private final Paint fillWhite = fill(Color.WHITE);
    private final Paint fillBlack = fill(Color.BLACK);

    // parameter proyeksi untuk satu frame
    private double la0, lo0, kx, ky, sinH, cosH, scale;
    private double pcx = CX, pcy = CY;                 // titik posisi pengguna di gambar (berbeda untuk peta warna)
    private final float[] o = new float[2];

    Renderer() {
        minorP.setPathEffect(new DashPathEffect(new float[]{2f, 3f}, 0f));
    }

    private static Paint stroke(int color, float w) {
        Paint p = new Paint();
        p.setAntiAlias(false);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(w);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeCap(Paint.Cap.ROUND);
        return p;
    }

    private static Paint fill(int color) {
        Paint p = new Paint();
        p.setAntiAlias(false);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    private void proj(double la, double lo) {
        double dx = (lo - lo0) * kx;
        double dy = (la - la0) * ky;
        o[0] = (float) (pcx + (dx * cosH - dy * sinH) / scale);
        o[1] = (float) (pcy - (dx * sinH + dy * cosH) / scale);
    }

    private Path wayPath(double[] pts) {
        Path p = new Path();
        for (int i = 0; i + 1 < pts.length; i += 2) {
            proj(pts[i], pts[i + 1]);
            if (i == 0) p.moveTo(o[0], o[1]);
            else p.lineTo(o[0], o[1]);
        }
        return p;
    }

    /**
     * @param arrowKind 0 = tanpa ikon, 1 = panah (arrowAngle derajat, 0 = lurus, 90 = kanan), 2 = tiba
     */
    byte[] render(double la, double lo, double headingDeg, double metersPerPx,
                  RoadSet roads, Route rt, int curSeg, double progress,
                  int arrowKind, float arrowAngle) {
        la0 = la;
        lo0 = lo;
        pcx = CX;
        pcy = CY;
        kx = 111320.0 * Math.cos(Math.toRadians(la));
        ky = 110540.0;
        double hr = Math.toRadians(headingDeg);
        sinH = Math.sin(hr);
        cosH = Math.cos(hr);
        scale = metersPerPx;

        c.drawColor(Color.BLACK);

        // ---- area peta ----
        c.save();
        c.clipRect(0, TOP, W, H);

        if (roads != null) {
            for (double[] w : roads.minor) c.drawPath(wayPath(w), minorP);
            for (double[] w : roads.major) c.drawPath(wayPath(w), majorP);
        }

        if (rt != null) {
            Path rp = new Path();
            rp.moveTo(CX, CY);
            int n = rt.lat.length;
            for (int i = Math.max(0, curSeg + 1); i < n; i++) {
                if (rt.cum[i] > progress + 3000.0) break;
                proj(rt.lat[i], rt.lon[i]);
                rp.lineTo(o[0], o[1]);
            }
            c.drawPath(rp, routeBlack);
            c.drawPath(rp, routeWhite);
        }

        // penanda posisi (segitiga menghadap atas)
        c.drawCircle(CX, CY, 7f, fillBlack);
        Path tri = new Path();
        tri.moveTo(CX, CY - 6);
        tri.lineTo(CX + 5, CY + 5);
        tri.lineTo(CX, CY + 2);
        tri.lineTo(CX - 5, CY + 5);
        tri.close();
        c.drawPath(tri, fillWhite);
        c.restore();

        // ---- banner atas ----
        c.drawRect(0, 0, W, TOP - 1, fillBlack);
        c.drawLine(0, TOP - 1, W, TOP - 1, thin);

        if (arrowKind == 1) {
            c.save();
            c.translate(8f, 7f);
            c.rotate(arrowAngle);
            c.drawLine(0f, 5f, 0f, -3f, arrowLine);
            Path head = new Path();
            head.moveTo(0f, -6f);
            head.lineTo(-4f, -1f);
            head.lineTo(4f, -1f);
            head.close();
            c.drawPath(head, fillWhite);
            c.restore();
        } else if (arrowKind == 2) {
            c.drawCircle(8f, 7f, 5f, thin);
            c.drawCircle(8f, 7f, 2f, fillWhite);
        }

        // ---- ke XBM ----
        bmp.getPixels(px, 0, W, 0, 0, W, H);
        byte[] out = new byte[W * H / 8];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if ((px[y * W + x] & 0xFF) > 127) {
                    out[y * (W / 8) + (x >> 3)] |= (byte) (1 << (x & 7));
                }
            }
        }
        return out;
    }

    // ===================================================================
    // PETA BERWARNA (untuk layar TFT): kotak side x side, format RGB332.
    // Banner belokan dan info bawah ikut tergambar di dalamnya.
    // ===================================================================
    private Bitmap cbmp;
    private Canvas cc;
    private int[] cpx;
    private int cside = 0;

    private static Paint cstroke(int color, float w) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(w);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeCap(Paint.Cap.ROUND);
        return p;
    }

    private static Paint cfill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    private static String fit(Paint p, String t, float maxW) {
        if (t == null) return "";
        if (p.measureText(t) <= maxW) return t;
        int n = p.breakText(t, true, maxW - p.measureText(".."), null);
        return t.substring(0, Math.max(0, n)) + "..";
    }

    // teks dengan garis tepi gelap (pengganti bar latar) supaya tetap terbaca di atas peta
    private void halo(String t, float x, float y, Paint p) {
        int col = p.getColor();
        Paint.Style st = p.getStyle();
        float sw = p.getStrokeWidth();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Math.max(2f, p.getTextSize() * 0.30f));
        p.setColor(0xFF050A1E);
        cc.drawText(t, x, y, p);
        p.setStyle(st);
        p.setStrokeWidth(sw);
        p.setColor(col);
        cc.drawText(t, x, y, p);
    }

    private static float tsz(float base, float s) {
        return Math.max(6f, base * s);
    }

    static volatile double zoomOut = 1.5;    // 1.0 = zoom semula, 1.5 = peta lebih luas (diatur dengan ketuk 2x / 3x di W-Smart Rider)

    byte[] renderColor(int side, double la, double lo, double headingDeg, double metersPerPx,
                       RoadSet roads, Route rt, int curSeg, double progress,
                       int arrowKind, float arrowAngle, int distNext, String name,
                       int eta, int remain10, int kmh, int flags, boolean jam, Traffic traf) {
        if (cbmp == null || cside != side) {
            cbmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
            cc = new Canvas(cbmp);
            cpx = new int[side * side];
            cside = side;
        }
        final float s = side / 240f;
        la0 = la;
        lo0 = lo;
        pcx = side / 2.0;
        pcy = side * 0.68;
        kx = 111320.0 * Math.cos(Math.toRadians(la));
        ky = 110540.0;
        double hr = Math.toRadians(headingDeg);
        sinH = Math.sin(hr);
        cosH = Math.cos(hr);
        scale = metersPerPx * 128.0 / side * 0.85 * zoomOut;

        cc.drawColor(0xFF0B1230);

        // ---- taman (hijau) & air (biru) di bawah jalan ----
        if (roads != null) {
            Paint parkC = cfill(0xFF1E9A4E);
            Paint waterC = cfill(0xFF2A7BFF);
            for (double[] w : roads.park) cc.drawPath(wayPath(w), parkC);
            for (double[] w : roads.water) cc.drawPath(wayPath(w), waterC);
            Paint streamC = cstroke(0xFF2A7BFF, Math.max(1.6f, 3.2f * s));
            for (double[] w : roads.stream) cc.drawPath(wayPath(w), streamC);
        }

        // ---- jalan (semua, termasuk gang kecil) ----
        Paint alleyC = cstroke(0xFF6A7DCC, Math.max(1.0f, 1.5f * s));
        Paint minorC = cstroke(0xFF8CA0E8, Math.max(1.3f, 2.0f * s));
        Paint majorC = cstroke(0xFFD0DAFF, Math.max(1.6f, 3.2f * s));
        if (roads != null) {
            for (double[] w : roads.alley) cc.drawPath(wayPath(w), alleyC);
            for (double[] w : roads.minor) cc.drawPath(wayPath(w), minorC);
            for (double[] w : roads.major) cc.drawPath(wayPath(w), majorC);
        }

        // ---- rute (merah di ~500 m ke depan bila terdeteksi macet) ----
        if (rt != null) {
            Path rp = new Path();
            Path near = new Path();
            rp.moveTo((float) pcx, (float) pcy);
            near.moveTo((float) pcx, (float) pcy);
            int n = rt.lat.length;
            for (int i = Math.max(0, curSeg + 1); i < n; i++) {
                if (rt.cum[i] > progress + 3000.0) break;
                proj(rt.lat[i], rt.lon[i]);
                rp.lineTo(o[0], o[1]);
                if (rt.cum[i] <= progress + 500.0) near.lineTo(o[0], o[1]);
            }
            cc.drawPath(rp, cstroke(0xFF1670D0, 8f * s));
            cc.drawPath(rp, cstroke(0xFF3CD8FF, 4.5f * s));
            cc.drawPath(rp, cstroke(0xFFD8FAFF, 1.4f * s));
            if (traf != null) {                               // data lalu lintas asli: merah = macet, oranye = padat
                for (int q = 0; q < traf.ratio.length; q++) {
                    float r = traf.ratio[q];
                    if (r >= 0.7f) continue;
                    int c1 = r < 0.4f ? 0xFF901010 : 0xFF9A5A00, c2 = r < 0.4f ? 0xFFFF3030 : 0xFFFFA020, c3 = r < 0.4f ? 0xFFFFC8C8 : 0xFFFFE0B0;
                    Path tp = new Path();
                    boolean st = false;
                    double a0 = Math.max(traf.from[q], progress);
                    for (int i = Math.max(0, curSeg + 1); i < n; i++) {
                        if (rt.cum[i] > traf.to[q]) break;
                        if (rt.cum[i] < a0) continue;
                        proj(rt.lat[i], rt.lon[i]);
                        if (!st) { tp.moveTo(o[0], o[1]); st = true; } else tp.lineTo(o[0], o[1]);
                    }
                    if (!st) continue;
                    cc.drawPath(tp, cstroke(c1, 8f * s));
                    cc.drawPath(tp, cstroke(c2, 4.5f * s));
                    cc.drawPath(tp, cstroke(c3, 1.4f * s));
                }
            } else if (jam) {
                cc.drawPath(near, cstroke(0xFF901010, 8f * s));
                cc.drawPath(near, cstroke(0xFFFF3030, 4.5f * s));
                cc.drawPath(near, cstroke(0xFFFFC8C8, 1.4f * s));
            }
        }

        // ---- penanda posisi ----
        float px0 = (float) pcx, py0 = (float) pcy;
        cc.drawCircle(px0, py0, 11f * s, cfill(0xAA0B1230));
        cc.drawCircle(px0, py0, 11f * s, cstroke(0xFF3CD8FF, 1.6f * s));
        Path tri = new Path();
        tri.moveTo(px0, py0 - 8f * s);
        tri.lineTo(px0 + 6f * s, py0 + 6f * s);
        tri.lineTo(px0, py0 + 2f * s);
        tri.lineTo(px0 - 6f * s, py0 + 6f * s);
        tri.close();
        cc.drawPath(tri, cfill(0xFFFFFFFF));

        // ---- info atas (tanpa bar): ikon belokan + jarak + nama jalan, teks kecil ----
        Paint tw = cfill(0xFFFFFFFF);
        tw.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        Paint ts = cfill(0xFFC8D6FF);
        boolean noRoute = (flags & 2) != 0;
        if (!noRoute) {
            int acc = 0xFF50EBA0;
            float ax = 14f * s, ay = 15f * s;
            cc.drawCircle(ax, ay, 12f * s, cfill(0xB00B1230));
            if (arrowKind == 1) {
                cc.save();
                cc.translate(ax, ay);
                cc.rotate(arrowAngle);
                cc.drawLine(0f, 7f * s, 0f, -3f * s, cstroke(acc, 3f * s));
                Path head = new Path();
                head.moveTo(0f, -9f * s);
                head.lineTo(-6f * s, -1f * s);
                head.lineTo(6f * s, -1f * s);
                head.close();
                cc.drawPath(head, cfill(acc));
                cc.restore();
            } else if (arrowKind == 2) {
                cc.drawCircle(ax, ay, 7f * s, cstroke(acc, 2f * s));
                cc.drawCircle(ax, ay, 3f * s, cfill(acc));
            }
            float textX = 30f * s;
            String d;
            if ((flags & 1) != 0) d = "Tiba";
            else if (distNext >= 1000) d = String.format(Locale.US, "%.1f km", distNext / 1000.0);
            else d = distNext + " m";
            tw.setTextSize(tsz(14f, s));
            halo(d, textX, 15f * s, tw);
            ts.setTextSize(tsz(10f, s));
            halo(fit(ts, name, side - textX - 4f * s), textX, 27f * s, ts);
        } else {
            tw.setTextSize(tsz(11f, s));
            halo(fit(tw, name, side - 12f * s), 6f * s, 14f * s, tw);
        }

        // ---- info bawah (tanpa bar): sisa jarak + waktu kiri, kecepatan kanan ----
        float by = side - 5f * s;
        if (!noRoute) {
            Paint bl = cfill(0xFFE8EEFF);
            bl.setTextSize(tsz(11f, s));
            String info = String.format(Locale.US, "%.1f km  %d mnt", remain10 * 10 / 1000.0, eta);
            halo(fit(bl, info, side * 0.55f), 6f * s, by, bl);
        }
        Paint sp = cfill(0xFF50EBA0);
        sp.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        sp.setTextSize(tsz(14f, s));
        String kt = kmh + " km/j";
        halo(kt, side - 6f * s - sp.measureText(kt), by, sp);

        // ---- ke RGB332 ----
        cbmp.getPixels(cpx, 0, side, 0, 0, side, side);
        byte[] out = new byte[side * side];
        for (int i = 0; i < out.length; i++) {
            int px = cpx[i];
            int r = Math.min(255, ((px >> 16) & 0xFF) + 16);
            int g = Math.min(255, ((px >> 8) & 0xFF) + 16);
            int b = Math.min(255, (px & 0xFF) + 32);
            out[i] = (byte) (((r >> 5) << 5) | ((g >> 5) << 2) | (b >> 6));
        }
        return out;
    }
}
