package com.wsmartrider.app;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/** Pembaca geometri GeoPackage (header GP + WKB). Hasil: daftar bagian, tiap bagian {lat0,lon0,lat1,lon1,...}.
 *  Polygon: hanya cincin luar. Titik: satu bagian dengan 1 pasang koordinat. */
final class GpkgGeom {
    private GpkgGeom() {
    }

    static ArrayList<double[]> parse(byte[] b) {
        ArrayList<double[]> out = new ArrayList<>();
        try {
            if (b == null || b.length < 12 || b[0] != 'G' || b[1] != 'P') return out;
            int flags = b[3] & 0xff;
            if (((flags >> 4) & 1) == 1) return out;                       // geometri kosong
            int env = (flags >> 1) & 7;
            int envLen = env == 0 ? 0 : (env == 1 ? 32 : (env == 2 || env == 3 ? 48 : (env == 4 ? 64 : -1)));
            if (envLen < 0) return out;
            ByteBuffer bb = ByteBuffer.wrap(b);
            bb.position(8 + envLen);
            read(bb, out);
        } catch (Exception ignored) {
        }
        return out;
    }

    private static void read(ByteBuffer bb, ArrayList<double[]> out) {
        byte bo = bb.get();
        bb.order(bo == 1 ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
        int t = bb.getInt();
        boolean z = (t & 0x80000000) != 0, m = (t & 0x40000000) != 0;
        t &= 0x0FFFFFFF;
        if (t >= 3000) {
            z = true;
            m = true;
            t -= 3000;
        } else if (t >= 2000) {
            m = true;
            t -= 2000;
        } else if (t >= 1000) {
            z = true;
            t -= 1000;
        }
        int dims = 2 + (z ? 1 : 0) + (m ? 1 : 0);
        switch (t) {
            case 1: {
                double x = bb.getDouble(), y = bb.getDouble();
                for (int k = 2; k < dims; k++) bb.getDouble();
                out.add(new double[]{y, x});
                break;
            }
            case 2:
                out.add(readPts(bb, dims));
                break;
            case 3: {
                int nr = bb.getInt();
                for (int r = 0; r < nr; r++) {
                    double[] ring = readPts(bb, dims);
                    if (r == 0) out.add(ring);                           // lubang (inner ring) diabaikan
                }
                break;
            }
            case 5:
            case 6:
            case 7: {
                int n = bb.getInt();
                for (int i = 0; i < n; i++) read(bb, out);
                break;
            }
            default:
                throw new IllegalStateException("tipe geometri " + t);
        }
    }

    private static double[] readPts(ByteBuffer bb, int dims) {
        int n = bb.getInt();
        double[] p = new double[n * 2];
        for (int i = 0; i < n; i++) {
            double x = bb.getDouble(), y = bb.getDouble();
            for (int k = 2; k < dims; k++) bb.getDouble();
            p[2 * i] = y;
            p[2 * i + 1] = x;
        }
        return p;
    }
}
