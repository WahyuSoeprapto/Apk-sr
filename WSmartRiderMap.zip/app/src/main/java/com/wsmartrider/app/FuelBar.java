package com.wsmartrider.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Bar sisa bensin berupa balok-balok berwarna (merah -> oranye -> kuning -> hijau). */
final class FuelBar extends View {
    private static final int BLOCKS = 6;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private float frac = 0f;
    private String big = "-- L", small = "";
    private boolean has = false;

    FuelBar(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    void setFuel(boolean valid, float fraction, String bigText, String smallText) {
        has = valid;
        frac = Math.max(0f, Math.min(1f, fraction));
        big = bigText;
        small = smallText;
        invalidate();
    }

    // warna tiap batang dari E (kiri) ke F (kanan): sama dengan spdFuelCol() di sketch
    private static final int[] COLORS = {0xFFFF4646, 0xFFFF8C32, 0xFFFFD63C, 0xFFAAEB46, 0xFF3CE16E, 0xFF46D7F0};

    private static int blockColor(int i) {
        return COLORS[Math.max(0, Math.min(COLORS.length - 1, i))];
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), (int) (118 * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        // angka besar di atas
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextAlign(Paint.Align.LEFT);
        int low = frac < 0.15f ? 0xFFFF4D4D : 0xFFFFFFFF;
        p.setColor(has ? low : 0xFF8899AA);
        p.setTextSize(28 * d);
        c.drawText(big, 0, 30 * d, p);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(14 * d);
        p.setColor(0xFF9FB3C8);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(small, w, 30 * d, p);
        // balok-balok
        float top = 46 * d, h = 38 * d, gap = 6 * d;
        float bw = (w - gap * (BLOCKS - 1)) / BLOCKS;
        int lit = has ? (int) Math.ceil(frac * BLOCKS - 0.001f) : 0;   // sama dengan OLED/TFT
        if (lit > BLOCKS) lit = BLOCKS;
        if (has && frac > 0.02f && lit == 0) lit = 1;
        for (int i = 0; i < BLOCKS; i++) {
            float x = i * (bw + gap);
            p.setColor(i < lit ? blockColor(i) : 0xFF1C2A3E);
            c.drawRoundRect(new RectF(x, top, x + bw, top + h), 6 * d, 6 * d, p);
        }
        // keterangan E / F
        p.setColor(0xFF9FB3C8);
        p.setTextSize(13 * d);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText("E", 0, top + h + 20 * d, p);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText("F", w, top + h + 20 * d, p);
    }
}
