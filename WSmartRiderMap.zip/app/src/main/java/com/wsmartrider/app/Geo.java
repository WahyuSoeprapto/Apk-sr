package com.wsmartrider.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

/** Semua akses internet: pencarian tujuan, rute, dan data jalan. */
final class Geo {
    private static final String UA = "WSmartRiderMap/1.0 (ESP32 hobby navigation)";

    static String http(String urlStr, String postBody) throws IOException {
        return http(urlStr, postBody, 10000, 30000);
    }

    static String http(String urlStr, String postBody, int connMs, int readMs) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(connMs);
        c.setReadTimeout(readMs);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "application/json");
        if (postBody != null) {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            OutputStream os = c.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.close();
        }
        int code = c.getResponseCode();
        if (code != 200) {
            c.disconnect();
            throw new IOException("HTTP " + code);
        }
        InputStream in = c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
        in.close();
        c.disconnect();
        return bo.toString("UTF-8");
    }

    /** Cari koordinat tujuan. Hasil: {lat, lon}. */
    static double[] geocode(String q, double la, double lo) throws Exception {
        String vb = (lo - 0.6) + "," + (la + 0.6) + "," + (lo + 0.6) + "," + (la - 0.6);
        String url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&viewbox=" + vb
                + "&q=" + URLEncoder.encode(q, "UTF-8");
        JSONArray a = new JSONArray(http(url, null));
        if (a.length() == 0) throw new Exception("Tujuan tidak ditemukan");
        JSONObject o = a.getJSONObject(0);
        return new double[]{Double.parseDouble(o.getString("lat")), Double.parseDouble(o.getString("lon"))};
    }

    /** Hitung rute mobil/motor dengan OSRM. */
    static Route route(double la, double lo, double dla, double dlo) throws Exception {
        String url = String.format(Locale.US,
                "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f"
                        + "?overview=full&geometries=geojson&steps=true", lo, la, dlo, dla);
        JSONObject root = new JSONObject(http(url, null));
        if (!"Ok".equals(root.optString("code"))) throw new Exception("Rute tidak ditemukan");
        return parseRoute(root.getJSONArray("routes").getJSONObject(0));
    }

    /** Rute beserta jalur alternatifnya (OSRM), rute utama di urutan pertama. */
    static java.util.List<Route> routes(double la, double lo, double dla, double dlo) throws Exception {
        String url = String.format(Locale.US,
                "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f"
                        + "?overview=full&geometries=geojson&steps=true&alternatives=true", lo, la, dlo, dla);
        JSONObject root = new JSONObject(http(url, null));
        if (!"Ok".equals(root.optString("code"))) throw new Exception("Rute tidak ditemukan");
        JSONArray ra = root.getJSONArray("routes");
        java.util.ArrayList<Route> out = new java.util.ArrayList<>();
        for (int i = 0; i < ra.length(); i++) {
            try {
                out.add(parseRoute(ra.getJSONObject(i)));
            } catch (Exception ignored) {
            }
        }
        if (out.isEmpty()) throw new Exception("Rute tidak ditemukan");
        return out;
    }

    private static final String[] OVERPASS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
            "https://overpass.private.coffee/api/interpreter"
    };

    /** Kirim query yang sama ke semua server Overpass bersamaan; kembalikan jawaban pertama yang sukses (null bila semua gagal). */
    private static String raceHttp(final String body) {
        final java.util.concurrent.LinkedBlockingQueue<String> q = new java.util.concurrent.LinkedBlockingQueue<>();
        for (final String srv : OVERPASS) {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        q.add(http(srv, body, 5000, 10000));
                    } catch (Exception e) {
                        q.add("");
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        }
        try {
            for (int i = 0; i < OVERPASS.length; i++) {
                String r = q.poll(12, java.util.concurrent.TimeUnit.SECONDS);
                if (r == null) return null;
                if (!r.isEmpty()) return r;
            }
        } catch (InterruptedException ignored) {
        }
        return null;
    }

    /** Daftar SPBU di sekitar posisi, diurutkan dari yang terdekat (garis lurus). Tiap isi: {lat, lon, nama, jarak meter}.
     *  Mencoba beberapa server Overpass dan memperluas radius (3 km -> 8 km -> 15 km) bila kosong. */
    static java.util.List<String[]> fuelList(double la, double lo, int max) throws Exception {
        int[] radii = {3000, 8000, 15000};
        Exception last = null;
        for (int rad : radii) {
            String q = String.format(Locale.US,
                    "[out:json][timeout:15];(node[\"amenity\"=\"fuel\"](around:%d,%.6f,%.6f);"
                            + "way[\"amenity\"=\"fuel\"](around:%d,%.6f,%.6f););out center tags;", rad, la, lo, rad, la, lo);
            String body = "data=" + URLEncoder.encode(q, "UTF-8");
            String s = raceHttp(body);                        // ketiga server ditanya bersamaan, yang tercepat dipakai
            if (s == null) {
                last = new Exception("gagal");
                continue;
            }                          // semua server gagal: coba lagi radius berikut
            JSONArray el = new JSONObject(s).getJSONArray("elements");
            java.util.ArrayList<String[]> out = new java.util.ArrayList<>();
            for (int i = 0; i < el.length(); i++) {
                JSONObject e = el.getJSONObject(i);
                double ela, elo;
                if (e.has("lat")) {
                    ela = e.getDouble("lat");
                    elo = e.getDouble("lon");
                } else if (e.has("center")) {
                    ela = e.getJSONObject("center").getDouble("lat");
                    elo = e.getJSONObject("center").getDouble("lon");
                } else continue;
                double dx = (elo - lo) * 111320.0 * Math.cos(Math.toRadians(la)), dy = (ela - la) * 110540.0;
                double d = Math.sqrt(dx * dx + dy * dy);
                JSONObject tg = e.optJSONObject("tags");
                String nm = tg == null ? "" : tg.optString("name", tg.optString("brand", ""));
                nm = clean(nm);
                if (nm.isEmpty()) nm = "SPBU";
                out.add(new String[]{String.valueOf(ela), String.valueOf(elo), nm, String.valueOf((int) d)});
            }
            if (out.isEmpty()) continue;
            java.util.Collections.sort(out, new java.util.Comparator<String[]>() {
                @Override
                public int compare(String[] x, String[] y) {
                    return Integer.compare(Integer.parseInt(x[3]), Integer.parseInt(y[3]));
                }
            });
            return new java.util.ArrayList<>(out.subList(0, Math.min(max, out.size())));
        }
        if (last != null) throw new Exception("Server peta tidak bisa dihubungi");
        throw new Exception("SPBU tidak ditemukan");
    }

    /** SPBU terdekat (garis lurus). Hasil: {lat, lon, nama, jarak meter}. */
    static String[] fuelNear(double la, double lo) throws Exception {
        return fuelList(la, lo, 1).get(0);
    }

    /** Jarak (meter) titik ke garis rute terdekat. */
    static double distToRoute(Route r, double la, double lo) {
        double kx = 111320.0 * Math.cos(Math.toRadians(la)), ky = 110540.0, best = 1e18;
        for (int i = 0; i + 1 < r.lat.length; i++) {
            double ax = (r.lon[i] - lo) * kx, ay = (r.lat[i] - la) * ky;
            double bx = (r.lon[i + 1] - lo) * kx, by = (r.lat[i + 1] - la) * ky;
            double dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
            double t = l2 < 1e-9 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / l2));
            double px = ax + t * dx, py = ay + t * dy;
            double d = Math.sqrt(px * px + py * py);
            if (d < best) best = d;
        }
        return best;
    }

    static Route parseRoute(JSONObject r) throws Exception {
        JSONArray co = r.getJSONObject("geometry").getJSONArray("coordinates");
        int n = co.length();
        if (n < 2) throw new Exception("Rute terlalu pendek");

        Route rt = new Route();
        rt.lat = new double[n];
        rt.lon = new double[n];
        rt.cum = new double[n];
        for (int i = 0; i < n; i++) {
            JSONArray c = co.getJSONArray(i);
            rt.lon[i] = c.getDouble(0);
            rt.lat[i] = c.getDouble(1);
            if (i > 0) {
                double cl = Math.cos(Math.toRadians(rt.lat[i]));
                double dx = (rt.lon[i] - rt.lon[i - 1]) * 111320.0 * cl;
                double dy = (rt.lat[i] - rt.lat[i - 1]) * 110540.0;
                rt.cum[i] = rt.cum[i - 1] + Math.sqrt(dx * dx + dy * dy);
            }
        }
        rt.totalDist = Math.max(1.0, rt.cum[n - 1]);
        rt.totalDur = r.optDouble("duration", rt.totalDist / 8.0);

        JSONArray steps = r.getJSONArray("legs").getJSONObject(0).getJSONArray("steps");
        int ns = steps.length();
        rt.nSteps = ns;
        rt.stepIdx = new int[ns];
        rt.stepDist = new double[ns];
        rt.stepType = new String[ns];
        rt.stepMod = new String[ns];
        rt.stepName = new String[ns];
        int prev = 0;
        for (int i = 0; i < ns; i++) {
            JSONObject st = steps.getJSONObject(i);
            JSONObject m = st.getJSONObject("maneuver");
            JSONArray loc = m.getJSONArray("location");
            double mlon = loc.getDouble(0), mlat = loc.getDouble(1);
            // titik rute terdekat dengan lokasi belokan (mencari ke depan saja)
            double best = 1e18;
            int bi = prev;
            for (int k = prev; k < n; k++) {
                double dx = (rt.lon[k] - mlon), dy = (rt.lat[k] - mlat);
                double d = dx * dx + dy * dy;
                if (d < best) { best = d; bi = k; }
            }
            prev = bi;
            rt.stepIdx[i] = bi;
            rt.stepDist[i] = rt.cum[bi];
            rt.stepType[i] = m.optString("type", "");
            rt.stepMod[i] = m.optString("modifier", "");
            rt.stepName[i] = clean(st.optString("name", ""));
        }
        return rt;
    }

    /** Unduh jalan di sekitar posisi (kotak sekitar 2,2 km). */
    static RoadSet roads(double la, double lo) throws Exception {
        double h = 0.010;
        String bbox = (la - h) + "," + (lo - h) + "," + (la + h) + "," + (lo + h);
        double h2 = 0.006;                                  // gang & jalan kecil: hanya area dekat (+-550 m) agar unduhan tetap ringan
        String bbox2 = (la - h2) + "," + (lo - h2) + "," + (la + h2) + "," + (lo + h2);
        String q = "[out:json][timeout:40];(way[\"highway\"~\"^(motorway|trunk|primary|secondary|tertiary|"
                + "unclassified|residential|living_street|motorway_link|trunk_link|primary_link|"
                + "secondary_link|tertiary_link)$\"](" + bbox + ");"
                + "way[\"highway\"~\"^(service|track|pedestrian|path|footway|cycleway)$\"](" + bbox2 + ");"
                + "nwr[\"amenity\"=\"fuel\"](" + bbox + ");"
                + "way[\"natural\"~\"^(water|wood|grassland|scrub)$\"](" + bbox + ");"
                + "way[\"waterway\"~\"^(river|canal|stream|drain)$\"](" + bbox + ");"
                + "way[\"leisure\"~\"^(park|garden|playground|pitch|recreation_ground|nature_reserve)$\"](" + bbox + ");"
                + "way[\"landuse\"~\"^(grass|recreation_ground|forest|meadow|village_green|cemetery|basin|reservoir)$\"](" + bbox + "););out geom qt;";
        String body = "data=" + URLEncoder.encode(q, "UTF-8");
        String s;
        try {
            s = http("https://overpass-api.de/api/interpreter", body);
        } catch (Exception e) {
            s = http("https://overpass.kumi.systems/api/interpreter", body);
        }
        JSONArray els = new JSONObject(s).getJSONArray("elements");
        RoadSet rs = new RoadSet();
        rs.cLat = la;
        rs.cLon = lo;
        for (int i = 0; i < els.length(); i++) {
            JSONObject e = els.getJSONObject(i);
            JSONObject ftg = e.optJSONObject("tags");
            if (ftg != null && "fuel".equals(ftg.optString("amenity", ""))) {       // SPBU: simpan di cache
                double fla = Double.NaN, flo = Double.NaN;
                if (e.has("lat")) {
                    fla = e.optDouble("lat");
                    flo = e.optDouble("lon");
                } else {
                    JSONArray fg = e.optJSONArray("geometry");
                    if (fg != null && fg.length() > 0) {
                        double sa = 0, so = 0;
                        for (int k = 0; k < fg.length(); k++) {
                            sa += fg.getJSONObject(k).getDouble("lat");
                            so += fg.getJSONObject(k).getDouble("lon");
                        }
                        fla = sa / fg.length();
                        flo = so / fg.length();
                    }
                }
                if (!Double.isNaN(fla) && !Double.isNaN(flo)) {
                    String fnm = clean(ftg.optString("name", ftg.optString("brand", "")));
                    rs.fuel.add(new String[]{String.valueOf(fla), String.valueOf(flo), fnm.isEmpty() ? "SPBU" : fnm});
                }
                continue;
            }
            JSONArray g = e.optJSONArray("geometry");
            if (g == null || g.length() < 2) continue;
            double[] pts = new double[g.length() * 2];
            for (int k = 0; k < g.length(); k++) {
                JSONObject p = g.getJSONObject(k);
                pts[2 * k] = p.getDouble("lat");
                pts[2 * k + 1] = p.getDouble("lon");
            }
            JSONObject tags = e.optJSONObject("tags");
            String hw = tags == null ? "" : tags.optString("highway", "");
            if (hw.isEmpty() && tags != null) {            // bukan jalan: air / taman / sungai
                String ww = tags.optString("waterway", "");
                if (!ww.isEmpty()) {
                    rs.stream.add(pts);
                    continue;
                }
                int nn = pts.length;
                boolean closed = nn >= 8 && pts[0] == pts[nn - 2] && pts[1] == pts[nn - 1];
                if (!closed) continue;                      // potongan tak tertutup tidak bisa diisi warna
                String nat = tags.optString("natural", ""), lu = tags.optString("landuse", "");
                if (nat.equals("water") || lu.equals("basin") || lu.equals("reservoir")) rs.water.add(pts);
                else rs.park.add(pts);
                continue;
            }
            if (hw.equals("service") || hw.equals("track") || hw.equals("pedestrian") || hw.equals("path")
                    || hw.equals("footway") || hw.equals("cycleway")) {
                String sv = tags.optString("service", ""), fw = tags.optString("footway", "");
                if (sv.equals("parking_aisle") || sv.equals("driveway") || sv.equals("drive-through")) continue;
                if (fw.equals("sidewalk") || fw.equals("crossing")) continue;   // trotoar & penyeberangan: terlalu ramai
                rs.alley.add(pts);
            } else if (hw.equals("residential") || hw.equals("unclassified") || hw.equals("living_street")) {
                rs.minor.add(pts);
            } else {
                rs.major.add(pts);
            }
        }
        return rs;
    }

    /** Lalu lintas di satu titik (TomTom Flow Segment). Hasil: kecepatan sekarang / kecepatan lancar, atau -1 bila gagal. */
    static double traffic(double la, double lo, String key) throws Exception {
        String url = String.format(Locale.US,
                "https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json?point=%.6f,%.6f&unit=KMPH&key=%s",
                la, lo, URLEncoder.encode(key, "UTF-8"));
        JSONObject f = new JSONObject(http(url, null)).getJSONObject("flowSegmentData");
        if (f.optBoolean("roadClosure", false)) return 0.0;
        double cur = f.optDouble("currentSpeed", -1), free = f.optDouble("freeFlowSpeed", -1);
        if (cur < 0 || free <= 0) return -1;
        return Math.min(1.0, cur / free);
    }

    /** Bersihkan teks agar aman ditampilkan di OLED (ASCII, maks 23 karakter). */
    static String clean(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < 23; i++) {
            char ch = s.charAt(i);
            sb.append((ch >= 32 && ch < 127) ? ch : '?');
        }
        return sb.toString();
    }
}
