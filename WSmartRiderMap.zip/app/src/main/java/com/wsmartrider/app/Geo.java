package com.wsmartrider.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

/** Semua akses internet: pencarian tujuan, rute, dan data jalan. */
final class Geo {
    private static final String UA = "WSmartRiderMap/1.0 (ESP32 hobby navigation)";

    static String http(String urlStr, String postBody) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "application/json");
        if (postBody != null) {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            OutputStream os = c.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.close();
        }
        int code = c.getResponseCode();
        if (code != 200) {
            c.disconnect();
            throw new IOException("HTTP " + code);
        }
        InputStream in = c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
        in.close();
        c.disconnect();
        return bo.toString("UTF-8");
    }

    /** Cari koordinat tujuan. Hasil: {lat, lon}. */
    static double[] geocode(String q, double la, double lo) throws Exception {
        String vb = (lo - 0.6) + "," + (la + 0.6) + "," + (lo + 0.6) + "," + (la - 0.6);
        String url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&viewbox=" + vb
                + "&q=" + URLEncoder.encode(q, "UTF-8");
        JSONArray a = new JSONArray(http(url, null));
        if (a.length() == 0) throw new Exception("Tujuan tidak ditemukan");
        JSONObject o = a.getJSONObject(0);
        return new double[]{Double.parseDouble(o.getString("lat")), Double.parseDouble(o.getString("lon"))};
    }

    /** Hitung rute mobil/motor dengan OSRM. */
    static Route route(double la, double lo, double dla, double dlo) throws Exception {
        String url = String.format(Locale.US,
                "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f"
                        + "?overview=full&geometries=geojson&steps=true", lo, la, dlo, dla);
        JSONObject root = new JSONObject(http(url, null));
        if (!"Ok".equals(root.optString("code"))) throw new Exception("Rute tidak ditemukan");
        JSONObject r = root.getJSONArray("routes").getJSONObject(0);
        JSONArray co = r.getJSONObject("geometry").getJSONArray("coordinates");
        int n = co.length();
        if (n < 2) throw new Exception("Rute terlalu pendek");

        Route rt = new Route();
        rt.lat = new double[n];
        rt.lon = new double[n];
        rt.cum = new double[n];
        for (int i = 0; i < n; i++) {
            JSONArray c = co.getJSONArray(i);
            rt.lon[i] = c.getDouble(0);
            rt.lat[i] = c.getDouble(1);
            if (i > 0) {
                double cl = Math.cos(Math.toRadians(rt.lat[i]));
                double dx = (rt.lon[i] - rt.lon[i - 1]) * 111320.0 * cl;
                double dy = (rt.lat[i] - rt.lat[i - 1]) * 110540.0;
                rt.cum[i] = rt.cum[i - 1] + Math.sqrt(dx * dx + dy * dy);
            }
        }
        rt.totalDist = Math.max(1.0, rt.cum[n - 1]);
        rt.totalDur = r.optDouble("duration", rt.totalDist / 8.0);

        JSONArray steps = r.getJSONArray("legs").getJSONObject(0).getJSONArray("steps");
        int ns = steps.length();
        rt.nSteps = ns;
        rt.stepIdx = new int[ns];
        rt.stepDist = new double[ns];
        rt.stepType = new String[ns];
        rt.stepMod = new String[ns];
        rt.stepName = new String[ns];
        int prev = 0;
        for (int i = 0; i < ns; i++) {
            JSONObject st = steps.getJSONObject(i);
            JSONObject m = st.getJSONObject("maneuver");
            JSONArray loc = m.getJSONArray("location");
            double mlon = loc.getDouble(0), mlat = loc.getDouble(1);
            // titik rute terdekat dengan lokasi belokan (mencari ke depan saja)
            double best = 1e18;
            int bi = prev;
            for (int k = prev; k < n; k++) {
                double dx = (rt.lon[k] - mlon), dy = (rt.lat[k] - mlat);
                double d = dx * dx + dy * dy;
                if (d < best) { best = d; bi = k; }
            }
            prev = bi;
            rt.stepIdx[i] = bi;
            rt.stepDist[i] = rt.cum[bi];
            rt.stepType[i] = m.optString("type", "");
            rt.stepMod[i] = m.optString("modifier", "");
            rt.stepName[i] = clean(st.optString("name", ""));
        }
        return rt;
    }

    /** Unduh jalan di sekitar posisi (kotak sekitar 2,2 km). */
    static RoadSet roads(double la, double lo) throws Exception {
        double h = 0.010;
        String bbox = (la - h) + "," + (lo - h) + "," + (la + h) + "," + (lo + h);
        double h2 = 0.005;                                  // gang & jalan kecil: hanya area dekat (+-550 m) agar unduhan tetap ringan
        String bbox2 = (la - h2) + "," + (lo - h2) + "," + (la + h2) + "," + (lo + h2);
        String q = "[out:json][timeout:25];(way[\"highway\"~\"^(motorway|trunk|primary|secondary|tertiary|"
                + "unclassified|residential|living_street|motorway_link|trunk_link|primary_link|"
                + "secondary_link|tertiary_link)$\"](" + bbox + ");"
                + "way[\"highway\"~\"^(service|track|pedestrian|path|footway|cycleway)$\"](" + bbox2 + "););out geom qt;";
        String body = "data=" + URLEncoder.encode(q, "UTF-8");
        String s;
        try {
            s = http("https://overpass-api.de/api/interpreter", body);
        } catch (Exception e) {
            s = http("https://overpass.kumi.systems/api/interpreter", body);
        }
        JSONArray els = new JSONObject(s).getJSONArray("elements");
        RoadSet rs = new RoadSet();
        rs.cLat = la;
        rs.cLon = lo;
        for (int i = 0; i < els.length(); i++) {
            JSONObject e = els.getJSONObject(i);
            JSONArray g = e.optJSONArray("geometry");
            if (g == null || g.length() < 2) continue;
            double[] pts = new double[g.length() * 2];
            for (int k = 0; k < g.length(); k++) {
                JSONObject p = g.getJSONObject(k);
                pts[2 * k] = p.getDouble("lat");
                pts[2 * k + 1] = p.getDouble("lon");
            }
            JSONObject tags = e.optJSONObject("tags");
            String hw = tags == null ? "" : tags.optString("highway", "");
            if (hw.equals("service") || hw.equals("track") || hw.equals("pedestrian") || hw.equals("path")
                    || hw.equals("footway") || hw.equals("cycleway")) {
                String sv = tags.optString("service", ""), fw = tags.optString("footway", "");
                if (sv.equals("parking_aisle") || sv.equals("driveway") || sv.equals("drive-through")) continue;
                if (fw.equals("sidewalk") || fw.equals("crossing")) continue;   // trotoar & penyeberangan: terlalu ramai
                rs.alley.add(pts);
            } else if (hw.equals("residential") || hw.equals("unclassified") || hw.equals("living_street")) {
                rs.minor.add(pts);
            } else {
                rs.major.add(pts);
            }
        }
        return rs;
    }

    /** Bersihkan teks agar aman ditampilkan di OLED (ASCII, maks 23 karakter). */
    static String clean(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < 23; i++) {
            char ch = s.charAt(i);
            sb.append((ch >= 32 && ch < 127) ? ch : '?');
        }
        return sb.toString();
    }
}
