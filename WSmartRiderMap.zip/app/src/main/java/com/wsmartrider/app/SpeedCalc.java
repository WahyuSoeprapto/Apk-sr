package com.wsmartrider.app;

import android.location.Location;

/**
 * Kecepatan dari GPS. Memakai kecepatan yang dilaporkan GPS bila ada; bila tidak ada
 * (misalnya aplikasi fake GPS yang hanya mengubah koordinat), kecepatan dihitung dari
 * jarak antar titik dibagi waktunya.
 */
final class SpeedCalc {
    private static Location anchor;
    private static long anchorAt = 0;
    private static double derived = 0;     // km/jam dari perpindahan antar titik
    private static long derivedAt = 0;

    private SpeedCalc() {
    }

    static synchronized void feed(Location l) {
        if (l == null) return;
        long now = System.currentTimeMillis();
        if (anchor == null) {
            anchor = l;
            anchorAt = now;
            return;
        }
        double dt = (now - anchorAt) / 1000.0;
        if (dt < 0.4) return;                                   // pembaruan terlalu rapat / titik yang sama
        float d = anchor.distanceTo(l);
        double acc = l.hasAccuracy() ? l.getAccuracy() : 0;
        double thr = Math.max(3.0, acc);                        // perpindahan di bawah derau GPS dianggap diam
        if (dt > 15 || d > 1000) {                              // titik melompat atau terlalu lama: mulai ulang
            derived = 0;
            derivedAt = now;
            anchor = l;
            anchorAt = now;
        } else if (d >= thr) {
            double v = d / dt * 3.6;
            derived = derived * 0.4 + v * 0.6;                  // haluskan
            derivedAt = now;
            anchor = l;
            anchorAt = now;
        } else if (dt > 4) {                                    // lama tidak bergerak = diam
            derived = 0;
            derivedAt = now;
            anchor = l;
            anchorAt = now;
        }
    }

    /** Kecepatan dalam km/jam. */
    static synchronized double kmh(Location l) {
        double rep = (l != null && l.hasSpeed()) ? l.getSpeed() * 3.6 : 0;
        if (rep >= 1.0) return rep;
        long now = System.currentTimeMillis();
        double der = (now - derivedAt < 6000L && derived >= 1.0) ? derived : 0;
        return der;
    }
}
