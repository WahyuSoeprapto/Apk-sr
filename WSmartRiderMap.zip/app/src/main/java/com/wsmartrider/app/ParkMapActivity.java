package com.wsmartrider.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Peta lokasi parkir motor di HP: tanda motor, posisimu sekarang, jarak dan arah. */
public class ParkMapActivity extends Activity {
    private double pLat, pLon;
    private long pTime;
    private WebView wv;
    private TextView tv;
    private LocationManager lm;
    private boolean pageReady = false;
    private Location lastLoc = null;

    private final LocationListener listener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            onFix(l);
        }

        @Override
        public void onProviderEnabled(String p) {
        }

        @Override
        public void onProviderDisabled(String p) {
        }

        @Override
        public void onStatusChanged(String p, int s, Bundle b) {
        }
    };

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "<html><body>Gagal memuat peta</body></html>";
        }
    }

    private static String compass(double deg) {
        String[] n = {"Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut"};
        return n[(int) (((deg % 360 + 360) % 360 + 22.5) / 45) % 8];
    }

    private void onFix(Location l) {
        if (l == null) return;
        lastLoc = l;
        float[] r = new float[1];
        Location.distanceBetween(l.getLatitude(), l.getLongitude(), pLat, pLon, r);
        Location target = new Location("park");
        target.setLatitude(pLat);
        target.setLongitude(pLon);
        String dist = r[0] >= 1000 ? String.format(Locale.US, "%.1f km", r[0] / 1000f) : String.format(Locale.US, "%.0f m", r[0]);
        String info = "Motor " + dist + " ke arah " + compass(l.bearingTo(target)) + "\nDiparkir " +
                new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new Date(pTime));
        tv.setText(info);
        if (pageReady) wv.evaluateJavascript(String.format(Locale.US, "setMe(%.6f,%.6f)", l.getLatitude(), l.getLongitude()), null);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        pLat = in.getDoubleExtra("lat", -6.2);
        pLon = in.getDoubleExtra("lon", 106.8);
        pTime = in.getLongExtra("time", System.currentTimeMillis());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        wv = new WebView(this);
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        wv.setWebChromeClient(new WebChromeClient());
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (lastLoc != null) onFix(lastLoc);
            }
        });
        root.addView(wv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        tv = new TextView(this);
        tv.setText("Mencari posisimu...");
        tv.setTextSize(16f);
        tv.setPadding(24, 16, 24, 8);
        root.addView(tv);

        Button walk = new Button(this);
        walk.setText("Jalan kaki ke motor (Google Maps)");
        walk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.US,
                            "google.navigation:q=%.6f,%.6f&mode=w", pLat, pLon)));
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.US,
                                "geo:%.6f,%.6f?q=%.6f,%.6f(Motor)", pLat, pLon, pLat, pLon))));
                    } catch (Exception e2) {
                        Toast.makeText(ParkMapActivity.this, "Tidak ada aplikasi peta", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        root.addView(walk);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button toMoto = new Button(this);
        toMoto.setText("Ke motor");
        toMoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wv.evaluateJavascript("centerMoto()", null);
            }
        });
        Button toMe = new Button(this);
        toMe.setText("Posisiku");
        toMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wv.evaluateJavascript("centerMe()", null);
            }
        });
        Button close = new Button(this);
        close.setText("Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        row.addView(toMoto, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(toMe, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(close, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        String html = readAsset("park.html")
                .replace("__PLAT__", String.valueOf(pLat))
                .replace("__PLON__", String.valueOf(pLon));
        wv.loadDataWithBaseURL("https://wsmartrider.local/", html, "text/html", "UTF-8", null);

        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null) {
                lastLoc = l;
                onFix(l);
            }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, listener);
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 4000, 0, listener);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            lm.removeUpdates(listener);
        } catch (Exception ignored) {
        }
    }
}
