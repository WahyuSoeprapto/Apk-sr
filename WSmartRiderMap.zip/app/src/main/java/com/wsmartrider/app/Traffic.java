package com.wsmartrider.app;

/** Kepadatan lalu lintas di depan sepanjang rute (dari TomTom). Jarak = jarak kumulatif rute (meter). */
final class Traffic {
    double[] from, to;   // potongan rute
    float[] ratio;       // kecepatan sekarang / kecepatan lancar (0 = macet total, 1 = lancar)
}
