package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Screen Mirror: merekam layar HP lewat MediaProjection, diubah menjadi gambar hitam-putih
 * 128x64 (dithering) lalu dikirim ke W-Smart Rider lewat NavService (Bluetooth / Wi-Fi).
 */
public class MirrorService extends Service {
    static volatile boolean running = false;
    static volatile int fps = 0;
    static volatile String info = "";
    static volatile int fitMode = 0;   // 0 = utuh (seluruh layar HP), 1 = lebar (potong atas-bawah)
    static volatile int cropPos = 1;   // untuk mode lebar: 0 = atas, 1 = tengah, 2 = bawah

    private static final int W = 128, H = 64;
    private static final long MIN_GAP_MS = 180;      // sekitar 5 gambar per detik
    private static final long KEEPALIVE_MS = 1200;   // kirim ulang walau tidak berubah (layar dianggap basi setelah 4 detik)

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler h;
    private int cw = 0, ch = 0, dpi = 320;
    private boolean down = false;
    private boolean invert = false;
    private long lastProc = 0, lastSent = 0, lastSizeCheck = 0, fpsT = 0;
    private int fpsCount = 0;
    private byte[] lastFrame = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            shutdown();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        startAsForeground();   // wajib sebelum getMediaProjection (Android 14+)

        Intent data = intent == null ? null : (Intent) intent.getParcelableExtra("data");
        int code = intent == null ? 0 : intent.getIntExtra("code", 0);
        if (data == null || !NavService.active) {
            info = NavService.active ? "Izin rekam layar tidak valid" : "Tekan Mulai dulu";
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            if (projection == null) throw new IllegalStateException("projection null");

            ht = new HandlerThread("wsr-mirror");
            ht.start();
            h = new Handler(ht.getLooper());

            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    if (h != null) h.post(new Runnable() {
                        @Override
                        public void run() {
                            shutdown();
                            stopSelf();
                        }
                    });
                }
            }, h);

            DisplayMetrics dm = realMetrics();
            dpi = dm.densityDpi;
            int[] sz = calcSize(dm);
            cw = sz[0];
            ch = sz[1];
            reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(imgListener, h);
            vd = projection.createVirtualDisplay("wsr-mirror", cw, ch, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);

            running = true;
            NavService.mirrorOn = true;
            info = "Menyiapkan...";
        } catch (Throwable e) {
            info = "Gagal memulai: " + e.getMessage();
            shutdown();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("mirror", "Screen Mirror", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, MirrorService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "mirror")
                .setContentTitle("W-Smart Rider")
                .setContentText("Screen Mirror aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(2, n);
        }
    }

    private DisplayMetrics realMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    /** Ukuran tangkapan diperkecil (sisi terpanjang maksimal 640 px) agar ringan. */
    private static int[] calcSize(DisplayMetrics dm) {
        float k = Math.min(1f, 640f / Math.max(dm.widthPixels, dm.heightPixels));
        return new int[]{Math.max(64, Math.round(dm.widthPixels * k)), Math.max(64, Math.round(dm.heightPixels * k))};
    }

    private final ImageReader.OnImageAvailableListener imgListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader r) {
            Image img = null;
            byte[] frame = null;
            try {
                img = r.acquireLatestImage();
                if (img == null) return;
                long now = SystemClock.uptimeMillis();
                if (now - lastProc < MIN_GAP_MS) return;
                lastProc = now;
                frame = convert(img);
            } catch (Throwable e) {
                info = "Error: " + e.getMessage();
            } finally {
                if (img != null) img.close();
            }
            if (down) return;
            if (!NavService.active) {            // koneksi utama dihentikan -> mirror ikut berhenti
                shutdown();
                stopSelf();
                return;
            }
            if (frame != null) deliver(frame);
            long now2 = SystemClock.uptimeMillis();
            if (now2 - lastSizeCheck > 1000) {
                lastSizeCheck = now2;
                checkResize();
            }
        }
    };

    private void deliver(byte[] frame) {
        long now = SystemClock.uptimeMillis();
        boolean same = lastFrame != null && Arrays.equals(lastFrame, frame);
        if (same && now - lastSent < KEEPALIVE_MS) return;
        if (NavService.pushMirror(frame)) {
            lastFrame = frame;
            lastSent = now;
            fpsCount++;
        }
        if (now - fpsT >= 1000) {
            fps = fpsCount;
            fpsCount = 0;
            fpsT = now;
            info = NavService.espIp == null ? "Menunggu W-Smart Rider terhubung..." : "Aktif (" + fps + " gambar/detik)";
        }
    }

    /** Putar layar HP: sesuaikan ukuran tangkapan. */
    private void checkResize() {
        try {
            DisplayMetrics dm = realMetrics();
            int[] sz = calcSize(dm);
            if (sz[0] == cw && sz[1] == ch) return;
            ImageReader nr = ImageReader.newInstance(sz[0], sz[1], PixelFormat.RGBA_8888, 2);
            nr.setOnImageAvailableListener(imgListener, h);
            vd.resize(sz[0], sz[1], dm.densityDpi);
            vd.setSurface(nr.getSurface());
            ImageReader old = reader;
            reader = nr;
            cw = sz[0];
            ch = sz[1];
            if (old != null) old.close();
        } catch (Throwable ignored) {
        }
    }

    /** RGBA layar HP -> bitmap 1 bit 128x64 (format XBM, bit paling kiri = bit 0). */
    private byte[] convert(Image img) {
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer buf = pl.getBuffer();
        int ps = pl.getPixelStride();
        int rs = pl.getRowStride();
        int w = img.getWidth(), hh = img.getHeight();

        // area sumber (sx, sy, sw, sh) dan area tujuan (dx, dy, dw, dh) di 128x64
        int sx = 0, sy = 0, sw = w, sh = hh;
        int dx = 0, dy = 0, dw = W, dh = H;
        if (fitMode == 1) {                                  // lebar: potong ke rasio 2:1
            if (w >= 2 * hh) {
                sw = 2 * hh;
                sx = (w - sw) / 2;
            } else {
                sh = w / 2;
                int pos = cropPos;
                sy = pos == 0 ? 0 : (pos == 2 ? hh - sh : (hh - sh) / 2);
            }
        } else {                                             // utuh: seluruh layar, letterbox
            float k = Math.min((float) W / w, (float) H / hh);
            dw = Math.max(1, Math.round(w * k));
            dh = Math.max(1, Math.round(hh * k));
            dx = (W - dw) / 2;
            dy = (H - dh) / 2;
        }

        int nsx = Math.max(1, Math.min(4, Math.round((float) sw / dw)));
        int nsy = Math.max(1, Math.min(4, Math.round((float) sh / dh)));
        float[] lum = new float[W * H];
        double sum = 0;
        for (int y = 0; y < dh; y++) {
            for (int x = 0; x < dw; x++) {
                int acc = 0, cnt = 0;
                for (int j = 0; j < nsy; j++) {
                    int py = sy + (int) ((y + (j + 0.5f) / nsy) * sh / dh);
                    if (py >= hh) py = hh - 1;
                    for (int i = 0; i < nsx; i++) {
                        int px = sx + (int) ((x + (i + 0.5f) / nsx) * sw / dw);
                        if (px >= w) px = w - 1;
                        int o = py * rs + px * ps;
                        int r = buf.get(o) & 0xFF, g = buf.get(o + 1) & 0xFF, b = buf.get(o + 2) & 0xFF;
                        acc += (r * 77 + g * 150 + b * 29) >> 8;
                        cnt++;
                    }
                }
                float v = (float) acc / cnt;
                lum[(dy + y) * W + dx + x] = v;
                sum += v;
            }
        }
        double mean = sum / (dw * dh);
        if (!invert && mean > 165) invert = true;           // tema terang -> dibalik agar tidak terlalu menyala
        else if (invert && mean < 120) invert = false;

        // kontras + pembalikan hanya di area gambar (bingkai hitam tetap hitam)
        for (int y = 0; y < dh; y++) {
            for (int x = 0; x < dw; x++) {
                int idx = (dy + y) * W + dx + x;
                float v = lum[idx];
                if (invert) v = 255f - v;
                v = (v - 36f) * (255f / (220f - 36f));
                lum[idx] = v < 0 ? 0 : (v > 255 ? 255 : v);
            }
        }

        // dithering Floyd-Steinberg
        byte[] out = new byte[W * H / 8];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int idx = y * W + x;
                float old = lum[idx];
                float nv = old >= 128f ? 255f : 0f;
                float err = old - nv;
                if (nv > 0) out[y * (W / 8) + (x >> 3)] |= (byte) (1 << (x & 7));
                if (x + 1 < W) lum[idx + 1] += err * 0.4375f;
                if (y + 1 < H) {
                    if (x > 0) lum[idx + W - 1] += err * 0.1875f;
                    lum[idx + W] += err * 0.3125f;
                    if (x + 1 < W) lum[idx + W + 1] += err * 0.0625f;
                }
            }
        }
        return out;
    }

    private synchronized void shutdown() {
        if (down) return;
        down = true;
        running = false;
        NavService.mirrorOn = false;
        fps = 0;
        if (info == null || info.startsWith("Aktif") || info.startsWith("Menunggu") || info.startsWith("Menyiapkan")) {
            info = "";
        }
        try {
            if (vd != null) vd.release();
        } catch (Throwable ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Throwable ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Throwable ignored) {
        }
        try {
            if (ht != null) ht.quitSafely();
        } catch (Throwable ignored) {
        }
        vd = null;
        reader = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }
}
