package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Display;

import java.nio.ByteBuffer;

/**
 * Screen Mirror: menangkap layar HP, mengubahnya menjadi 128x64 hitam-putih (XBM, 1024 byte)
 * lalu mengirimnya ke W-Smart Rider lewat jalur yang sama dengan peta (flag bit2 = Screen Mirror).
 */
public class MirrorService extends Service {
    static volatile boolean active = false;
    static volatile String status = "Mati";
    static volatile int fps = 0;

    /** 0 = pas (seluruh layar, ada bidang hitam), 1 = potong tengah (isi penuh), 2 = regang (isi penuh, bentuk melar). */
    static volatile int fit = 0;
    static volatile boolean invert = false;
    /** 0 = Tajam (teks & ikon jelas, tanpa bintik), 1 = Foto (dithering halus untuk gambar/foto). */
    static volatile int quality = 0;
    /** Kirim gambar berwarna 120x120 (untuk layar TFT W-Smart Rider). Hanya lewat Bluetooth; selain itu otomatis hitam-putih. */
    static volatile boolean color = false;
    /** Bagian layar HP yang diambil pada bentuk "Potong": 0 = atas (kiri), 1 = tengah, 2 = bawah (kanan). */
    static volatile int pos = 1;
    /** Sisi gambar warna: 120 (cepat) atau 160 (tajam). */
    static volatile int colorSize = 160;

    private static final int HDR = 60, FRAME = 1024;
    private static final int MAX_SIDE = 1024;           // sisi terpanjang gambar tangkapan
    private static final long MIN_GAP = 130L;          // ~7 gambar per detik
    private static final int[][] BAYER = {
            {0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};

    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader ir;
    private HandlerThread ht;
    private Handler h;
    private int capW, capH, dpi, phoneW, phoneH;
    private long lastSend = 0, fpsT = 0;
    private int fpsN = 0;
    private byte[] lastPkt;
    private byte[] buf = new byte[0];
    private final int[] gray = new int[128 * 64];
    private final int[] enh = new int[128 * 64];
    private final int[] integ = new int[129 * 65];

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || !intent.hasExtra("data")) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (active) return START_NOT_STICKY;

        try {
            startAsForeground();
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            ht = new HandlerThread("wsr-mirror");
            ht.start();
            h = new Handler(ht.getLooper());
            mp = m.getMediaProjection(code, data);
            if (mp == null) throw new IllegalStateException("izin ditolak");
            mp.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            }, h);
            measure();
            ir = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
            ir.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    onFrame(r);
                }
            }, h);
            vd = mp.createVirtualDisplay("wsr-mirror", capW, capH, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.getSurface(), null, h);
            active = true;
            status = "Aktif";
            h.postDelayed(watch, 1000);
        } catch (Throwable e) {
            status = "Gagal: " + e.getMessage();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("mirror", "Screen Mirror", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, MirrorService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "mirror")
                .setContentTitle("W-Smart Rider")
                .setContentText("Screen Mirror aktif")
                .setSmallIcon(android.R.drawable.ic_menu_slideshow)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(3, n);
        }
    }

    /** Ukuran layar HP saat ini -> ukuran gambar tangkapan (bentuk layar tetap). */
    private void measure() {
        DisplayMetrics dm = new DisplayMetrics();
        DisplayManager dmg = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display d = dmg.getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealMetrics(dm);
        phoneW = Math.max(2, dm.widthPixels);
        phoneH = Math.max(2, dm.heightPixels);
        dpi = dm.densityDpi;
        float sc = Math.min(1f, MAX_SIDE / (float) Math.max(phoneW, phoneH));
        capW = Math.max(16, Math.round(phoneW * sc));
        capH = Math.max(16, Math.round(phoneH * sc));
    }

    /** Tiap detik: kirim ulang frame terakhir (layar diam tidak menghasilkan gambar baru) dan cek putar layar. */
    private final Runnable watch = new Runnable() {
        @Override
        public void run() {
            if (!active) return;
            try {
                int ow = phoneW, oh = phoneH;
                measure();
                if (ow != phoneW || oh != phoneH) reconfigure();
                long now = System.currentTimeMillis();
                if (now - lastSend > (colorActive() ? 2000L : 1000L) && lastPkt != null) push(lastPkt);
                if (now - fpsT >= 1000L) {
                    fps = fpsN;
                    fpsN = 0;
                    fpsT = now;
                }
            } catch (Throwable ignored) {
            }
            if (h != null) h.postDelayed(this, 1000);
        }
    };

    private void reconfigure() {
        ImageReader old = ir;
        ImageReader nr = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        nr.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader r) {
                onFrame(r);
            }
        }, h);
        ir = nr;
        if (vd != null) {
            vd.resize(capW, capH, dpi);
            vd.setSurface(nr.getSurface());
        }
        if (old != null) old.close();
    }

    private void push(byte[] pkt) {
        NavService n = NavService.inst;
        if (n != null && n.pushMirror(pkt)) lastSend = System.currentTimeMillis();
    }

    private void onFrame(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long now = System.currentTimeMillis();
            boolean col = colorActive();
            if (now - lastSend < (col ? 220L : MIN_GAP)) return;
            byte[] pkt = col ? convertColor(img) : convert(img);
            lastPkt = pkt;
            push(pkt);
            fpsN++;
        } catch (Throwable ignored) {
        } finally {
            if (img != null) img.close();
        }
    }

    private boolean colorActive() {
        NavService n = NavService.inst;
        return color && n != null && n.colorOk();
    }

    /** Gambar RGBA -> paket "MP" berisi frame warna cw x cw (RGB332, flags = 4 | 8, byte 3 = cw). */
    private byte[] convertColor(Image img) {
        final int cw = colorSize <= 120 ? 120 : 160;
        final int w = img.getWidth(), hh = img.getHeight();
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer bb = pl.getBuffer();
        final int rs = pl.getRowStride();
        final int ps = pl.getPixelStride();
        int need = bb.remaining();
        if (buf.length < need) buf = new byte[need];
        bb.get(buf, 0, need);

        float sx = 0, sy = 0, sw = w, sh = hh;
        int dx = 0, dy = 0, dw = cw, dh = cw;
        int mode = fit;
        final int ps2 = pos;                   // 0 atas, 1 tengah, 2 bawah
        if (mode == 0) {                       // pas: seluruh layar HP, sisanya hitam
            float sc = Math.min((float) cw / w, (float) cw / hh);
            dw = Math.max(1, Math.round(w * sc));
            dh = Math.max(1, Math.round(hh * sc));
            dx = (cw - dw) / 2;
            dy = (cw - dh) / 2;
        } else if (mode == 1) {                // potong: bujur sangkar dari layar HP, posisi atas / tengah / bawah
            if (w >= hh) {
                sw = hh;
                sx = (w - sw) * ps2 / 2f;
            } else {
                sh = w;
                sy = (hh - sh) * ps2 / 2f;
            }
        }

        // 1) rata-rata luas -> r,g,b per piksel
        int[] R = new int[cw * cw], G = new int[cw * cw], B = new int[cw * cw];
        boolean[] has = new boolean[cw * cw];
        for (int y = 0; y < dh; y++) {
            int y0 = (int) (sy + y * sh / dh);
            int y1 = Math.max(y0 + 1, (int) (sy + (y + 1) * sh / dh));
            if (y1 > hh) y1 = hh;
            for (int x = 0; x < dw; x++) {
                int x0 = (int) (sx + x * sw / dw);
                int x1 = Math.max(x0 + 1, (int) (sx + (x + 1) * sw / dw));
                if (x1 > w) x1 = w;
                int sr = 0, sg = 0, sb = 0, n = 0;
                for (int yy = y0; yy < y1; yy++) {
                    int row = yy * rs;
                    for (int xx = x0; xx < x1; xx++) {
                        int o = row + xx * ps;
                        if (o + 2 >= buf.length) continue;
                        sr += buf[o] & 0xFF;
                        sg += buf[o + 1] & 0xFF;
                        sb += buf[o + 2] & 0xFF;
                        n++;
                    }
                }
                if (n == 0) continue;
                int i = (dy + y) * cw + dx + x;
                R[i] = sr / n;
                G[i] = sg / n;
                B[i] = sb / n;
                has[i] = true;
            }
        }

        // 2) pertajam (unsharp mask 3x3) supaya teks dan garis jalan tidak buram, lalu 3) kuantisasi RGB332
        byte[] pkt = new byte[HDR + cw * cw];
        pkt[0] = 'M';
        pkt[1] = 'P';
        pkt[2] = 4 | 8;                        // bit2 = Screen Mirror, bit3 = gambar warna
        pkt[3] = (byte) cw;                    // sisi gambar
        for (int y = 0; y < cw; y++) {
            for (int x = 0; x < cw; x++) {
                int i = y * cw + x;
                if (!has[i]) continue;
                int sr = 0, sg = 0, sb = 0, n = 0;
                for (int j = -1; j <= 1; j++) {
                    int yy = y + j;
                    if (yy < 0 || yy >= cw) continue;
                    for (int k = -1; k <= 1; k++) {
                        int xx = x + k;
                        if (xx < 0 || xx >= cw) continue;
                        int q = yy * cw + xx;
                        sr += R[q];
                        sg += G[q];
                        sb += B[q];
                        n++;
                    }
                }
                int r = R[i] + (R[i] - sr / n) * 3 / 4;
                int g = G[i] + (G[i] - sg / n) * 3 / 4;
                int b = B[i] + (B[i] - sb / n) * 3 / 4;
                r = Math.max(0, Math.min(255, r + 16));
                g = Math.max(0, Math.min(255, g + 16));
                b = Math.max(0, Math.min(255, b + 32));
                pkt[HDR + i] = (byte) (((r >> 5) << 5) | ((g >> 5) << 2) | (b >> 6));
            }
        }
        return pkt;
    }

    /** Gambar RGBA -> paket "MP" berisi frame 128x64 (XBM). */
    private byte[] convert(Image img) {
        final int w = img.getWidth(), hh = img.getHeight();
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer bb = pl.getBuffer();
        final int rs = pl.getRowStride();
        final int ps = pl.getPixelStride();
        int need = bb.remaining();
        if (buf.length < need) buf = new byte[need];
        bb.get(buf, 0, need);

        // sumber (sx,sy,sw,sh) -> tujuan (dx,dy,dw,dh) pada layar 128x64
        float sx = 0, sy = 0, sw = w, sh = hh;
        int dx = 0, dy = 0, dw = 128, dh = 64;
        int mode = fit;
        if (mode == 0) {
            float sc = Math.min(128f / w, 64f / hh);
            dw = Math.max(1, Math.round(w * sc));
            dh = Math.max(1, Math.round(hh * sc));
            dx = (128 - dw) / 2;
            dy = (64 - dh) / 2;
        } else if (mode == 1) {
            final int ps2 = pos;               // 0 atas, 1 tengah, 2 bawah
            if (w >= 2f * hh) {
                sw = 2f * hh;
                sx = (w - sw) * ps2 / 2f;
            } else {
                sh = w / 2f;
                sy = (hh - sh) * ps2 / 2f;
            }
        }

        java.util.Arrays.fill(gray, -1);   // -1 = di luar gambar (tetap hitam)
        for (int y = 0; y < dh; y++) {
            int y0 = (int) (sy + y * sh / dh);
            int y1 = Math.max(y0 + 1, (int) (sy + (y + 1) * sh / dh));
            if (y1 > hh) y1 = hh;
            for (int x = 0; x < dw; x++) {
                int x0 = (int) (sx + x * sw / dw);
                int x1 = Math.max(x0 + 1, (int) (sx + (x + 1) * sw / dw));
                if (x1 > w) x1 = w;
                int sum = 0, n = 0;
                for (int yy = y0; yy < y1; yy++) {
                    int row = yy * rs;
                    for (int xx = x0; xx < x1; xx++) {
                        int o = row + xx * ps;
                        if (o + 2 >= buf.length) continue;
                        int rr = buf[o] & 0xFF, gg = buf[o + 1] & 0xFF, bl = buf[o + 2] & 0xFF;
                        sum += (77 * rr + 150 * gg + 29 * bl) >> 8;
                        n++;
                    }
                }
                gray[(dy + y) * 128 + dx + x] = n == 0 ? 0 : sum / n;
            }
        }

        enhance();

        byte[] pkt = new byte[HDR + FRAME];
        pkt[0] = 'M';
        pkt[1] = 'P';
        pkt[2] = 4;                       // bit2 = frame Screen Mirror
        final boolean inv = invert;
        final boolean sharp = quality == 0;
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 128; x++) {
                int i = y * 128 + x;
                if (gray[i] < 0) continue;   // bidang kosong: hitam
                int g = enh[i];
                boolean on;
                if (sharp) {
                    // Tajam: bandingkan dengan rata-rata sekitar. Area datar -> penuh putih / penuh hitam (tanpa bintik),
                    // tepi huruf / ikon -> tegas.
                    int mean = localMean(x, y);
                    int d = g - mean;
                    if (d > 14) on = true;
                    else if (d < -14) on = false;
                    else on = g > 128;
                } else {
                    int thr = BAYER[y & 3][x & 3] * 16 + 8;
                    on = g > thr;
                }
                if (inv) on = !on;
                if (on) pkt[HDR + y * 16 + (x >> 3)] |= (byte) (1 << (x & 7));
            }
        }
        return pkt;
    }

    /** Regangkan kontras (persentil 2%-98%) lalu pertajam tepi (unsharp mask 3x3) -> enh[]; juga siapkan integral image. */
    private void enhance() {
        int[] hist = new int[256];
        int cnt = 0;
        for (int i = 0; i < gray.length; i++) {
            int g = gray[i];
            if (g < 0) continue;
            hist[g > 255 ? 255 : g]++;
            cnt++;
        }
        int lo = 0, hi = 255;
        if (cnt > 0) {
            int acc = 0, cut = Math.max(1, cnt / 50);
            for (int v = 0; v < 256; v++) {
                acc += hist[v];
                if (acc >= cut) { lo = v; break; }
            }
            acc = 0;
            for (int v = 255; v >= 0; v--) {
                acc += hist[v];
                if (acc >= cut) { hi = v; break; }
            }
        }
        if (hi - lo < 40) {               // layar hampir rata: jangan perbesar noise
            int mid = (hi + lo) / 2;
            lo = Math.max(0, mid - 20);
            hi = Math.min(255, mid + 20);
        }
        final int range = Math.max(1, hi - lo);
        for (int i = 0; i < gray.length; i++) {
            int g = gray[i];
            if (g < 0) { enh[i] = 0; continue; }
            int v = (g - lo) * 255 / range;
            enh[i] = v < 0 ? 0 : (v > 255 ? 255 : v);
        }
        // pertajam: v' = v + 1.0 * (v - blur)
        int[] tmp = new int[gray.length];
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 128; x++) {
                int sum = 0, n = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy > 63) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx > 127) continue;
                        sum += enh[yy * 128 + xx];
                        n++;
                    }
                }
                int c = enh[y * 128 + x];
                int v = c + (c - sum / n);
                tmp[y * 128 + x] = v < 0 ? 0 : (v > 255 ? 255 : v);
            }
        }
        System.arraycopy(tmp, 0, enh, 0, tmp.length);

        // integral image dari enh untuk rata-rata lokal
        for (int y = 0; y < 64; y++) {
            int row = 0;
            for (int x = 0; x < 128; x++) {
                row += enh[y * 128 + x];
                integ[(y + 1) * 129 + (x + 1)] = integ[y * 129 + (x + 1)] + row;
            }
        }
    }

    /** Rata-rata kecerahan jendela 9x9 di sekitar (x,y). */
    private int localMean(int x, int y) {
        int x0 = Math.max(0, x - 4), x1 = Math.min(127, x + 4);
        int y0 = Math.max(0, y - 4), y1 = Math.min(63, y + 4);
        int sum = integ[(y1 + 1) * 129 + (x1 + 1)] - integ[y0 * 129 + (x1 + 1)]
                - integ[(y1 + 1) * 129 + x0] + integ[y0 * 129 + x0];
        return sum / ((x1 - x0 + 1) * (y1 - y0 + 1));
    }

    @Override
    public void onDestroy() {
        active = false;
        status = "Mati";
        fps = 0;
        Handler hh = h;
        if (hh != null) hh.removeCallbacksAndMessages(null);
        try {
            if (vd != null) vd.release();
        } catch (Exception ignored) {
        }
        try {
            if (ir != null) ir.close();
        } catch (Exception ignored) {
        }
        try {
            if (mp != null) mp.stop();
        } catch (Exception ignored) {
        }
        try {
            if (ht != null) ht.quitSafely();
        } catch (Exception ignored) {
        }
        vd = null;
        ir = null;
        mp = null;
        h = null;
        super.onDestroy();
    }
}
