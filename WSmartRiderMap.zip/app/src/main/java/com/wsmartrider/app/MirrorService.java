package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Display;

import java.nio.ByteBuffer;

/**
 * Screen Mirror: menangkap layar HP, mengubahnya menjadi 128x64 hitam-putih (XBM, 1024 byte)
 * lalu mengirimnya ke W-Smart Rider lewat jalur yang sama dengan peta (flag bit2 = Screen Mirror).
 */
public class MirrorService extends Service {
    static volatile boolean active = false;
    static volatile String status = "Mati";
    static volatile int fps = 0;

    /** 0 = pas (seluruh layar, ada bidang hitam), 1 = potong tengah (isi penuh), 2 = regang (isi penuh, bentuk melar). */
    static volatile int fit = 0;
    static volatile boolean invert = false;

    private static final int HDR = 60, FRAME = 1024;
    private static final int MAX_SIDE = 640;           // sisi terpanjang gambar tangkapan
    private static final long MIN_GAP = 130L;          // ~7 gambar per detik
    private static final int[][] BAYER = {
            {0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};

    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader ir;
    private HandlerThread ht;
    private Handler h;
    private int capW, capH, dpi, phoneW, phoneH;
    private long lastSend = 0, fpsT = 0;
    private int fpsN = 0;
    private byte[] lastPkt;
    private byte[] buf = new byte[0];
    private final int[] gray = new int[128 * 64];

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || !intent.hasExtra("data")) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (active) return START_NOT_STICKY;

        try {
            startAsForeground();
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            ht = new HandlerThread("wsr-mirror");
            ht.start();
            h = new Handler(ht.getLooper());
            mp = m.getMediaProjection(code, data);
            if (mp == null) throw new IllegalStateException("izin ditolak");
            mp.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            }, h);
            measure();
            ir = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
            ir.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    onFrame(r);
                }
            }, h);
            vd = mp.createVirtualDisplay("wsr-mirror", capW, capH, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.getSurface(), null, h);
            active = true;
            status = "Aktif";
            h.postDelayed(watch, 1000);
        } catch (Throwable e) {
            status = "Gagal: " + e.getMessage();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("mirror", "Screen Mirror", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, MirrorService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "mirror")
                .setContentTitle("W-Smart Rider")
                .setContentText("Screen Mirror aktif")
                .setSmallIcon(android.R.drawable.ic_menu_slideshow)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(3, n);
        }
    }

    /** Ukuran layar HP saat ini -> ukuran gambar tangkapan (bentuk layar tetap). */
    private void measure() {
        DisplayMetrics dm = new DisplayMetrics();
        DisplayManager dmg = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display d = dmg.getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealMetrics(dm);
        phoneW = Math.max(2, dm.widthPixels);
        phoneH = Math.max(2, dm.heightPixels);
        dpi = dm.densityDpi;
        float sc = Math.min(1f, MAX_SIDE / (float) Math.max(phoneW, phoneH));
        capW = Math.max(16, Math.round(phoneW * sc));
        capH = Math.max(16, Math.round(phoneH * sc));
    }

    /** Tiap detik: kirim ulang frame terakhir (layar diam tidak menghasilkan gambar baru) dan cek putar layar. */
    private final Runnable watch = new Runnable() {
        @Override
        public void run() {
            if (!active) return;
            try {
                int ow = phoneW, oh = phoneH;
                measure();
                if (ow != phoneW || oh != phoneH) reconfigure();
                long now = System.currentTimeMillis();
                if (now - lastSend > 1000L && lastPkt != null) push(lastPkt);
                if (now - fpsT >= 1000L) {
                    fps = fpsN;
                    fpsN = 0;
                    fpsT = now;
                }
            } catch (Throwable ignored) {
            }
            if (h != null) h.postDelayed(this, 1000);
        }
    };

    private void reconfigure() {
        ImageReader old = ir;
        ImageReader nr = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        nr.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader r) {
                onFrame(r);
            }
        }, h);
        ir = nr;
        if (vd != null) {
            vd.resize(capW, capH, dpi);
            vd.setSurface(nr.getSurface());
        }
        if (old != null) old.close();
    }

    private void push(byte[] pkt) {
        NavService n = NavService.inst;
        if (n != null && n.pushMirror(pkt)) lastSend = System.currentTimeMillis();
    }

    private void onFrame(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long now = System.currentTimeMillis();
            if (now - lastSend < MIN_GAP) return;
            byte[] pkt = convert(img);
            lastPkt = pkt;
            push(pkt);
            fpsN++;
        } catch (Throwable ignored) {
        } finally {
            if (img != null) img.close();
        }
    }

    /** Gambar RGBA -> paket "MP" berisi frame 128x64 (XBM). */
    private byte[] convert(Image img) {
        final int w = img.getWidth(), hh = img.getHeight();
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer bb = pl.getBuffer();
        final int rs = pl.getRowStride();
        final int ps = pl.getPixelStride();
        int need = bb.remaining();
        if (buf.length < need) buf = new byte[need];
        bb.get(buf, 0, need);

        // sumber (sx,sy,sw,sh) -> tujuan (dx,dy,dw,dh) pada layar 128x64
        float sx = 0, sy = 0, sw = w, sh = hh;
        int dx = 0, dy = 0, dw = 128, dh = 64;
        int mode = fit;
        if (mode == 0) {
            float sc = Math.min(128f / w, 64f / hh);
            dw = Math.max(1, Math.round(w * sc));
            dh = Math.max(1, Math.round(hh * sc));
            dx = (128 - dw) / 2;
            dy = (64 - dh) / 2;
        } else if (mode == 1) {
            if (w >= 2f * hh) {
                sw = 2f * hh;
                sx = (w - sw) / 2f;
            } else {
                sh = w / 2f;
                sy = (hh - sh) / 2f;
            }
        }

        java.util.Arrays.fill(gray, -1);   // -1 = di luar gambar (tetap hitam)
        for (int y = 0; y < dh; y++) {
            int y0 = (int) (sy + y * sh / dh);
            int y1 = Math.max(y0 + 1, (int) (sy + (y + 1) * sh / dh));
            if (y1 > hh) y1 = hh;
            for (int x = 0; x < dw; x++) {
                int x0 = (int) (sx + x * sw / dw);
                int x1 = Math.max(x0 + 1, (int) (sx + (x + 1) * sw / dw));
                if (x1 > w) x1 = w;
                int sum = 0, n = 0;
                for (int yy = y0; yy < y1; yy++) {
                    int row = yy * rs;
                    for (int xx = x0; xx < x1; xx++) {
                        int o = row + xx * ps;
                        if (o + 2 >= buf.length) continue;
                        int rr = buf[o] & 0xFF, gg = buf[o + 1] & 0xFF, bl = buf[o + 2] & 0xFF;
                        sum += (77 * rr + 150 * gg + 29 * bl) >> 8;
                        n++;
                    }
                }
                gray[(dy + y) * 128 + dx + x] = n == 0 ? 0 : sum / n;
            }
        }

        byte[] pkt = new byte[HDR + FRAME];
        pkt[0] = 'M';
        pkt[1] = 'P';
        pkt[2] = 4;                       // bit2 = frame Screen Mirror
        final boolean inv = invert;
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 128; x++) {
                int g = gray[y * 128 + x];
                if (g < 0) continue;      // bidang kosong: hitam
                int thr = BAYER[y & 3][x & 3] * 16 + 8;
                boolean on = g > thr;
                if (inv) on = !on;
                if (on) pkt[HDR + y * 16 + (x >> 3)] |= (byte) (1 << (x & 7));
            }
        }
        return pkt;
    }

    @Override
    public void onDestroy() {
        active = false;
        status = "Mati";
        fps = 0;
        Handler hh = h;
        if (hh != null) hh.removeCallbacksAndMessages(null);
        try {
            if (vd != null) vd.release();
        } catch (Exception ignored) {
        }
        try {
            if (ir != null) ir.close();
        } catch (Exception ignored) {
        }
        try {
            if (mp != null) mp.stop();
        } catch (Exception ignored) {
        }
        try {
            if (ht != null) ht.quitSafely();
        } catch (Exception ignored) {
        }
        vd = null;
        ir = null;
        mp = null;
        h = null;
        super.onDestroy();
    }
}
