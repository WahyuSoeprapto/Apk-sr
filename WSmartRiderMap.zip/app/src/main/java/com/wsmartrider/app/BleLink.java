package com.wsmartrider.app;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;

import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/** Koneksi Bluetooth LE ke W-Smart Rider (layanan yang sama dengan aplikasi Chronos). */
final class BleLink {
    interface Listener {
        void onCommand(byte[] d);
    }

    static final UUID SERVICE = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    static final UUID RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    static final UUID TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final class Item {
        final byte[] data;
        final boolean noResp;

        Item(byte[] d, boolean n) {
            data = d;
            noResp = n;
        }
    }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinkedBlockingQueue<Item> q = new LinkedBlockingQueue<>();
    private final Semaphore sem = new Semaphore(0);

    private volatile boolean running = false;
    private volatile boolean scanning = false;
    private volatile boolean servicesStarted = false;
    volatile boolean ready = false;
    volatile String name = "";
    volatile String state = "";
    private volatile int mtu = 23;
    private int mapFrame = 0;

    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic rx, tx;
    private BluetoothLeScanner scanner;
    private Thread writer;

    BleLink(Context c, Listener l) {
        ctx = c;
        listener = l;
    }

    // ---------------- siklus hidup ----------------
    void start() {
        if (running) return;
        running = true;
        writer = new Thread(new Runnable() {
            @Override
            public void run() {
                writeLoop();
            }
        });
        writer.setDaemon(true);
        writer.start();
        startScan();
    }

    void stop() {
        running = false;
        main.removeCallbacksAndMessages(null);
        stopScan();
        closeGatt();
        if (writer != null) writer.interrupt();
        ready = false;
        state = "";
    }

    private final Runnable retry = new Runnable() {
        @Override
        public void run() {
            startScan();
        }
    };

    private final Runnable scanTimeout = new Runnable() {
        @Override
        public void run() {
            if (scanning) {
                stopScan();
                state = "W-Smart Rider tidak ditemukan, mencoba lagi...";
                main.postDelayed(retry, 3000);
            }
        }
    };

    // ---------------- pemindaian ----------------
    private void startScan() {
        if (!running || ready || gatt != null || scanning) return;
        try {
            BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
            if (ad == null || !ad.isEnabled()) {
                state = "Bluetooth HP mati";
                main.postDelayed(retry, 4000);
                return;
            }
            scanner = ad.getBluetoothLeScanner();
            if (scanner == null) {
                state = "Bluetooth belum siap";
                main.postDelayed(retry, 4000);
                return;
            }
            ScanFilter f = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE)).build();
            ScanSettings s = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(Collections.singletonList(f), s, scanCb);
            scanning = true;
            state = "Mencari W-Smart Rider (Bluetooth)...";
            main.postDelayed(scanTimeout, 12000);
        } catch (SecurityException e) {
            state = "Izin Bluetooth belum diberikan";
            main.postDelayed(retry, 5000);
        } catch (Exception e) {
            state = "Scan error: " + e.getMessage();
            main.postDelayed(retry, 5000);
        }
    }

    private void stopScan() {
        try {
            if (scanner != null && scanning) scanner.stopScan(scanCb);
        } catch (Exception ignored) {
        }
        scanning = false;
    }

    private final ScanCallback scanCb = new ScanCallback() {
        @Override
        public void onScanResult(int type, ScanResult r) {
            if (!running || gatt != null) return;
            stopScan();
            main.removeCallbacks(scanTimeout);
            connect(r.getDevice());
        }

        @Override
        public void onScanFailed(int code) {
            scanning = false;
            state = "Scan gagal (" + code + ")";
            main.postDelayed(retry, 5000);
        }
    };

    // ---------------- koneksi ----------------
    private void connect(BluetoothDevice dev) {
        try {
            String n = dev.getName();
            name = (n != null && !n.isEmpty()) ? n : dev.getAddress();
        } catch (SecurityException e) {
            name = dev.getAddress();
        }
        state = "Menyambung ke " + name + "...";
        servicesStarted = false;
        try {
            gatt = dev.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            state = "Izin Bluetooth belum diberikan";
            main.postDelayed(retry, 5000);
        }
    }

    private void closeGatt() {
        BluetoothGatt g = gatt;
        gatt = null;
        rx = null;
        tx = null;
        ready = false;
        q.clear();
        if (g != null) {
            try {
                g.disconnect();
            } catch (Exception ignored) {
            }
            try {
                g.close();
            } catch (Exception ignored) {
            }
        }
    }

    private void discover(BluetoothGatt g) {
        if (servicesStarted) return;
        servicesStarted = true;
        try {
            g.discoverServices();
        } catch (SecurityException ignored) {
        }
    }

    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(final BluetoothGatt g, int status, int newState) {
            try {
                if (newState == 2) { // terhubung
                    state = "Terhubung, menyiapkan layanan...";
                    g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);
                    if (!g.requestMtu(517)) discover(g);
                    main.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (gatt == g) discover(g);
                        }
                    }, 3000);
                } else if (newState == 0) { // terputus
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            if (gatt == g || gatt == null) {
                                closeGatt();
                                if (running) {
                                    state = "Terputus, mencari lagi...";
                                    main.postDelayed(retry, 2500);
                                }
                            }
                        }
                    });
                }
            } catch (SecurityException ignored) {
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt g, int m, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = m;
            discover(g);
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            try {
                BluetoothGattService s = g.getService(SERVICE);
                if (s == null) {
                    state = "Layanan Chronos tidak ditemukan";
                    g.disconnect();
                    return;
                }
                rx = s.getCharacteristic(RX);
                tx = s.getCharacteristic(TX);
                if (rx == null || tx == null) {
                    state = "Karakteristik tidak lengkap";
                    g.disconnect();
                    return;
                }
                g.setCharacteristicNotification(tx, true);
                BluetoothGattDescriptor d = tx.getDescriptor(CCCD);
                if (d != null) {
                    d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    g.writeDescriptor(d);
                } else {
                    markReady();
                }
            } catch (SecurityException ignored) {
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            markReady();
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] v = c.getValue();
            if (v != null && listener != null) listener.onCommand(v);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            sem.release();
        }
    };

    private void markReady() {
        if (ready) return;
        ready = true;
        state = "Terhubung via Bluetooth (MTU " + mtu + ")";
    }

    // ---------------- kirim ----------------
    /** Kirim paket logis Chronos (otomatis dipecah sesuai kerangka library). */
    void send(byte[] logical) {
        if (!ready) return;
        for (byte[] p : Proto.frame(logical, mtu)) q.offer(new Item(p, false));
    }

    /** Kirim satu frame peta (36 byte header + 1024 byte gambar). Dilewati jika antrean penuh. */
    int mtu() {
        return mtu;
    }

    /** Antrekan banyak paket (ditulis dengan respons, andal) - dipakai untuk mengirim wallpaper jam. */
    void sendQueued(java.util.List<byte[]> chunks) {
        if (!ready) return;
        for (byte[] p : chunks) q.offer(new Item(p, false));
    }

    void sendMap(byte[] pkt) {
        boolean big = pkt.length > 4000;              // frame warna: tunggu antrean hampir kosong
        if (!ready || q.size() > (big ? 2 : 8)) return;
        int per = Math.max(10, Math.min(400, mtu - 13));
        if ((pkt.length + per - 1) / per > 255) return;   // jumlah potongan harus muat 1 byte
        mapFrame = (mapFrame + 1) & 0xFF;
        for (byte[] p : Proto.mapChunks(pkt, mtu, mapFrame)) q.offer(new Item(p, true));
    }

    private void writeLoop() {
        while (running) {
            try {
                Item it = q.poll(500, TimeUnit.MILLISECONDS);
                if (it == null) continue;
                BluetoothGatt g = gatt;
                BluetoothGattCharacteristic c = rx;
                if (!ready || g == null || c == null) continue;
                c.setWriteType(it.noResp
                        ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                        : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                c.setValue(it.data);
                sem.drainPermits();
                if (g.writeCharacteristic(c)) {
                    sem.tryAcquire(1500, TimeUnit.MILLISECONDS);
                } else {
                    Thread.sleep(30);
                }
            } catch (InterruptedException e) {
                break;
            } catch (SecurityException e) {
                state = "Izin Bluetooth belum diberikan";
            } catch (Exception ignored) {
            }
        }
    }
}
