package com.wsmartrider.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Tema jam layar TFT W-Smart Rider. Tabel warna HARUS sama dengan CK_TH[] di sketch. */
final class ClockThemes {
    static final int COUNT = 8;
    static final String[] NAMES = {"Neon", "Sunset", "Aurora", "Samudra", "Sakura", "Emas", "Api", "Pop"};
    static final int BG_T = 0, BG_B = 1, INK_T = 2, INK_B = 3, DATE = 4, CARD = 5, LINE = 6, ACC = 7, FA = 8, FB = 9;
    // tiap tema: bgT, bgB, inkT, inkB, date, card, line, acc, fa, fb (masing-masing R,G,B)
    private static final int[][] T = {
            {6, 12, 44, 40, 16, 84, 0, 235, 255, 200, 110, 255, 200, 210, 255, 30, 34, 86, 66, 80, 170, 110, 230, 170, 0, 215, 255, 200, 110, 255},
            {30, 8, 52, 112, 34, 58, 255, 214, 90, 255, 92, 140, 255, 205, 175, 72, 24, 66, 170, 70, 110, 255, 170, 80, 255, 200, 70, 255, 90, 140},
            {4, 24, 36, 8, 72, 66, 150, 255, 120, 40, 220, 230, 190, 255, 230, 10, 52, 62, 30, 140, 130, 150, 255, 120, 120, 255, 130, 40, 220, 230},
            {2, 14, 52, 6, 78, 122, 255, 255, 255, 110, 215, 255, 170, 225, 255, 8, 40, 88, 40, 120, 200, 90, 220, 255, 60, 200, 255, 120, 255, 225},
            {44, 12, 40, 98, 28, 78, 255, 190, 215, 255, 150, 120, 255, 215, 230, 74, 22, 64, 170, 70, 130, 255, 160, 190, 255, 150, 190, 255, 200, 130},
            {14, 12, 8, 60, 42, 10, 255, 236, 150, 255, 160, 40, 255, 225, 160, 44, 32, 10, 150, 110, 30, 255, 200, 70, 255, 214, 90, 255, 150, 30},
            {20, 4, 4, 86, 12, 8, 255, 235, 90, 255, 70, 40, 255, 200, 160, 60, 14, 12, 170, 50, 30, 255, 150, 50, 255, 210, 60, 255, 70, 40},
            {16, 6, 44, 62, 8, 82, 190, 255, 70, 255, 80, 200, 240, 200, 255, 44, 16, 86, 150, 60, 190, 190, 255, 70, 190, 255, 70, 255, 80, 200}
    };

    static int col(int theme, int slot) {
        int[] a = T[Math.max(0, Math.min(COUNT - 1, theme))];
        return Color.rgb(a[slot * 3], a[slot * 3 + 1], a[slot * 3 + 2]);
    }

    /** Kartu pratinjau satu tema (meniru susunan jam di layar TFT: jam, bar bensin, tanggal, kartu cuaca & trip). */
    static final class Preview extends View {
        private final int theme;
        private final float density;
        private boolean selected = false;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Preview(Context c, int theme, float density) {
            super(c);
            this.theme = theme;
            this.density = density;
        }

        void setSelectedTheme(boolean s) {
            if (selected != s) {
                selected = s;
                invalidate();
            }
        }

        private void box(Canvas c, float k, float x, float y, float w, float h, float r, int fill, int stroke) {
            RectF rf = new RectF(x * k, y * k, (x + w) * k, (y + h) * k);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            c.drawRoundRect(rf, r * k, r * k, p);
            if (stroke != 0) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(1f, k));
                p.setColor(stroke);
                c.drawRoundRect(rf, r * k, r * k, p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align al) {
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setTextAlign(al);
            c.drawText(s, x, y, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = getWidth();
            if (s <= 0) return;
            float k = s / 240f;
            // latar
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, 0, 0, s, col(theme, BG_T), col(theme, BG_B), Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(0, 0, s, s), 16 * k, 16 * k, p);
            p.setShader(null);
            // status: Bluetooth + baterai
            p.setColor(0xFF5AAAFF);
            c.drawCircle(20 * k, 15 * k, 4 * k, p);
            box(c, k, 194, 8, 30, 15, 4, 0, 0xFFD7DEF5);
            box(c, k, 197, 11, 20, 9, 2, 0xFF5AEB96, 0);
            // jam
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(86 * k);
            p.setShader(new LinearGradient(0, 34 * k, 0, 106 * k, col(theme, INK_T), col(theme, INK_B), Shader.TileMode.CLAMP));
            c.drawText("18:37", s / 2f, 98 * k, p);
            p.setShader(null);
            // bar bensin (contoh 70%)
            int fb = col(theme, FB);
            box(c, k, 12, 3, 12, 17, 2, fb, 0);
            box(c, k, 14, 5, 8, 5, 1, col(theme, CARD), 0);
            box(c, k, 10, 20, 16, 2, 1, fb, 0);
            box(c, k, 38, 116, 138, 14, 7, col(theme, CARD), col(theme, LINE));
            p.setShader(new LinearGradient(40 * k, 0, 174 * k, 0, col(theme, FA), col(theme, FB), Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(new RectF(40 * k, 118 * k, (40 + 134 * 0.7f) * k, 128 * k), 5 * k, 5 * k, p);
            p.setShader(null);
            int dc = col(theme, DATE);
            txt(c, "E", 40 * k, 145 * k, 9 * k, dc, false, Paint.Align.LEFT);
            txt(c, "BENSIN", (38 + 69) * k, 145 * k, 9 * k, dc, false, Paint.Align.CENTER);
            txt(c, "F", 174 * k, 145 * k, 9 * k, dc, false, Paint.Align.RIGHT);
            txt(c, "2.9 L", 184 * k, 129 * k, 14 * k, Color.WHITE, true, Paint.Align.LEFT);
            txt(c, "87 km", 184 * k, 147 * k, 12 * k, dc, false, Paint.Align.LEFT);
            // tanggal
            txt(c, "Rabu, 28 Okt 2026", s / 2f, 175 * k, 15 * k, dc, false, Paint.Align.CENTER);
            // kartu cuaca & trip
            box(c, k, 6, 196, 134, 38, 10, col(theme, CARD), col(theme, LINE));
            p.setColor(0xFFFFCD3C);
            c.drawCircle(26 * k, 215 * k, 8 * k, p);
            p.setColor(0xFFE2E9F7);
            c.drawCircle(32 * k, 220 * k, 7 * k, p);
            txt(c, "31\u00B0C", 52 * k, 215 * k, 15 * k, Color.WHITE, true, Paint.Align.LEFT);
            txt(c, "Berawan", 52 * k, 229 * k, 11 * k, dc, false, Paint.Align.LEFT);
            box(c, k, 146, 196, 88, 38, 10, col(theme, CARD), col(theme, LINE));
            box(c, k, 154, 203, 4, 24, 2, col(theme, ACC), 0);
            txt(c, "TRIP", 164 * k, 212 * k, 11 * k, col(theme, ACC), false, Paint.Align.LEFT);
            txt(c, "12.3 km", 164 * k, 228 * k, 14 * k, Color.WHITE, true, Paint.Align.LEFT);
            // pilihan
            if (selected) {
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3 * density);
                p.setColor(0xFF19B8F2);
                c.drawRoundRect(new RectF(1.5f * density, 1.5f * density, s - 1.5f * density, s - 1.5f * density), 16 * k, 16 * k, p);
                p.setStyle(Paint.Style.FILL);
            }
            float nameH = getHeight() - s;
            txt(c, NAMES[theme] + (selected ? "  \u2713" : ""), s / 2f, s + nameH * 0.68f, 14 * density,
                    selected ? Color.WHITE : 0xFF9FB3C8, selected, Paint.Align.CENTER);
        }
    }
}
