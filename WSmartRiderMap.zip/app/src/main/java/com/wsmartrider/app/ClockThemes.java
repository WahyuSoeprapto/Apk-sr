package com.wsmartrider.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Tema jam layar TFT W-Smart Rider. Tabel warna HARUS sama dengan CK_TH[] di sketch. */
final class ClockThemes {
    static final int COUNT = 14;
    static final String[] NAMES = {"Neon", "Sunset", "Aurora", "Samudra", "Sakura", "Emas", "Api", "Pop", "Pelangi RGB", "Cyber", "Mono", "Retro Amber", "RGB Gamer", "Hutan"};
    static final int BG_T = 0, BG_B = 1, INK_T = 2, INK_B = 3, DATE = 4, CARD = 5, LINE = 6, ACC = 7, FA = 8, FB = 9;
    // tiap tema: bgT, bgB, inkT, inkB, date, card, line, acc, fa, fb (masing-masing R,G,B)
    private static final int[][] T = {
            {6, 12, 44, 40, 16, 84, 0, 235, 255, 200, 110, 255, 200, 210, 255, 30, 34, 86, 66, 80, 170, 110, 230, 170, 0, 215, 255, 200, 110, 255},
            {30, 8, 52, 112, 34, 58, 255, 214, 90, 255, 92, 140, 255, 205, 175, 72, 24, 66, 170, 70, 110, 255, 170, 80, 255, 200, 70, 255, 90, 140},
            {4, 24, 36, 8, 72, 66, 150, 255, 120, 40, 220, 230, 190, 255, 230, 10, 52, 62, 30, 140, 130, 150, 255, 120, 120, 255, 130, 40, 220, 230},
            {2, 14, 52, 6, 78, 122, 255, 255, 255, 110, 215, 255, 170, 225, 255, 8, 40, 88, 40, 120, 200, 90, 220, 255, 60, 200, 255, 120, 255, 225},
            {44, 12, 40, 98, 28, 78, 255, 190, 215, 255, 150, 120, 255, 215, 230, 74, 22, 64, 170, 70, 130, 255, 160, 190, 255, 150, 190, 255, 200, 130},
            {14, 12, 8, 60, 42, 10, 255, 236, 150, 255, 160, 40, 255, 225, 160, 44, 32, 10, 150, 110, 30, 255, 200, 70, 255, 214, 90, 255, 150, 30},
            {20, 4, 4, 86, 12, 8, 255, 235, 90, 255, 70, 40, 255, 200, 160, 60, 14, 12, 170, 50, 30, 255, 150, 50, 255, 210, 60, 255, 70, 40},
            {16, 6, 44, 62, 8, 82, 190, 255, 70, 255, 80, 200, 240, 200, 255, 44, 16, 86, 150, 60, 190, 190, 255, 70, 190, 255, 70, 255, 80, 200},
            // 8 Pelangi RGB (warna dihitung dari waktu; angka di sini hanya latar & cadangan)
            {4, 4, 14, 16, 6, 34, 255, 0, 0, 0, 0, 255, 230, 230, 255, 16, 12, 40, 120, 120, 200, 255, 255, 255, 255, 0, 0, 0, 0, 255},
            // 9 Cyber
            {0, 10, 4, 0, 40, 20, 120, 255, 160, 0, 200, 90, 150, 255, 190, 0, 36, 18, 0, 150, 70, 120, 255, 160, 0, 200, 90, 180, 255, 120},
            // 10 Mono
            {10, 10, 12, 40, 42, 48, 255, 255, 255, 170, 175, 190, 200, 205, 215, 26, 28, 34, 90, 95, 110, 255, 255, 255, 150, 155, 170, 255, 255, 255},
            // 11 Retro Amber
            {18, 8, 0, 50, 24, 0, 255, 190, 40, 255, 120, 0, 255, 200, 120, 40, 20, 2, 170, 100, 10, 255, 170, 0, 255, 200, 40, 255, 110, 0},
            // 12 RGB Gamer
            {0, 0, 0, 8, 8, 18, 255, 0, 0, 0, 0, 255, 255, 255, 255, 10, 10, 22, 90, 90, 160, 255, 255, 255, 255, 0, 0, 0, 0, 255},
            // 13 Hutan
            {4, 20, 8, 16, 56, 24, 200, 255, 120, 60, 200, 90, 200, 240, 190, 10, 44, 20, 50, 130, 60, 200, 255, 120, 90, 220, 100, 220, 255, 120}
    };
    // Susunan per tema -- HARUS sama dengan lay/flags/clkOff/rgb di CK_TH[] pada sketch.
    static final int F_SWAP = 1, F_MIRROR = 2, F_WICON_R = 4, F_DATE_L = 8, F_DATE_R = 16;
    private static final int[] LAY = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 1, 3, 2};
    private static final int[] FLAGS = {0, 0, 0, 0, 0, 0, 0, 0, F_SWAP | F_MIRROR, F_WICON_R | F_DATE_L, F_MIRROR | F_DATE_R,
            F_WICON_R | F_DATE_L, F_SWAP | F_WICON_R, F_SWAP | F_MIRROR};
    private static final int[] CLK_OFF = {0, 0, 0, 0, 0, 0, 0, 0, 0, -12, 12, -8, 0, 0};
    private static final int[] RGB = {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0};
    // posisi atas {jam, bensin, tanggal, kartu} per susunan -- sama dengan CK_LAY di sketch
    private static final int[][] LAYY = {{34, 110, 156, 194}, {82, 158, 208, 32}, {60, 192, 30, 138}, {78, 30, 156, 194}};

    static int col(int theme, int slot) {
        int[] a = T[Math.max(0, Math.min(COUNT - 1, theme))];
        return Color.rgb(a[slot * 3], a[slot * 3 + 1], a[slot * 3 + 2]);
    }

    /** Kartu pratinjau satu tema (meniru susunan jam di layar TFT: jam, bar bensin, tanggal, kartu cuaca & trip). */
    static final class Preview extends View {
        private final int theme;
        private final float density;
        private boolean selected = false;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Preview(Context c, int theme, float density) {
            super(c);
            this.theme = theme;
            this.density = density;
        }

        void setSelectedTheme(boolean s) {
            if (selected != s) {
                selected = s;
                invalidate();
            }
        }

        private void box(Canvas c, float k, float x, float y, float w, float h, float r, int fill, int stroke) {
            RectF rf = new RectF(x * k, y * k, (x + w) * k, (y + h) * k);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            c.drawRoundRect(rf, r * k, r * k, p);
            if (stroke != 0) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(1f, k));
                p.setColor(stroke);
                c.drawRoundRect(rf, r * k, r * k, p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align al) {
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setTextAlign(al);
            c.drawText(s, x, y, p);
        }

        private static int hsv(float h, float sat, float val) {
            return Color.HSVToColor(new float[]{((h % 360f) + 360f) % 360f, sat, val});
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = getWidth();
            if (s <= 0) return;
            float k = s / 240f;
            final int lay = LAY[theme], fl = FLAGS[theme], off = CLK_OFF[theme], rgb = RGB[theme];
            final int[] y = LAYY[lay];
            final float hue = rgb == 0 ? 0f : (System.currentTimeMillis() / (rgb == 2 ? 9f : 20f)) % 360f;
            // warna: tema RGB dihitung dari hue yang berputar (sama dengan ckPickTheme di sketch)
            final int dateC = rgb != 0 ? hsv(hue + 40, 0.27f, 1f) : col(theme, DATE);
            final int cardC = rgb != 0 ? hsv(hue + 200, 1f, 0.18f) : col(theme, CARD);
            final int lineC = rgb != 0 ? hsv(hue + 60, 1f, 0.67f) : col(theme, LINE);
            final int accC = rgb != 0 ? hsv(hue + 180, 1f, 1f) : col(theme, ACC);
            final int faC = rgb != 0 ? hsv(hue, 1f, 1f) : col(theme, FA);
            final int fbC = rgb != 0 ? hsv(hue + 120, 1f, 1f) : col(theme, FB);
            // latar
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, 0, 0, s, col(theme, BG_T), col(theme, BG_B), Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(0, 0, s, s), 16 * k, 16 * k, p);
            p.setShader(null);
            // status: Bluetooth + baterai
            p.setColor(0xFF5AAAFF);
            c.drawCircle(20 * k, 15 * k, 4 * k, p);
            box(c, k, 194, 8, 30, 15, 4, 0, 0xFFD7DEF5);
            box(c, k, 197, 11, 20, 9, 2, 0xFF5AEB96, 0);
            // jam
            float cy = y[0];
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(86 * k);
            if (rgb != 0) {
                p.setShader(new LinearGradient(0, cy * k, 0, (cy + 72) * k,
                        new int[]{hsv(hue, 1f, 1f), hsv(hue + 70, 1f, 1f), hsv(hue + 140, 1f, 1f)},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            } else {
                p.setShader(new LinearGradient(0, cy * k, 0, (cy + 72) * k, col(theme, INK_T), col(theme, INK_B), Shader.TileMode.CLAMP));
            }
            c.drawText("18:37", s / 2f + off * k, (cy + 64) * k, p);
            p.setShader(null);
            // bar bensin (contoh 70%)
            boolean mir = (fl & F_MIRROR) != 0;
            float fy = y[1];
            float bx = mir ? 64 : 38, bw = mir ? 118 : 138, ix = mir ? 200 : 0, nx = mir ? 6 : 184;
            box(c, k, 12 + ix, fy + 3, 12, 17, 2, fbC, 0);
            box(c, k, 14 + ix, fy + 5, 8, 5, 1, cardC, 0);
            box(c, k, 10 + ix, fy + 20, 16, 2, 1, fbC, 0);
            box(c, k, bx, fy + 6, bw, 14, 7, cardC, lineC);
            p.setStyle(Paint.Style.FILL);
            if (rgb != 0) {
                p.setShader(new LinearGradient((bx + 2) * k, 0, (bx + bw - 2) * k, 0,
                        new int[]{hsv(hue, 1f, 1f), hsv(hue + 75, 1f, 1f), hsv(hue + 150, 1f, 1f)},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            } else {
                p.setShader(new LinearGradient((bx + 2) * k, 0, (bx + bw - 2) * k, 0, faC, fbC, Shader.TileMode.CLAMP));
            }
            c.drawRoundRect(new RectF((bx + 2) * k, (fy + 8) * k, (bx + 2 + (bw - 4) * 0.7f) * k, (fy + 18) * k), 5 * k, 5 * k, p);
            p.setShader(null);
            txt(c, "E", (bx + 2) * k, (fy + 35) * k, 9 * k, dateC, false, Paint.Align.LEFT);
            txt(c, "BENSIN", (bx + bw / 2f) * k, (fy + 35) * k, 9 * k, dateC, false, Paint.Align.CENTER);
            txt(c, "F", (bx + bw) * k, (fy + 35) * k, 9 * k, dateC, false, Paint.Align.RIGHT);
            txt(c, "2.9 L", nx * k, (fy + 19) * k, 14 * k, Color.WHITE, true, Paint.Align.LEFT);
            txt(c, "87 km", nx * k, (fy + 37) * k, 12 * k, dateC, false, Paint.Align.LEFT);
            // tanggal
            String tgl = "Rabu, 28 Okt 2026";
            if ((fl & F_DATE_L) != 0) txt(c, tgl, 10 * k, (y[2] + 19) * k, 15 * k, dateC, false, Paint.Align.LEFT);
            else if ((fl & F_DATE_R) != 0) txt(c, tgl, 230 * k, (y[2] + 19) * k, 15 * k, dateC, false, Paint.Align.RIGHT);
            else txt(c, tgl, s / 2f, (y[2] + 19) * k, 15 * k, dateC, false, Paint.Align.CENTER);
            // kartu cuaca & trip
            boolean swp = (fl & F_SWAP) != 0, icR = (fl & F_WICON_R) != 0;
            float cyy = y[3], xW = swp ? 100 : 6, xT = swp ? 6 : 146;
            box(c, k, xW, cyy + 2, 134, 40, 10, cardC, lineC);
            float icx = icR ? xW + 112 : xW + 22, tx = icR ? xW + 10 : xW + 46;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFCD3C);
            c.drawCircle((icx - 2) * k, (cyy + 21) * k, 8 * k, p);
            p.setColor(0xFFE2E9F7);
            c.drawCircle((icx + 4) * k, (cyy + 26) * k, 7 * k, p);
            txt(c, "31\u00B0C", tx * k, (cyy + 21) * k, 15 * k, Color.WHITE, true, Paint.Align.LEFT);
            txt(c, "Berawan", tx * k, (cyy + 36) * k, 11 * k, dateC, false, Paint.Align.LEFT);
            box(c, k, xT, cyy + 2, 88, 40, 10, cardC, lineC);
            box(c, k, xT + 8, cyy + 9, 4, 26, 2, accC, 0);
            txt(c, "TRIP", (xT + 18) * k, (cyy + 17) * k, 11 * k, accC, false, Paint.Align.LEFT);
            txt(c, "12.3 km", (xT + 18) * k, (cyy + 36) * k, 14 * k, Color.WHITE, true, Paint.Align.LEFT);
            // pilihan
            if (selected) {
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3 * density);
                p.setColor(0xFF19B8F2);
                c.drawRoundRect(new RectF(1.5f * density, 1.5f * density, s - 1.5f * density, s - 1.5f * density), 16 * k, 16 * k, p);
                p.setStyle(Paint.Style.FILL);
            }
            float nameH = getHeight() - s;
            txt(c, NAMES[theme] + (selected ? "  \u2713" : ""), s / 2f, s + nameH * 0.68f, 14 * density,
                    selected ? Color.WHITE : 0xFF9FB3C8, selected, Paint.Align.CENTER);
            if (rgb != 0) postInvalidateOnAnimation();      // tema RGB: pratinjau bergerak
        }
    }
}
