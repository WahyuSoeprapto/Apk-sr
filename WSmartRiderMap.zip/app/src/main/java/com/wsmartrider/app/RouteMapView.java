package com.wsmartrider.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

/**
 * Pratinjau peta di tab Navigasi: jalan sekitar + rute aktif (magenta) + posisi + tujuan/SPBU.
 * Ketuk peta untuk ganti: "Seluruh rute" (muat utuh) <-> "Ikuti posisi" (zoom dekat, mengikuti GPS).
 * Data diambil dari NavService.ui* (diisi tiap 0,5 detik oleh layanan navigasi).
 */
final class RouteMapView extends View {
    private boolean follow = false;
    private int sig = 0;
    private final Path path = new Path();
    private final float d;

    private final Paint bg = fill(0xFF0B1230);
    private final Paint park = fill(0xFF1E9A4E);
    private final Paint water = fill(0xFF2A7BFF);
    private final Paint stream, alley, minor, major, casing, core, shine, ring, txt, txtBg;
    private final Paint me = fill(0xFFFFFFFF);
    private final Paint pin = fill(0xFFFFA020);

    private double cLat, cLon, mpp, kx, ky;
    private float w, h;

    RouteMapView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        stream = stroke(0xFF2A7BFF, 2f);
        alley = stroke(0xFF4C5C9E, 1f);
        minor = stroke(0xFF8CA0E8, 1.6f);
        major = stroke(0xFFD0DAFF, 2.6f);
        casing = stroke(0xFF50006E, 8f);
        core = stroke(0xFFFF28FF, 4.5f);
        shine = stroke(0xFFFFC8FF, 1.4f);
        ring = stroke(0xFF3CD8FF, 2f);
        txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setColor(Color.WHITE);
        txt.setTextSize(12f * d);
        txt.setFakeBoldText(true);
        txtBg = fill(0xCC0B1230);
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                follow = !follow;
                sig = 0;
                invalidate();
            }
        });
    }

    private Paint fill(int col) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        return p;
    }

    private Paint stroke(int col, float dp) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(col);
        p.setStrokeWidth(dp * (getResources() == null ? 1f : getResources().getDisplayMetrics().density));
        return p;
    }

    /** Dipanggil dari penyegar UI (tiap ~1 detik). Gambar ulang hanya bila datanya berubah. */
    void refresh() {
        Route r = NavService.uiRoute;
        int s = System.identityHashCode(r) * 31 + System.identityHashCode(NavService.uiRoads);
        s = s * 31 + (int) Math.round(NavService.uiLat * 20000) + (int) Math.round(NavService.uiLon * 20000) * 7;
        s = s * 31 + (follow ? 1 : 0) + (NavService.uiHasPos ? 2 : 0);
        s = s * 31 + (NavService.uiDetour == null ? 0 : NavService.uiDetour.hashCode());
        if (s != sig) {
            sig = s;
            invalidate();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return super.onTouchEvent(e);
    }

    private float px(double lon) {
        return (float) (w / 2f + (lon - cLon) * kx / mpp);
    }

    private float py(double lat) {
        return (float) (h / 2f - (lat - cLat) * ky / mpp);
    }

    private void drawWays(Canvas c, java.util.List<double[]> ways, Paint p, boolean closed) {
        for (double[] wy : ways) {
            path.reset();
            boolean any = false;
            for (int i = 0; i + 1 < wy.length; i += 2) {
                float x = px(wy[i + 1]), y = py(wy[i]);
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
                any = true;
            }
            if (any) c.drawPath(path, p);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        w = getWidth();
        h = getHeight();
        c.drawRoundRect(0, 0, w, h, 14f * d, 14f * d, bg);
        c.save();
        Path clip = new Path();
        clip.addRoundRect(0, 0, w, h, 14f * d, 14f * d, Path.Direction.CW);
        c.clipPath(clip);

        if (!NavService.active || !NavService.uiHasPos) {
            c.drawText("Mulai navigasi untuk melihat peta", 14f * d, h / 2f, txt);
            c.restore();
            return;
        }
        Route rt = NavService.uiRoute;
        RoadSet rs = NavService.uiRoads;
        double la = NavService.uiLat, lo = NavService.uiLon;
        ky = 110540.0;
        kx = 111320.0 * Math.cos(Math.toRadians(la));

        // ---- bingkai: seluruh rute atau ikuti posisi ----
        if (follow || rt == null) {
            cLat = la;
            cLon = lo;
            mpp = (follow ? 500.0 : 700.0) / Math.min(w, h) * 2.0;   // lebar pandang ~1 km (ikuti) / ~1,4 km (tanpa rute)
        } else {
            double minLa = la, maxLa = la, minLo = lo, maxLo = lo;
            for (int i = 0; i < rt.lat.length; i++) {
                minLa = Math.min(minLa, rt.lat[i]);
                maxLa = Math.max(maxLa, rt.lat[i]);
                minLo = Math.min(minLo, rt.lon[i]);
                maxLo = Math.max(maxLo, rt.lon[i]);
            }
            cLat = (minLa + maxLa) / 2;
            cLon = (minLo + maxLo) / 2;
            double spanX = Math.max(150.0, (maxLo - minLo) * kx), spanY = Math.max(150.0, (maxLa - minLa) * ky);
            mpp = Math.max(spanX / (w * 0.82), spanY / (h * 0.82));
        }

        // ---- taman, air, jalan ----
        if (rs != null) {
            for (double[] wy : rs.park) {
                path.reset();
                for (int i = 0; i + 1 < wy.length; i += 2) {
                    if (i == 0) path.moveTo(px(wy[i + 1]), py(wy[i]));
                    else path.lineTo(px(wy[i + 1]), py(wy[i]));
                }
                path.close();
                c.drawPath(path, park);
            }
            for (double[] wy : rs.water) {
                path.reset();
                for (int i = 0; i + 1 < wy.length; i += 2) {
                    if (i == 0) path.moveTo(px(wy[i + 1]), py(wy[i]));
                    else path.lineTo(px(wy[i + 1]), py(wy[i]));
                }
                path.close();
                c.drawPath(path, water);
            }
            drawWays(c, rs.stream, stream, false);
            drawWays(c, rs.alley, alley, false);
            drawWays(c, rs.minor, minor, false);
            drawWays(c, rs.major, major, false);
        }

        // ---- rute aktif (magenta) ----
        if (rt != null) {
            path.reset();
            for (int i = 0; i < rt.lat.length; i++) {
                float x = px(rt.lon[i]), y = py(rt.lat[i]);
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            c.drawPath(path, casing);
            c.drawPath(path, core);
            c.drawPath(path, shine);
            // ujung rute: tujuan / SPBU
            int ne = rt.lat.length - 1;
            float ex = px(rt.lon[ne]), ey = py(rt.lat[ne]);
            String dn = NavService.uiDetour;
            c.drawCircle(ex, ey, 9f * d, bg);
            c.drawCircle(ex, ey, 7f * d, pin);
            String lbl = dn != null ? "SPBU " + dn : (NavService.uiDest.isEmpty() ? "Tujuan" : NavService.uiDest);
            if (lbl.length() > 26) lbl = lbl.substring(0, 26);
            float tw = txt.measureText(lbl);
            float tx = Math.max(4f * d, Math.min(w - tw - 10f * d, ex - tw / 2f));
            float ty = Math.max(20f * d, Math.min(h - 8f * d, ey - 14f * d));
            c.drawRoundRect(tx - 4f * d, ty - 13f * d, tx + tw + 4f * d, ty + 5f * d, 6f * d, 6f * d, txtBg);
            c.drawText(lbl, tx, ty, txt);
        }

        // ---- posisi kamu (panah arah) ----
        float mx = px(lo), my = py(la);
        c.drawCircle(mx, my, 11f * d, txtBg);
        c.drawCircle(mx, my, 11f * d, ring);
        c.save();
        c.rotate((float) NavService.uiHeading, mx, my);
        Path tri = new Path();
        tri.moveTo(mx, my - 8f * d);
        tri.lineTo(mx + 6f * d, my + 6f * d);
        tri.lineTo(mx, my + 2f * d);
        tri.lineTo(mx - 6f * d, my + 6f * d);
        tri.close();
        c.drawPath(tri, me);
        c.restore();

        String mode = follow ? "Ikuti posisi" : "Seluruh rute";
        float mw = txt.measureText(mode + "  (ketuk)");
        c.drawRoundRect(6f * d, h - 24f * d, 6f * d + mw + 10f * d, h - 6f * d, 6f * d, 6f * d, txtBg);
        c.drawText(mode + "  (ketuk)", 11f * d, h - 11f * d, txt);
        c.restore();
    }
}
