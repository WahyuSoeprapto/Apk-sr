package com.wsmartrider.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Cuaca dari Open-Meteo (gratis, tanpa API key), diubah ke paket Chronos. */
final class Weather {
    /** Kode ikon Chronos: 0 berawan sebagian, 1 cerah, 2 salju, 3 hujan, 4 berawan, 5 ekstrem, 6 angin, 7 kabut. */
    static int icon(int wmo) {
        if (wmo == 0 || wmo == 1) return 1;
        if (wmo == 2) return 0;
        if (wmo == 3) return 4;
        if (wmo == 45 || wmo == 48) return 7;
        if (wmo >= 51 && wmo <= 67) return 3;
        if (wmo >= 71 && wmo <= 77) return 2;
        if (wmo >= 80 && wmo <= 82) return 3;
        if (wmo == 85 || wmo == 86) return 2;
        if (wmo >= 95) return 3;
        return 4;
    }

    static volatile String uiTemp = "-";
    static volatile String uiDesc = "";
    static volatile String uiCity = "";
    static volatile long uiAt = 0;

    // ---- data lengkap untuk tab Cuaca di aplikasi ----
    static volatile int uiCode = 2;                  // kode WMO cuaca sekarang
    static volatile int uiFeels = 0, uiHum = 0, uiWind = 0, uiUv = 0, uiPress = 0, uiHigh = 0, uiLow = 0;
    static volatile String[] hrLabel = new String[0];    // 24 jam ke depan, mulai jam sekarang
    static volatile int[] hrTemp = new int[0], hrCode = new int[0], hrPop = new int[0];
    static volatile String[] dayLabel = new String[0];   // 7 hari
    static volatile int[] dayCode = new int[0], dayMax = new int[0], dayMin = new int[0], dayPop = new int[0];

    /** Emoji cuaca untuk layar HP. */
    static String emoji(int wmo) {
        if (wmo == 0 || wmo == 1) return "\u2600\uFE0F";
        if (wmo == 2) return "\u26C5";
        if (wmo == 3) return "\u2601\uFE0F";
        if (wmo == 45 || wmo == 48) return "\uD83C\uDF2B\uFE0F";
        if (wmo >= 51 && wmo <= 67) return "\uD83C\uDF27\uFE0F";
        if (wmo >= 71 && wmo <= 77) return "\u2744\uFE0F";
        if (wmo >= 80 && wmo <= 82) return "\uD83C\uDF27\uFE0F";
        if (wmo >= 85 && wmo <= 86) return "\u2744\uFE0F";
        if (wmo >= 95) return "\u26C8\uFE0F";
        return "\u2601\uFE0F";
    }

    static String desc(int wmo) {
        if (wmo == 0 || wmo == 1) return "Cerah";
        if (wmo == 2) return "Berawan sebagian";
        if (wmo == 3) return "Berawan";
        if (wmo == 45 || wmo == 48) return "Berkabut";
        if (wmo >= 51 && wmo <= 67) return "Hujan";
        if (wmo >= 71 && wmo <= 77) return "Salju";
        if (wmo >= 80 && wmo <= 82) return "Hujan lebat";
        if (wmo >= 95) return "Badai petir";
        return "Berawan";
    }

    private static int pi(double v) {
        return (int) Math.round(v);
    }

    private static int hl(int v) {
        return (v < 0 ? 0x80 : 0) | Math.min(127, Math.abs(v));
    }

    static List<byte[]> fetch(double lat, double lon) throws Exception {
        String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,weather_code,surface_pressure,relative_humidity_2m,apparent_temperature,wind_speed_10m"
                        + "&hourly=temperature_2m,weather_code,relative_humidity_2m,wind_speed_10m,uv_index,precipitation_probability"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min,uv_index_max,precipitation_probability_max"
                        + "&timezone=auto&forecast_days=7", lat, lon);
        JSONObject root = new JSONObject(Geo.http(url, null));
        JSONObject cur = root.getJSONObject("current");
        JSONObject daily = root.getJSONObject("daily");
        JSONObject hourly = root.getJSONObject("hourly");

        uiTemp = pi(cur.getDouble("temperature_2m")) + "\u00B0";
        uiDesc = desc(cur.getInt("weather_code"));
        uiCode = cur.getInt("weather_code");
        uiFeels = pi(cur.optDouble("apparent_temperature", cur.getDouble("temperature_2m")));
        uiHum = pi(cur.optDouble("relative_humidity_2m", 0));
        uiWind = pi(cur.optDouble("wind_speed_10m", 0));
        uiPress = pi(cur.optDouble("surface_pressure", 0));
        try {
            JSONArray dpm = daily.optJSONArray("precipitation_probability_max");
            JSONArray dcx = daily.getJSONArray("weather_code"), dtx = daily.getJSONArray("temperature_2m_max"), dtn = daily.getJSONArray("temperature_2m_min");
            JSONArray dtm = daily.getJSONArray("time");
            int nd = Math.min(7, dcx.length());
            String[] dl = new String[nd];
            int[] dcc = new int[nd], dmx = new int[nd], dmn = new int[nd], dpp = new int[nd];
            java.text.SimpleDateFormat inF = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
            java.text.SimpleDateFormat outF = new java.text.SimpleDateFormat("EEE", new Locale("id", "ID"));
            for (int i = 0; i < nd; i++) {
                String lbl = i == 0 ? "Hari ini" : dtm.getString(i);
                if (i > 0) try { lbl = outF.format(inF.parse(dtm.getString(i))); } catch (Exception ignored) { }
                dl[i] = lbl;
                dcc[i] = dcx.getInt(i);
                dmx[i] = pi(dtx.getDouble(i));
                dmn[i] = pi(dtn.getDouble(i));
                dpp[i] = dpm == null ? 0 : pi(dpm.optDouble(i, 0));
            }
            uiHigh = dmx.length > 0 ? dmx[0] : 0;
            uiLow = dmn.length > 0 ? dmn[0] : 0;
            dayLabel = dl; dayCode = dcc; dayMax = dmx; dayMin = dmn; dayPop = dpp;
            // 24 jam ke depan mulai dari jam sekarang
            JSONArray htm = hourly.getJSONArray("time"), htp = hourly.getJSONArray("temperature_2m"), hcd = hourly.getJSONArray("weather_code");
            JSONArray hpp = hourly.optJSONArray("precipitation_probability");
            String nowH = cur.optString("time", "").length() >= 13 ? cur.optString("time").substring(0, 13) : "";
            int st = 0;
            for (int i = 0; i < htm.length(); i++) {
                if (htm.getString(i).substring(0, 13).compareTo(nowH) >= 0) { st = i; break; }
            }
            int nh = Math.min(24, htm.length() - st);
            String[] hl2 = new String[nh];
            int[] ht2 = new int[nh], hc2 = new int[nh], hp2 = new int[nh];
            for (int i = 0; i < nh; i++) {
                String tt = htm.getString(st + i);
                hl2[i] = i == 0 ? "Skrg" : tt.substring(11, 16);
                ht2[i] = pi(htp.getDouble(st + i));
                hc2[i] = hcd.getInt(st + i);
                hp2[i] = hpp == null ? 0 : pi(hpp.optDouble(st + i, 0));
            }
            hrLabel = hl2; hrTemp = ht2; hrCode = hc2; hrPop = hp2;
            uiUv = pi(hourly.getJSONArray("uv_index").optDouble(st, 0));
        } catch (Exception ignored) {
        }
        uiAt = System.currentTimeMillis();

        JSONArray dc = daily.getJSONArray("weather_code");
        JSONArray dmax = daily.getJSONArray("temperature_2m_max");
        JSONArray dmin = daily.getJSONArray("temperature_2m_min");
        JSONArray duv = daily.getJSONArray("uv_index_max");
        int days = Math.min(7, dc.length());

        ByteArrayOutputStream a = new ByteArrayOutputStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        for (int k = 0; k < days; k++) {
            int ic, t;
            if (k == 0) {
                ic = icon(cur.getInt("weather_code"));
                t = pi(cur.getDouble("temperature_2m"));
            } else {
                ic = icon(dc.getInt(k));
                t = pi((dmax.getDouble(k) + dmin.getDouble(k)) / 2.0);
            }
            a.write((ic << 4) | (t < 0 ? 1 : 0));
            a.write(Math.abs(t) & 0xFF);
            b.write(hl(pi(dmax.getDouble(k))));
            b.write(hl(pi(dmin.getDouble(k))));
        }

        List<byte[]> out = new ArrayList<>();
        out.add(Proto.ab(0x7E, 0x80, a.toByteArray()));
        out.add(Proto.ab(0x88, 0x80, b.toByteArray()));

        int uv = pi(duv.optDouble(0, 0));
        int pr = pi(cur.optDouble("surface_pressure", 1013));
        out.add(Proto.ab(0x8A, 0x80, new byte[]{(byte) uv, (byte) (pr >> 8), (byte) (pr & 0xFF)}));

        JSONArray ht = hourly.getJSONArray("temperature_2m");
        JSONArray hc = hourly.getJSONArray("weather_code");
        JSONArray hh = hourly.getJSONArray("relative_humidity_2m");
        JSONArray hw = hourly.getJSONArray("wind_speed_10m");
        JSONArray hu = hourly.getJSONArray("uv_index");
        int size = Math.min(24, ht.length());
        ByteArrayOutputStream h = new ByteArrayOutputStream();
        h.write(size);
        h.write(0);
        for (int z = 0; z < size; z++) {
            int t = pi(ht.getDouble(z));
            int ic = icon(hc.getInt(z));
            int wind = pi(hw.getDouble(z));
            h.write((ic << 4) | (t < 0 ? 1 : 0));
            h.write(Math.abs(t) & 0xFF);
            h.write((wind >> 8) & 0xFF);
            h.write(wind & 0xFF);
            h.write(pi(hh.getDouble(z)) & 0xFF);
            h.write(pi(hu.optDouble(z, 0)) & 0xFF);
        }
        out.add(Proto.build(0xEA, 0xFE, 0x7E, 0x02, h.toByteArray()));
        return out;
    }

    private static String strip(String s) {
        String v = s == null ? "" : s.trim();
        String[] pre = {"Kota Administrasi ", "Kabupaten Administrasi ", "Kota ", "Kabupaten ", "Kecamatan ", "Kelurahan ", "Kel. ", "Kec. "};
        for (String p : pre) {
            if (v.regionMatches(true, 0, p, 0, p.length())) {
                v = v.substring(p.length());
                break;
            }
        }
        return v.trim();
    }

    private static String first(JSONObject ad, String... keys) {
        for (String k : keys) {
            String v = strip(ad.optString(k, ""));
            if (!v.isEmpty()) return v;
        }
        return "";
    }

    /** Nama daerah dari koordinat, mis. "Koja, Jakarta Utara" atau "Mangga Dua Selatan, Sawah Besar, Jakarta Pusat". */
    static String city(double lat, double lon) {
        try {
            String url = String.format(Locale.US,
                    "https://nominatim.openstreetmap.org/reverse?format=json&zoom=16&addressdetails=1"
                            + "&accept-language=id&lat=%.5f&lon=%.5f", lat, lon);
            JSONObject ad = new JSONObject(Geo.http(url, null)).getJSONObject("address");
            String kel = first(ad, "village");
            String kec = first(ad, "suburb", "city_district", "subdistrict");
            String kota = first(ad, "city", "town", "county", "state_district", "municipality");
            List<String> parts = new ArrayList<>();
            for (String p : new String[]{kel, kec, kota}) {
                if (p.isEmpty()) continue;
                boolean dup = false;
                for (String q : parts) if (q.equalsIgnoreCase(p)) dup = true;
                if (!dup) parts.add(p);
            }
            if (parts.isEmpty()) {
                String st = first(ad, "state");
                if (!st.isEmpty()) parts.add(st);
            }
            StringBuilder sb = new StringBuilder();
            for (String p : parts) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(p);
            }
            if (sb.length() > 0) {
                uiCity = sb.toString();
                return uiCity;
            }
        } catch (Exception ignored) {
        }
        return "";
    }
}
