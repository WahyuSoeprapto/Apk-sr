package com.wsmartrider.app;

import android.content.SharedPreferences;
import android.location.Location;

/** Odometer perjalanan (dihitung dari GPS, disimpan di HP). */
final class Trip {
    static volatile double km = 0;
    static volatile double total = 0;     // odometer total (tidak ikut direset)
    private static Location last;

    static synchronized void update(Location l) {
        if (l == null) return;
        if (last == null) {
            last = l;
            return;
        }
        float d = last.distanceTo(l);
        if (d >= 2f) {
            if (d <= 1000f) { km += d / 1000.0; total += d / 1000.0; }
            last = l;
        }
    }

    static synchronized void reset() {
        km = 0;
        last = null;
    }

    static void load(SharedPreferences sp) {
        try {
            km = Double.parseDouble(sp.getString("trip_km", "0"));
        } catch (Exception e) {
            km = 0;
        }
        try {
            total = Double.parseDouble(sp.getString("odo_km", "0"));
        } catch (Exception e) {
            total = 0;
        }
    }

    static void save(SharedPreferences sp) {
        sp.edit().putString("trip_km", String.valueOf(km)).putString("odo_km", String.valueOf(total)).apply();
    }
}
