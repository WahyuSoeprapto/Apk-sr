package com.wsmartrider.app;

import android.content.SharedPreferences;
import android.location.Location;

/** Odometer perjalanan (dihitung dari GPS, disimpan di HP). */
final class Trip {
    static volatile double km = 0;
    private static Location last;

    // Kecepatan cadangan (m/s) dihitung dari jarak antar titik GPS / selisih waktu.
    // Dipakai saat GPS (mis. Fake GPS / mock location) tidak mengisi nilai speed.
    private static Location spPrev;
    private static double spCalc = 0;
    private static long spAt = 0;

    static synchronized void trackSpeed(Location l) {
        long now = System.currentTimeMillis();
        if (spPrev != null) {
            long dt = l.getTime() - spPrev.getTime();
            if (dt <= 0) dt = now - spAt;                       // mock sering memakai waktu yang sama
            if (dt >= 300 && dt <= 15000) {
                double v = spPrev.distanceTo(l) / (dt / 1000.0);
                if (v < 70.0) {                                  // buang lompatan tidak wajar (> 250 km/jam)
                    spCalc = spCalc <= 0 ? v : spCalc * 0.4 + v * 0.6;
                    spAt = now;
                    spPrev = l;
                }
            } else if (dt > 15000) {
                spCalc = 0;
                spPrev = l;
            }
        } else {
            spPrev = l;
            spAt = now;
        }
    }

    /** Kecepatan terbaik (m/s): nilai asli GPS bila ada, kalau tidak hasil hitungan sendiri. */
    static synchronized double speedMs(Location l) {
        if (l != null && l.hasSpeed() && l.getSpeed() > 0.3f) return l.getSpeed();
        if (System.currentTimeMillis() - spAt > 4000L) return 0;
        return spCalc;
    }

    static synchronized void update(Location l) {
        if (l == null) return;
        trackSpeed(l);
        if (last == null) {
            last = l;
            return;
        }
        float d = last.distanceTo(l);
        if (d >= 2f) {
            if (d <= 1000f) km += d / 1000.0;
            last = l;
        }
    }

    static synchronized void reset() {
        km = 0;
        last = null;
    }

    static void load(SharedPreferences sp) {
        try {
            km = Double.parseDouble(sp.getString("trip_km", "0"));
        } catch (Exception e) {
            km = 0;
        }
    }

    static void save(SharedPreferences sp) {
        sp.edit().putString("trip_km", String.valueOf(km)).apply();
    }
}
