package com.wsmartrider.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG_TOP = 0xFF0B1030;
    private static final int BG_BOTTOM = 0xFF1B2D5C;
    private static final int CARD = 0x1AFFFFFF;
    private static final int LINE = 0x33FFFFFF;
    private static final int CYAN = 0xFF4DE3F0;
    private static final int GRAY = 0xFF9AA7C7;

    private EditText etDest, etIp;
    private TextView tvPill, tvSpeed, tvRemain, tvEta, tvRoads, tvDetail, tvAccess, tvModeInfo;
    private Button btnBle, btnWifi;
    private boolean modeBle = true;
    private boolean askedPerms = false;
    private double pickLat = Double.NaN, pickLon = Double.NaN;
    private String pickLabel = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 500);
        }
    };

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable box(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lp(float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(topDp), 0, 0);
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(box(CARD, LINE, 20));
        return c;
    }

    private void styleInput(EditText e) {
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFF7F8CAB);
        e.setTextSize(16f);
        e.setSingleLine(true);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(box(0x33000000, LINE, 12));
    }

    private Button button(String label, int fill, int stroke, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(textColor);
        b.setMinHeight(dp(50));
        b.setBackground(box(fill, stroke, 14));
        return b;
    }

    /** Satu kotak info kecil: label di atas, nilai besar di bawah. */
    private LinearLayout tile(String label, TextView value) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setBackground(box(CARD, LINE, 18));
        t.addView(text(label, 12f, GRAY, false));
        value.setTextSize(20f);
        value.setTextColor(Color.WHITE);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        value.setPadding(0, dp(4), 0, 0);
        t.addView(value);
        return t;
    }

    private LinearLayout row(View a, View b, float topDp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams pa = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pa.setMargins(0, 0, dp(5), 0);
        LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pb.setMargins(dp(5), 0, 0, 0);
        r.addView(a, pa);
        r.addView(b, pb);
        r.setLayoutParams(lp(topDp));
        return r;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("wsr", MODE_PRIVATE);

        getWindow().setStatusBarColor(BG_TOP);
        getWindow().setNavigationBarColor(BG_BOTTOM);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));

        // ---- judul ----
        root.addView(text("W-Smart Rider", 28f, Color.WHITE, true));
        TextView sub = text("Peta navigasi untuk layar OLED", 14f, GRAY, false);
        sub.setPadding(0, dp(2), 0, dp(14));
        root.addView(sub);

        // ---- status koneksi ----
        tvPill = text("Berhenti", 13f, GRAY, true);
        tvPill.setGravity(Gravity.CENTER);
        tvPill.setPadding(dp(12), dp(12), dp(12), dp(12));
        tvPill.setBackground(box(0x22FFFFFF, LINE, 26));
        root.addView(tvPill, lp(0));

        // ---- pilihan koneksi ----
        modeBle = !"wifi".equals(sp.getString("mode", "ble"));
        LinearLayout conn = card();
        conn.addView(text("Koneksi", 13f, CYAN, true));
        btnBle = button("Bluetooth", CYAN, 0, 0xFF06121F);
        btnWifi = button("Wi-Fi hotspot", 0x224DE3F0, CYAN, CYAN);
        btnBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setMode(true);
            }
        });
        btnWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setMode(false);
            }
        });
        conn.addView(row(btnBle, btnWifi, 8));
        tvModeInfo = text("", 12f, GRAY, false);
        tvModeInfo.setPadding(0, dp(8), 0, 0);
        conn.addView(tvModeInfo);
        root.addView(conn, lp(14));
        styleModeButtons();

        // ---- kartu tujuan ----
        LinearLayout dest = card();
        dest.addView(text("Tujuan", 13f, CYAN, true));
        etDest = new EditText(this);
        etDest.setHint("Ketik tempat, atau pilih di peta");
        etDest.setText(sp.getString("dest", ""));
        styleInput(etDest);
        dest.addView(etDest, lp(8));
        Button pick = button("Pilih di peta", 0x224DE3F0, CYAN, CYAN);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPicker();
            }
        });
        dest.addView(pick, lp(10));
        root.addView(dest, lp(14));

        try {
            pickLat = Double.parseDouble(sp.getString("plat", ""));
            pickLon = Double.parseDouble(sp.getString("plon", ""));
            pickLabel = String.format(Locale.US, "Titik peta: %.5f, %.5f", pickLat, pickLon);
        } catch (Exception e) {
            pickLat = Double.NaN;
            pickLon = Double.NaN;
        }

        // ---- akses notifikasi ----
        LinearLayout acc = card();
        acc.addView(text("Notifikasi, musik, dan telepon HP", 13f, CYAN, true));
        tvAccess = text("", 13f, GRAY, false);
        tvAccess.setPadding(0, dp(6), 0, 0);
        acc.addView(tvAccess);
        Button accBtn = button("Izinkan akses notifikasi", 0x224DE3F0, CYAN, CYAN);
        accBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        acc.addView(accBtn, lp(10));
        root.addView(acc, lp(14));

        // ---- kotak info ----
        tvSpeed = new TextView(this);
        tvRemain = new TextView(this);
        tvEta = new TextView(this);
        tvRoads = new TextView(this);
        root.addView(row(tile("Kecepatan", tvSpeed), tile("Sisa jarak", tvRemain), 14));
        root.addView(row(tile("Perkiraan tiba", tvEta), tile("Peta", tvRoads), 10));

        // ---- tombol ----
        Button start = button("Mulai", CYAN, 0, 0xFF06121F);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNav();
            }
        });
        Button stop = button("Berhenti", 0x22FF6B6B, 0xFFFF6B6B, 0xFFFF6B6B);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, NavService.class);
                i.setAction("STOP");
                startService(i);
            }
        });
        root.addView(row(start, stop, 14));

        // ---- pengaturan lanjutan ----
        LinearLayout adv = card();
        adv.addView(text("Alamat IP W-Smart Rider (opsional)", 13f, GRAY, false));
        etIp = new EditText(this);
        etIp.setHint("Kosongkan = otomatis");
        etIp.setInputType(InputType.TYPE_CLASS_PHONE);
        etIp.setText(sp.getString("ip", ""));
        styleInput(etIp);
        adv.addView(etIp, lp(8));
        root.addView(adv, lp(14));

        // ---- detail / pesan kesalahan ----
        tvDetail = text("", 12f, GRAY, false);
        tvDetail.setPadding(dp(4), dp(12), dp(4), 0);
        root.addView(tvDetail);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOTTOM}));
        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    private void setMode(boolean ble) {
        modeBle = ble;
        getSharedPreferences("wsr", MODE_PRIVATE).edit().putString("mode", ble ? "ble" : "wifi").apply();
        styleModeButtons();
    }

    private void styleModeButtons() {
        if (modeBle) {
            btnBle.setBackground(box(CYAN, 0, 14));
            btnBle.setTextColor(0xFF06121F);
            btnWifi.setBackground(box(0x224DE3F0, CYAN, 14));
            btnWifi.setTextColor(CYAN);
            tvModeInfo.setText("Bluetooth: peta, notifikasi, telepon, musik, cuaca, dan jam. "
                    + "Tutup/putuskan aplikasi Chronos agar tidak berebut koneksi.");
        } else {
            btnWifi.setBackground(box(CYAN, 0, 14));
            btnWifi.setTextColor(0xFF06121F);
            btnBle.setBackground(box(0x224DE3F0, CYAN, 14));
            btnBle.setTextColor(CYAN);
            tvModeInfo.setText("Wi-Fi: hanya peta. Hidupkan hotspot HP dan sambungkan W-Smart Rider ke hotspot itu. "
                    + "Fitur lain tetap lewat aplikasi Chronos.");
        }
    }

    private boolean notifAccess() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void refresh() {
        boolean na = notifAccess();
        tvAccess.setText(na ? "Akses notifikasi: aktif" : "Akses notifikasi: belum aktif (perlu untuk notifikasi WA dan musik)");
        tvAccess.setTextColor(na ? 0xFF5CFFB0 : 0xFFFFC857);
        if (!NavService.active) {
            tvPill.setText("BERHENTI");
            tvPill.setTextColor(GRAY);
        } else if (NavService.espIp == null) {
            tvPill.setText("MENUNGGU W-SMART RIDER...");
            tvPill.setTextColor(0xFFFFC857);
        } else {
            tvPill.setText("TERHUBUNG: W-SMART RIDER (" + NavService.espIp + ")");
            tvPill.setTextColor(0xFF5CFFB0);
        }
        tvSpeed.setText(NavService.kmhNow + " km/jam");
        tvRemain.setText(NavService.remainTxt);
        tvEta.setText(NavService.etaTxt);
        tvRoads.setText(NavService.roadsTxt);
        tvDetail.setText(NavService.status);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void startNav() {
        ArrayList<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ANSWER_PHONE_CALLS);
        }
        if (!need.isEmpty() && !askedPerms) {
            askedPerms = true;
            requestPermissions(need.toArray(new String[0]), 1);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tvDetail.setText("Izin lokasi diperlukan agar peta bisa berjalan.");
            return;
        }
        String dest = etDest.getText().toString().trim();
        String ip = etIp.getText().toString().trim();
        getSharedPreferences("wsr", MODE_PRIVATE).edit().putString("dest", dest).putString("ip", ip).apply();

        Intent i = new Intent(this, NavService.class);
        i.putExtra("dest", dest);
        i.putExtra("ip", ip);
        i.putExtra("mode", modeBle ? "ble" : "wifi");
        if (!Double.isNaN(pickLat) && dest.equals(pickLabel)) {
            i.putExtra("dlat", pickLat);
            i.putExtra("dlon", pickLon);
        }
        startForegroundService(i);
    }

    private void openPicker() {
        Intent i = new Intent(this, MapPickerActivity.class);
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null) {
                i.putExtra("lat", l.getLatitude());
                i.putExtra("lon", l.getLongitude());
                i.putExtra("has", true);
            }
        } catch (Exception ignored) {
        }
        startActivityForResult(i, 2);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 2 && res == RESULT_OK && data != null) {
            pickLat = data.getDoubleExtra("lat", Double.NaN);
            pickLon = data.getDoubleExtra("lon", Double.NaN);
            if (!Double.isNaN(pickLat) && !Double.isNaN(pickLon)) {
                pickLabel = String.format(Locale.US, "Titik peta: %.5f, %.5f", pickLat, pickLon);
                etDest.setText(pickLabel);
                getSharedPreferences("wsr", MODE_PRIVATE).edit()
                        .putString("plat", String.valueOf(pickLat))
                        .putString("plon", String.valueOf(pickLon)).apply();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        startNav();
    }
}
