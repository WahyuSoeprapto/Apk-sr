package com.wsmartrider.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText etDest, etIp;
    private boolean askedPerms = false;
    private double pickLat = Double.NaN, pickLon = Double.NaN;
    private String pickLabel = "";
    private TextView tvStatus;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            tvStatus.setText(NavService.status);
            handler.postDelayed(this, 500);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("wsr", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("W-Smart Rider Map");
        title.setTextSize(22f);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Hidupkan hotspot HP, sambungkan ESP32 ke hotspot itu, lalu tekan Mulai. "
                + "Kosongkan tujuan untuk mode peta saja.");
        info.setPadding(0, dp(8), 0, dp(8));
        root.addView(info);

        etDest = new EditText(this);
        etDest.setHint("Tujuan (contoh: Stasiun Gambir Jakarta)");
        etDest.setSingleLine(true);
        etDest.setText(sp.getString("dest", ""));
        root.addView(etDest);

        try {
            pickLat = Double.parseDouble(sp.getString("plat", ""));
            pickLon = Double.parseDouble(sp.getString("plon", ""));
            pickLabel = String.format(Locale.US, "Titik peta: %.5f, %.5f", pickLat, pickLon);
        } catch (Exception e) {
            pickLat = Double.NaN;
            pickLon = Double.NaN;
        }

        Button pick = new Button(this);
        pick.setText("Pilih di peta");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPicker();
            }
        });
        root.addView(pick);

        etIp = new EditText(this);
        etIp.setHint("IP ESP32 (kosongkan = otomatis)");
        etIp.setSingleLine(true);
        etIp.setInputType(InputType.TYPE_CLASS_PHONE);
        etIp.setText(sp.getString("ip", ""));
        root.addView(etIp);

        Button start = new Button(this);
        start.setText("Mulai");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNav();
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Berhenti");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, NavService.class);
                i.setAction("STOP");
                startService(i);
            }
        });
        root.addView(stop);

        tvStatus = new TextView(this);
        tvStatus.setPadding(0, dp(16), 0, 0);
        tvStatus.setText(NavService.status);
        root.addView(tvStatus);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void startNav() {
        ArrayList<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty() && !askedPerms) {
            askedPerms = true;
            requestPermissions(need.toArray(new String[0]), 1);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tvStatus.setText("Izin lokasi diperlukan agar peta bisa berjalan.");
            return;
        }
        String dest = etDest.getText().toString().trim();
        String ip = etIp.getText().toString().trim();
        getSharedPreferences("wsr", MODE_PRIVATE).edit().putString("dest", dest).putString("ip", ip).apply();

        Intent i = new Intent(this, NavService.class);
        i.putExtra("dest", dest);
        i.putExtra("ip", ip);
        if (!Double.isNaN(pickLat) && dest.equals(pickLabel)) {
            i.putExtra("dlat", pickLat);
            i.putExtra("dlon", pickLon);
        }
        startForegroundService(i);
    }

    private void openPicker() {
        Intent i = new Intent(this, MapPickerActivity.class);
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null) {
                i.putExtra("lat", l.getLatitude());
                i.putExtra("lon", l.getLongitude());
                i.putExtra("has", true);
            }
        } catch (Exception ignored) {
        }
        startActivityForResult(i, 2);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 2 && res == RESULT_OK && data != null) {
            pickLat = data.getDoubleExtra("lat", Double.NaN);
            pickLon = data.getDoubleExtra("lon", Double.NaN);
            if (!Double.isNaN(pickLat) && !Double.isNaN(pickLon)) {
                pickLabel = String.format(Locale.US, "Titik peta: %.5f, %.5f", pickLat, pickLon);
                etDest.setText(pickLabel);
                getSharedPreferences("wsr", MODE_PRIVATE).edit()
                        .putString("plat", String.valueOf(pickLat))
                        .putString("plon", String.valueOf(pickLon)).apply();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        startNav();
    }
}
