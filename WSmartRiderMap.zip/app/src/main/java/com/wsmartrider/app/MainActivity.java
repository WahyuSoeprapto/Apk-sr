package com.wsmartrider.app;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = 0xFF071321;
    private static final int PANEL = 0xFF0E2337;
    private static final int BLUE = 0xFF19B8F2;
    private static final int STROKE = 0xFF1B4F6A;
    private static final int BTN = 0xFF11364E;
    private static final int GRAY = 0xFF9FB3C8;
    private static final int GREEN = 0xFF5CFFB0;
    private static final int AMBER = 0xFFFFC857;
    private static final int DARK = 0xFF06121F;

    private EditText etDest, etIp, etTt, etOil;
    private TextView tvOil, tvPark;
    private final TextView[] tvAuto = new TextView[2];
    private Button btnAlt;
    private TextView tvPill, tvSpeed, tvTrip, tvTemp, tvWeatherSub, tvRemain, tvEta;
    private Button btnWxAuto, btnWxManual;
    // wallpaper jam
    private ImageView ivWp;
    private TextView tvWpInfo, tvWpDim;
    private Bitmap wpBase;                 // foto 240x240 hasil potong tengah (belum diredupkan)
    private boolean wpAutoSend = false;    // true: setelah foto dipilih dari galeri langsung dikirim ke alat
    private int wpDim = 40;                // persen peredupan agar jam tetap terbaca
    private EditText etWx;
    private TextView tvWxInfo;
    private LinearLayout wxEdit;
    private boolean wxEditing = false;
    private int wxVerUi = -1;
    private TextView tvMusic, tvAccess, tvModeInfo, tvNavInfo, tvDetail;
    private Button btnBle, btnWifi, btnMap, btnTurn;
    private TextView tvOverlay, tvMirror;
    private Button btnFit0, btnFit1, btnFit2, btnInv, btnQ0, btnQ1, btnColor, btnP0, btnP1, btnP2, btnD0, btnD1, btnD2, btnD3, btnMapColor;

    private boolean built = false;
    private boolean modeBle = true;
    private boolean turnNav = false;
    private boolean askedPerms = false;
    private boolean pendingStart = false;
    private boolean pendingConnectOnly = false;
    private TextView tvBg, tvConnState;
    private double pickLat = Double.NaN, pickLon = Double.NaN;
    private String pickLabel = "";

    private LocationManager locMgr;
    private volatile Location actLoc;
    private volatile double actKmh = 0;
    private long tMusicUi = 0;
    private static volatile boolean wxBusy = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (built) refresh();
            handler.postDelayed(this, 500);
        }
    };

    private final LocationListener gpsListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            actLoc = l;
            SpeedCalc.feed(l);
            actKmh = SpeedCalc.kmh(l);
            Trip.update(l);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    // ===================== util tampilan =====================
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("wsr", MODE_PRIVATE);
    }

    private GradientDrawable box(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lp(float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(topDp), 0, 0);
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 11f, BLUE, true);
        t.setLetterSpacing(0.1f);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(box(PANEL, STROKE, 20));
        return c;
    }

    private void styleInput(EditText e) {
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFF6F8399);
        e.setTextSize(16f);
        e.setSingleLine(true);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(box(0x55000000, STROKE, 12));
    }

    private Button button(String label, int fill, int stroke, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(textColor);
        b.setMinHeight(dp(48));
        b.setBackground(box(fill, stroke, 14));
        return b;
    }

    private LinearLayout tile(String label, TextView value, TextView sub) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(box(PANEL, STROKE, 18));
        t.addView(label(label));
        value.setTextSize(24f);
        value.setTextColor(Color.WHITE);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        value.setPadding(0, dp(8), 0, dp(2));
        t.addView(value);
        if (sub != null) {
            sub.setTextSize(11f);
            sub.setTextColor(GRAY);
            t.addView(sub);
        }
        return t;
    }

    private LinearLayout row(View a, View b, float topDp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams pa = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        pa.setMargins(0, 0, dp(5), 0);
        LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        pb.setMargins(dp(5), 0, 0, 0);
        r.addView(a, pa);
        r.addView(b, pb);
        r.setLayoutParams(lp(topDp));
        return r;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ===================== siklus hidup =====================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        locMgr = (LocationManager) getSystemService(LOCATION_SERVICE);
        showSplash();
    }

    private void showSplash() {
        final LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.wsr_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splash.addView(logo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView name = text("W-SMART RIDER", 22f, Color.rgb(7, 35, 58), false);
        name.setGravity(Gravity.CENTER);
        name.setLetterSpacing(0.12f);
        splash.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(70)));
        setContentView(splash);
        splash.postDelayed(new Runnable() {
            @Override
            public void run() {
                ObjectAnimator a = ObjectAnimator.ofFloat(splash, View.ALPHA, 1f, 0f);
                a.setDuration(850);
                a.setInterpolator(new DecelerateInterpolator());
                a.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        buildDashboard();
                    }
                });
                a.start();
            }
        }, 1200);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
        if (built) startGps();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
        try {
            locMgr.removeUpdates(gpsListener);
        } catch (Exception ignored) {
        }
        if (built) Trip.save(prefs());
    }

    private void startGps() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            locMgr.removeUpdates(gpsListener);
            locMgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, gpsListener);
            if (actLoc == null) {
                Location last = locMgr.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last == null) last = locMgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                actLoc = last;
            }
        } catch (Exception ignored) {
        }
    }

    // ===================== dashboard =====================
    private void buildDashboard() {
        SharedPreferences sp = prefs();
        Trip.load(sp);
        modeBle = !"wifi".equals(sp.getString("mode", "ble"));
        turnNav = "turn".equals(sp.getString("nav", "map"));
        try {
            pickLat = Double.parseDouble(sp.getString("plat", ""));
            pickLon = Double.parseDouble(sp.getString("plon", ""));
            pickLabel = String.format(Locale.US, "Titik peta: %.5f, %.5f", pickLat, pickLon);
        } catch (Exception e) {
            pickLat = Double.NaN;
            pickLon = Double.NaN;
        }

        tabViews.clear();
        for (int i = 0; i < 5; i++) tabViews.add(new java.util.ArrayList<View>());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(14), dp(18), dp(24));

        // ---- judul ----
        TextView h = text("W-SMART RIDER", 25f, Color.WHITE, true);
        h.setLetterSpacing(0.06f);
        root.addView(h);
        TextView sub = text("SMART COCKPIT  \u2022  RIDE CONNECTED", 11f, BLUE, false);
        sub.setLetterSpacing(0.08f);
        sub.setPadding(0, dp(2), 0, dp(12));
        root.addView(sub);

        // ---- status koneksi ----
        tvPill = text("\u25CF  Berhenti", 14f, GRAY, true);
        tvPill.setPadding(dp(16), dp(16), dp(16), dp(16));
        tvPill.setBackground(box(PANEL, STROKE, 16));
        tabAdd(root, 0, tvPill, lp(0));

        // ---- kecepatan ----
        LinearLayout speed = new LinearLayout(this);
        speed.setOrientation(LinearLayout.VERTICAL);
        speed.setGravity(Gravity.CENTER);
        speed.setPadding(dp(12), dp(20), dp(12), dp(20));
        speed.setBackground(box(PANEL, STROKE, 24));
        TextView sl = label("KECEPATAN SAAT INI");
        sl.setLetterSpacing(0.12f);
        speed.addView(sl);
        tvSpeed = text("0", 76f, Color.WHITE, true);
        tvSpeed.setGravity(Gravity.CENTER);
        speed.addView(tvSpeed);
        speed.addView(text("km/jam  \u2022  berdasarkan GPS", 12f, GRAY, false));
        tabAdd(root, 0, speed, lp(14));

        // ---- jarak perjalanan & cuaca ----
        tvTrip = new TextView(this);
        tvTemp = new TextView(this);
        tvWeatherSub = new TextView(this);
        LinearLayout tripTile = tile("JARAK PERJALANAN", tvTrip, text("Tahan untuk reset", 11f, GRAY, false));
        tripTile.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Trip.reset();
                Trip.save(prefs());
                toast("Jarak perjalanan direset");
                return true;
            }
        });
        tabAdd(root, 0, row(tripTile, tile("CUACA", tvTemp, tvWeatherSub), 12), null);

        // ---- lokasi cuaca ----
        LinearLayout wx = card();
        wx.addView(label("LOKASI CUACA"));
        btnWxAuto = button("Ikuti GPS", BLUE, 0, DARK);
        btnWxManual = button("Atur sendiri", BTN, STROKE, Color.WHITE);
        btnWxAuto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wxEditing = false;
                WeatherLoc.setAuto(prefs());
                Weather.uiAt = 0;
                styleWxButtons();
                toast("Cuaca mengikuti GPS HP secara otomatis");
            }
        });
        btnWxManual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wxEditing = true;
                styleWxButtons();
            }
        });
        wx.addView(row(btnWxAuto, btnWxManual, 10));
        tvWxInfo = text("", 12f, GRAY, false);
        tvWxInfo.setPadding(0, dp(8), 0, 0);
        wx.addView(tvWxInfo);
        wxEdit = new LinearLayout(this);
        wxEdit.setOrientation(LinearLayout.VERTICAL);
        etWx = new EditText(this);
        etWx.setHint("Ketik daerah, mis. Koja Jakarta Utara");
        etWx.setText(prefs().getString("wx_name", ""));
        styleInput(etWx);
        wxEdit.addView(etWx, lp(10));
        Button wxApply = button("Terapkan lokasi cuaca", BTN, STROKE, Color.WHITE);
        wxApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyWxPlace();
            }
        });
        wxEdit.addView(wxApply, lp(10));
        wx.addView(wxEdit);
        Button wxNow = button("Perbarui cuaca sekarang", BTN, STROKE, Color.WHITE);
        wxNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Weather.uiAt = 0;
                WeatherLoc.refreshNow();
                toast("Memperbarui cuaca...");
            }
        });
        wx.addView(wxNow, lp(10));
        tabAdd(root, 3, wx, lp(14));
        styleWxButtons();

        // ---- koneksi ----
        LinearLayout conn = card();
        conn.addView(label("KONEKSI"));
        btnBle = button("Bluetooth", BLUE, 0, DARK);
        btnWifi = button("Wi-Fi hotspot", BTN, STROKE, Color.WHITE);
        btnBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setMode(true);
            }
        });
        btnWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setMode(false);
            }
        });
        conn.addView(row(btnBle, btnWifi, 10));
        tvModeInfo = text("", 12f, GRAY, false);
        tvModeInfo.setPadding(0, dp(8), 0, 0);
        conn.addView(tvModeInfo);
        // sambungkan ke W-Smart Rider tanpa harus memulai navigasi
        tvConnState = text("", 13f, GRAY, false);
        tvConnState.setPadding(0, dp(12), 0, 0);
        conn.addView(tvConnState);
        Button cBtn = button("Sambungkan", BLUE, 0, DARK);
        cBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NavService.active) {
                    toast("Sudah tersambung");
                    return;
                }
                prefs().edit().putBoolean("autoconnect", true).apply();
                startNav(true);
            }
        });
        Button dBtn = button("Putuskan", 0x33FF6B6B, 0xFFFF6B6B, 0xFFFF6B6B);
        dBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs().edit().putBoolean("autoconnect", false).apply();
                Intent i = new Intent(MainActivity.this, NavService.class);
                i.setAction("STOP");
                startService(i);
            }
        });
        conn.addView(row(cBtn, dBtn, 10));
        tabAdd(root, 0, conn, lp(14));

        // ---- navigasi ----
        LinearLayout nav = card();
        nav.addView(label("NAVIGASI"));
        etDest = new EditText(this);
        etDest.setHint("Ketik tempat, atau pilih di peta");
        etDest.setText(sp.getString("dest", ""));
        styleInput(etDest);
        nav.addView(etDest, lp(10));
        Button pick = button("Pilih tujuan di peta", BTN, STROKE, Color.WHITE);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPicker();
            }
        });
        nav.addView(pick, lp(10));
        TextView tl = text("Tampilan di layar W-Smart Rider", 12f, GRAY, false);
        tl.setPadding(0, dp(14), 0, 0);
        nav.addView(tl);
        btnMap = button("Peta", BLUE, 0, DARK);
        btnTurn = button("Belokan demi belokan", BTN, STROKE, Color.WHITE);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setNav(false);
            }
        });
        btnTurn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setNav(true);
            }
        });
        nav.addView(row(btnMap, btnTurn, 6));
        tvNavInfo = text("", 12f, GRAY, false);
        tvNavInfo.setPadding(0, dp(8), 0, 0);
        nav.addView(tvNavInfo);
        btnMapColor = button("Peta berwarna (layar TFT)", BTN, STROKE, Color.WHITE);
        btnMapColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.mapColor = !MirrorService.mapColor;
                prefs().edit().putBoolean("map_color", MirrorService.mapColor).apply();
                styleMirrorButtons();
            }
        });
        nav.addView(btnMapColor, lp(8));
        TextView mapColorNote = text("Mode peta tampil berwarna (jalan, rute, banner). Mengikuti ukuran di tab Mirror; 240 hanya lewat Wi-Fi.", 11f, GRAY, false);
        mapColorNote.setPadding(0, dp(4), 0, dp(4));
        nav.addView(mapColorNote);
        tvRemain = new TextView(this);
        tvEta = new TextView(this);
        nav.addView(row(tile("SISA JARAK", tvRemain, null), tile("PERKIRAAN TIBA", tvEta, null), 12));
        Button start = button("Mulai", BLUE, 0, DARK);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNav(false);
            }
        });
        Button stop = button("Berhenti", 0x33FF6B6B, 0xFFFF6B6B, 0xFFFF6B6B);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, NavService.class);
                i.setAction("STOPNAV");                 // hanya hentikan rute; sambungan tetap hidup
                startService(i);
                toast("Navigasi dihentikan. Sambungan ke W-Smart Rider tetap aktif.");
            }
        });
        nav.addView(row(start, stop, 12));
        tabAdd(root, 1, nav, lp(14));

        // ---- musik ----
        LinearLayout music = card();
        music.addView(label("MUSIK"));
        tvMusic = text("Tidak ada musik yang diputar", 15f, Color.WHITE, false);
        tvMusic.setPadding(0, dp(8), 0, dp(8));
        music.addView(tvMusic);
        LinearLayout mrow = new LinearLayout(this);
        mrow.setOrientation(LinearLayout.HORIZONTAL);
        Button prev = button("Sebelumnya", BTN, STROKE, Color.WHITE);
        Button play = button("Putar/Jeda", BTN, STROKE, Color.WHITE);
        Button next = button("Berikutnya", BTN, STROKE, Color.WHITE);
        prev.setTextSize(12f);
        play.setTextSize(12f);
        next.setTextSize(12f);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Phone.musicControl(MainActivity.this, 2);
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Phone.musicControl(MainActivity.this, 4);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Phone.musicControl(MainActivity.this, 3);
            }
        });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mp.setMargins(dp(3), 0, dp(3), 0);
        mrow.addView(prev, mp);
        mrow.addView(play, mp);
        mrow.addView(next, mp);
        music.addView(mrow);
        tabAdd(root, 2, music, lp(14));

        // ---- notifikasi & telepon ----
        LinearLayout acc = card();
        acc.addView(label("NOTIFIKASI, MUSIK & TELEPON"));
        tvAccess = text("", 13f, GRAY, false);
        tvAccess.setPadding(0, dp(8), 0, 0);
        acc.addView(tvAccess);
        Button accBtn = button("Izinkan akses notifikasi", BTN, STROKE, Color.WHITE);
        accBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        acc.addView(accBtn, lp(10));

        tvOverlay = text("", 13f, GRAY, false);
        tvOverlay.setPadding(0, dp(14), 0, 0);
        acc.addView(tvOverlay);
        Button ovBtn = button("Izinkan tampil di atas aplikasi lain", BTN, STROKE, Color.WHITE);
        ovBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        acc.addView(ovBtn, lp(10));
        tabAdd(root, 0, acc, lp(14));

        // ---- agar tombol angkat / tolak telepon tetap jalan saat aplikasi ditutup ----
        LinearLayout bgc = card();
        bgc.addView(label("TETAP JALAN DI LATAR BELAKANG"));
        tvBg = text("", 13f, GRAY, false);
        tvBg.setPadding(0, dp(8), 0, 0);
        bgc.addView(tvBg);
        Button bg1 = button("Abaikan optimasi baterai", BTN, STROKE, Color.WHITE);
        bg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestIgnoreBattery();
            }
        });
        bgc.addView(bg1, lp(10));
        Button bg2 = button("Izin pop-up di latar belakang (Xiaomi / HyperOS)", BTN, STROKE, Color.WHITE);
        bg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMiuiPermissions();
            }
        });
        bgc.addView(bg2, lp(10));
        Button bg3 = button("Mulai otomatis (Autostart)", BTN, STROKE, Color.WHITE);
        bg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAutostart();
            }
        });
        bgc.addView(bg3, lp(10));
        tabAdd(root, 0, bgc, lp(14));

        // ---- screen mirror ----
        LinearLayout mir = card();
        mir.addView(label("SCREEN MIRROR"));
        tvMirror = text("", 13f, GRAY, false);
        tvMirror.setPadding(0, dp(8), 0, 0);
        mir.addView(tvMirror);
        Button mStart = button("Mulai mirror", BLUE, 0, DARK);
        Button mStop = button("Berhenti", 0x33FF6B6B, 0xFFFF6B6B, 0xFFFF6B6B);
        mStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMirror();
            }
        });
        mStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MirrorService.class);
                i.setAction("STOP");
                startService(i);
            }
        });
        mir.addView(row(mStart, mStop, 10));
        TextView fl = text("Bentuk tampilan di OLED", 12f, GRAY, false);
        fl.setPadding(0, dp(12), 0, 0);
        mir.addView(fl);
        btnFit0 = button("Pas", BLUE, 0, DARK);
        btnFit1 = button("Potong", BTN, STROKE, Color.WHITE);
        btnFit2 = button("Regang", BTN, STROKE, Color.WHITE);
        View.OnClickListener fitL = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.fit = v == btnFit0 ? 0 : (v == btnFit1 ? 1 : 2);
                prefs().edit().putInt("mirror_fit", MirrorService.fit).apply();
                styleMirrorButtons();
            }
        };
        btnFit0.setOnClickListener(fitL);
        btnFit1.setOnClickListener(fitL);
        btnFit2.setOnClickListener(fitL);
        LinearLayout fr = new LinearLayout(this);
        fr.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        fp.setMargins(dp(3), 0, dp(3), 0);
        fr.addView(btnFit0, fp);
        fr.addView(btnFit1, fp);
        fr.addView(btnFit2, fp);
        mir.addView(fr, lp(6));
        TextView ql = text("Kualitas gambar", 12f, GRAY, false);
        ql.setPadding(0, dp(12), 0, 0);
        mir.addView(ql);
        btnQ0 = button("Tajam (teks)", BLUE, 0, DARK);
        btnQ1 = button("Foto", BTN, STROKE, Color.WHITE);
        View.OnClickListener qL = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.quality = v == btnQ0 ? 0 : 1;
                prefs().edit().putInt("mirror_q", MirrorService.quality).apply();
                styleMirrorButtons();
            }
        };
        btnQ0.setOnClickListener(qL);
        btnQ1.setOnClickListener(qL);
        LinearLayout qr = new LinearLayout(this);
        qr.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        qp.setMargins(dp(3), 0, dp(3), 0);
        qr.addView(btnQ0, qp);
        qr.addView(btnQ1, qp);
        mir.addView(qr, lp(6));

        TextView pl = text("Bagian layar HP yang ditampilkan (bentuk \"Potong\")", 12f, GRAY, false);
        pl.setPadding(0, dp(12), 0, 0);
        mir.addView(pl);
        btnP0 = button("Atas", BTN, STROKE, Color.WHITE);
        btnP1 = button("Tengah", BLUE, 0, DARK);
        btnP2 = button("Bawah", BTN, STROKE, Color.WHITE);
        View.OnClickListener pL = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.pos = v == btnP0 ? 0 : (v == btnP2 ? 2 : 1);
                prefs().edit().putInt("mirror_pos", MirrorService.pos).apply();
                styleMirrorButtons();
            }
        };
        btnP0.setOnClickListener(pL);
        btnP1.setOnClickListener(pL);
        btnP2.setOnClickListener(pL);
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ppp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ppp.setMargins(dp(3), 0, dp(3), 0);
        pr.addView(btnP0, ppp);
        pr.addView(btnP1, ppp);
        pr.addView(btnP2, ppp);
        mir.addView(pr, lp(6));

        TextView dl = text("Detail gambar warna (piksel)", 12f, GRAY, false);
        dl.setPadding(0, dp(12), 0, 0);
        mir.addView(dl);
        btnD0 = button("120", BTN, STROKE, Color.WHITE);
        btnD1 = button("160", BLUE, 0, DARK);
        btnD2 = button("200", BTN, STROKE, Color.WHITE);
        btnD3 = button("240", BTN, STROKE, Color.WHITE);
        View.OnClickListener dL = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.colorSize = v == btnD0 ? 120 : (v == btnD2 ? 200 : (v == btnD3 ? 240 : 160));
                prefs().edit().putInt("mirror_cs", MirrorService.colorSize).apply();
                styleMirrorButtons();
            }
        };
        btnD0.setOnClickListener(dL);
        btnD1.setOnClickListener(dL);
        btnD2.setOnClickListener(dL);
        btnD3.setOnClickListener(dL);
        LinearLayout dr = new LinearLayout(this);
        dr.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams dpp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        dpp.setMargins(dp(3), 0, dp(3), 0);
        dr.addView(btnD0, dpp);
        dr.addView(btnD1, dpp);
        dr.addView(btnD2, dpp);
        dr.addView(btnD3, dpp);
        mir.addView(dr, lp(6));
        TextView dnote = text("Makin besar makin tajam, tetapi makin lambat. 240 hanya lewat Wi-Fi (W-Smart Rider tersambung ke hotspot HP); tanpa Wi-Fi, mirror pindah ke Bluetooth dan dibatasi maksimal 200.", 11f, GRAY, false);
        dnote.setPadding(0, dp(4), 0, 0);
        mir.addView(dnote);
        btnInv = button("Balik warna", BTN, STROKE, Color.WHITE);
        btnInv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.invert = !MirrorService.invert;
                prefs().edit().putBoolean("mirror_inv", MirrorService.invert).apply();
                styleMirrorButtons();
            }
        });
        mir.addView(btnInv, lp(8));
        btnColor = button("Warna (layar TFT)", BTN, STROKE, Color.WHITE);
        btnColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MirrorService.color = !MirrorService.color;
                prefs().edit().putBoolean("mirror_color", MirrorService.color).apply();
                styleMirrorButtons();
            }
        });
        mir.addView(btnColor, lp(8));
        TextView colorNote = text("Warna hanya lewat Bluetooth dan untuk layar TFT. Pakai bentuk \"Potong\" untuk Google Maps.", 11f, GRAY, false);
        colorNote.setPadding(0, dp(4), 0, 0);
        mir.addView(colorNote);
        tabAdd(root, 4, mir, lp(14));

        // ---- wallpaper jam (layar TFT) ----
        LinearLayout wp = card();
        wp.addView(label("WALLPAPER JAM (layar TFT)"));
        TextView wpNote = text("Tekan tombol biru, pilih foto dari galeri HP, lalu foto otomatis dikirim lewat Bluetooth dan tersimpan di W-Smart Rider sebagai latar halaman jam. Sambungkan dulu ke alat (tombol Sambungkan).", 12f, GRAY, false);
        wpNote.setPadding(0, dp(8), 0, dp(8));
        wp.addView(wpNote);
        ivWp = new ImageView(this);
        ivWp.setScaleType(ImageView.ScaleType.FIT_CENTER);
        ivWp.setBackground(box(0x55000000, STROKE, 12));
        wp.addView(ivWp, new LinearLayout.LayoutParams(dp(180), dp(180)));
        wpDim = prefs().getInt("wp_dim", 40);
        tvWpDim = text("", 12f, GRAY, false);
        tvWpDim.setPadding(0, dp(12), 0, 0);
        wp.addView(tvWpDim);
        SeekBar sbDim = new SeekBar(this);
        sbDim.setMax(80);
        sbDim.setProgress(wpDim);
        sbDim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                wpDim = p;
                updateWpPreview();
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                prefs().edit().putInt("wp_dim", wpDim).apply();
            }
        });
        wp.addView(sbDim);
        Button wpPick = button("Ubah wallpaper jam (pilih foto dari galeri)", BLUE, 0, DARK);
        wpPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wpAutoSend = true;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(i, "Pilih foto wallpaper"), 4);
            }
        });
        wp.addView(wpPick, lp(10));
        Button wpSend = button("Kirim ulang (setelah ubah peredupan)", BTN, STROKE, Color.WHITE);
        wpSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendWallpaper(false);
            }
        });
        Button wpDel = button("Hapus wallpaper", 0x33FF6B6B, 0xFFFF6B6B, 0xFFFF6B6B);
        wpDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendWallpaper(true);
            }
        });
        wp.addView(row(wpSend, wpDel, 10));
        tvWpInfo = text("", 12f, GRAY, false);
        tvWpInfo.setPadding(0, dp(8), 0, 0);
        wp.addView(tvWpInfo);
        tabAdd(root, 0, wp, lp(14));          // tampil di Beranda agar mudah ditemukan
        updateWpPreview();
        MirrorService.fit = prefs().getInt("mirror_fit", 0);
        MirrorService.invert = prefs().getBoolean("mirror_inv", false);
        MirrorService.quality = prefs().getInt("mirror_q", 0);
        MirrorService.color = prefs().getBoolean("mirror_color", false);
        MirrorService.mapColor = prefs().getBoolean("map_color", false);
        MirrorService.pos = prefs().getInt("mirror_pos", 1);
        MirrorService.colorSize = prefs().getInt("mirror_cs", 160);
        styleMirrorButtons();

        // ---- auto rute (tab Navigasi) ----
        LinearLayout auto = card();
        auto.addView(label("AUTO RUTE"));
        auto.addView(text("Simpan dua tujuan favorit. Saat peta tampil di W-Smart Rider, ketuk sensor sentuh untuk langsung memulai rute.", 12f, GRAY, false));
        addAutoSlot(auto, 1, "Rumah", "5x");
        addAutoSlot(auto, 2, "Tempat kerja", "6x");
        refreshAuto();
        tabAdd(root, 1, auto, lp(14));

        // ---- macet & jalur alternatif (tab Navigasi) ----
        LinearLayout route = card();
        route.addView(label("MACET & JALUR ALTERNATIF"));
        route.addView(text("Kunci API TomTom untuk warna macet asli di peta (opsional)", 12f, GRAY, false));
        etTt = new EditText(this);
        etTt.setHint("Kosongkan = perkiraan dari kecepatan");
        etTt.setSingleLine(true);
        etTt.setText(sp.getString("tt_key", ""));
        styleInput(etTt);
        route.addView(etTt, lp(8));
        Button btnTtSave = button("Simpan kunci TomTom", BTN, STROKE, Color.WHITE);
        btnTtSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs().edit().putString("tt_key", etTt.getText().toString().trim()).apply();
                toast("Kunci TomTom disimpan");
            }
        });
        route.addView(btnTtSave, lp(8));
        route.addView(text("Jalur alternatif otomatis saat macet di depan (butuh kunci TomTom)", 12f, GRAY, false));
        btnAlt = button(sp.getBoolean("alt_on", false) ? "Jalur alternatif: AKTIF" : "Jalur alternatif: MATI", BTN, STROKE, Color.WHITE);
        btnAlt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean on = !prefs().getBoolean("alt_on", false);
                prefs().edit().putBoolean("alt_on", on).apply();
                btnAlt.setText(on ? "Jalur alternatif: AKTIF" : "Jalur alternatif: MATI");
            }
        });
        route.addView(btnAlt, lp(8));
        tabAdd(root, 1, route, lp(14));

        // ---- lokasi parkir (tab Navigasi) ----
        LinearLayout park = card();
        park.addView(label("LOKASI PARKIR MOTOR"));
        tvPark = text("", 12f, GRAY, false);
        park.addView(tvPark, lp(4));
        Button btnParkSet = button("Tandai parkir di sini", BTN, STROKE, Color.WHITE);
        btnParkSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Location l = actLoc;
                if (l == null) {
                    toast("GPS belum dapat lokasi. Coba lagi sebentar.");
                    return;
                }
                prefs().edit().putString("park_lat", String.valueOf(l.getLatitude()))
                        .putString("park_lon", String.valueOf(l.getLongitude()))
                        .putLong("park_time", System.currentTimeMillis()).apply();
                toast("Lokasi parkir disimpan");
            }
        });
        park.addView(btnParkSet, lp(8));
        Button btnParkGo = button("Lihat peta motor saya", BTN, STROKE, Color.WHITE);
        btnParkGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double pla = Double.parseDouble(prefs().getString("park_lat", ""));
                    double plo = Double.parseDouble(prefs().getString("park_lon", ""));
                    Intent i = new Intent(MainActivity.this, ParkMapActivity.class);
                    i.putExtra("lat", pla);
                    i.putExtra("lon", plo);
                    i.putExtra("time", prefs().getLong("park_time", System.currentTimeMillis()));
                    startActivity(i);
                } catch (Exception e) {
                    toast("Belum ada lokasi parkir yang ditandai");
                }
            }
        });
        park.addView(btnParkGo, lp(8));
        Button btnParkDel = button("Hapus tanda parkir", 0xFF3A2A38, 0xFFFF6B6B, 0xFFFF6B6B);
        btnParkDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs().edit().remove("park_lat").remove("park_lon").remove("park_time").apply();
                toast("Tanda parkir dihapus");
            }
        });
        park.addView(btnParkDel, lp(8));
        tabAdd(root, 1, park, lp(14));

        // ---- pengaturan lanjutan ----
        LinearLayout adv = card();
        adv.addView(text("Alamat IP W-Smart Rider (khusus mode Wi-Fi, opsional)", 12f, GRAY, false));
        etIp = new EditText(this);
        etIp.setHint("Kosongkan = otomatis");
        etIp.setInputType(InputType.TYPE_CLASS_PHONE);
        etIp.setText(sp.getString("ip", ""));
        styleInput(etIp);
        adv.addView(etIp, lp(8));
        tabAdd(root, 0, adv, lp(14));

        // ---- rute pintar & servis ----
        LinearLayout smart = card();
        smart.addView(label("SERVIS OLI"));
        smart.addView(text("Ganti oli setiap berapa km (0 = nonaktif)", 12f, GRAY, false));
        etOil = new EditText(this);
        etOil.setInputType(InputType.TYPE_CLASS_NUMBER);
        etOil.setText(String.valueOf(sp.getInt("oil_int", 0)));
        styleInput(etOil);
        smart.addView(etOil, lp(8));
        Button btnOilSave = button("Simpan interval oli", BTN, STROKE, Color.WHITE);
        btnOilSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int km = 0;
                try { km = Integer.parseInt(etOil.getText().toString().trim()); } catch (Exception ignored) { }
                prefs().edit().putInt("oil_int", Math.max(0, km)).apply();
                android.widget.Toast.makeText(MainActivity.this, "Interval oli disimpan", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        smart.addView(btnOilSave, lp(8));
        Button btnOilDone = button("Oli sudah diganti (mulai hitung ulang)", BTN, STROKE, Color.WHITE);
        btnOilDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Trip.save(prefs());
                prefs().edit().putString("oil_last", String.valueOf(Trip.total)).apply();
                android.widget.Toast.makeText(MainActivity.this, "Hitungan oli diulang dari 0", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        smart.addView(btnOilDone, lp(8));
        tvOil = text("", 12f, GRAY, false);
        smart.addView(tvOil, lp(4));
        tabAdd(root, 0, smart, lp(14));

        tvDetail = text("", 12f, GRAY, false);
        tvDetail.setPadding(dp(4), dp(12), dp(4), 0);
        tabAdd(root, 0, tvDetail, null);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(BG);
        sv.addView(root);
        tabScroll = sv;

        // ---- bar menu bawah: Beranda | Navigasi | Musik | Cuaca | Mirror ----
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);
        shell.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        shell.addView(buildTabBar(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(shell);
        selectTab(prefs().getInt("tab", 0));

        built = true;
        styleModeButtons();
        styleNavButtons();
        if (prefs().getBoolean("autoconnect", false) && !NavService.active
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startNav(true);                      // dulu pernah "Sambungkan": sambungkan lagi otomatis
        }
        if (!missingPerms().isEmpty() && !askedPerms) {
            askedPerms = true;
            requestPermissions(missingPerms().toArray(new String[0]), 100);
        }
        startGps();
        refresh();
    }

    // ===================== menu bar bawah =====================
    private final java.util.List<java.util.List<View>> tabViews = new java.util.ArrayList<java.util.List<View>>();
    private final TextView[] tabIc = new TextView[5];
    private final TextView[] tabLb = new TextView[5];
    private ScrollView tabScroll;

    private void tabAdd(LinearLayout root, int tab, View v, LinearLayout.LayoutParams lp) {
        if (lp != null) root.addView(v, lp);
        else root.addView(v);
        tabViews.get(tab).add(v);
    }

    private View buildTabBar() {
        final String[] icons = {"\uD83C\uDFE0", "\uD83E\uDDED", "\uD83C\uDFB5", "\u26C5", "\uD83D\uDCF1"};
        final String[] names = {"Beranda", "Navigasi", "Musik", "Cuaca", "Mirror"};
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackground(box(PANEL, STROKE, 0));
        bar.setPadding(dp(4), dp(6), dp(4), dp(6));
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, dp(4), 0, dp(4));
            TextView ic = text(icons[i], 21f, Color.WHITE, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = text(names[i], 10f, GRAY, true);
            lb.setGravity(Gravity.CENTER);
            item.addView(ic);
            item.addView(lb);
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectTab(idx);
                }
            });
            tabIc[i] = ic;
            tabLb[i] = lb;
            bar.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        return bar;
    }

    private void selectTab(int t) {
        if (t < 0 || t > 4) t = 0;
        prefs().edit().putInt("tab", t).apply();
        for (int i = 0; i < tabViews.size(); i++) {
            for (View v : tabViews.get(i)) v.setVisibility(i == t ? View.VISIBLE : View.GONE);
            if (tabIc[i] != null) {
                tabIc[i].setAlpha(i == t ? 1f : 0.45f);
                tabLb[i].setTextColor(i == t ? BLUE : GRAY);
            }
        }
        if (tabScroll != null) tabScroll.scrollTo(0, 0);
    }

    private void toggle(Button on, Button off) {
        on.setBackground(box(BLUE, 0, 14));
        on.setTextColor(DARK);
        off.setBackground(box(BTN, STROKE, 14));
        off.setTextColor(Color.WHITE);
    }

    private void styleModeButtons() {
        if (modeBle) {
            toggle(btnBle, btnWifi);
            tvModeInfo.setText("Bluetooth: peta, belokan, notifikasi, telepon, musik, cuaca, dan jam. "
                    + "Putuskan aplikasi Chronos agar tidak berebut koneksi.");
        } else {
            toggle(btnWifi, btnBle);
            tvModeInfo.setText("Wi-Fi: hanya peta. Hidupkan hotspot HP dan sambungkan W-Smart Rider "
                    + "ke hotspot itu. Fitur lain butuh Bluetooth.");
        }
    }

    private void styleNavButtons() {
        if (turnNav) {
            toggle(btnTurn, btnMap);
            tvNavInfo.setText("Belokan: panah, jarak, dan nama jalan seperti Chronos. Dari rute di aplikasi ini, "
                    + "atau kosongkan tujuan lalu jalankan navigasi di Google Maps (diteruskan otomatis). "
                    + "Hanya lewat Bluetooth.");
        } else {
            toggle(btnMap, btnTurn);
            tvNavInfo.setText("Peta: gambar jalan sekitar dan rute di layar W-Smart Rider.");
        }
    }

    private void setMode(boolean ble) {
        modeBle = ble;
        prefs().edit().putString("mode", ble ? "ble" : "wifi").apply();
        styleModeButtons();
        if (NavService.active) startNav(false);
    }

    private void setNav(boolean turn) {
        turnNav = turn;
        prefs().edit().putString("nav", turn ? "turn" : "map").apply();
        styleNavButtons();
        if (NavService.active) startNav(false);
    }

    private void styleMirrorButtons() {
        Button[] fb = {btnFit0, btnFit1, btnFit2};
        for (int i = 0; i < 3; i++) {
            if (i == MirrorService.fit) {
                fb[i].setBackground(box(BLUE, 0, 14));
                fb[i].setTextColor(DARK);
            } else {
                fb[i].setBackground(box(BTN, STROKE, 14));
                fb[i].setTextColor(Color.WHITE);
            }
        }
        Button[] qb = {btnQ0, btnQ1};
        for (int i = 0; i < 2; i++) {
            if (i == MirrorService.quality) {
                qb[i].setBackground(box(BLUE, 0, 14));
                qb[i].setTextColor(DARK);
            } else {
                qb[i].setBackground(box(BTN, STROKE, 14));
                qb[i].setTextColor(Color.WHITE);
            }
        }
        Button[] pb = {btnP0, btnP1, btnP2};
        for (int i = 0; i < 3; i++) {
            if (i == MirrorService.pos) {
                pb[i].setBackground(box(BLUE, 0, 14));
                pb[i].setTextColor(DARK);
            } else {
                pb[i].setBackground(box(BTN, STROKE, 14));
                pb[i].setTextColor(Color.WHITE);
            }
        }
        Button[] db = {btnD0, btnD1, btnD2, btnD3};
        int curD = MirrorService.colorSize <= 120 ? 0 : (MirrorService.colorSize <= 160 ? 1 : (MirrorService.colorSize <= 200 ? 2 : 3));
        for (int i = 0; i < 4; i++) {
            boolean on = (i == curD);
            if (on) {
                db[i].setBackground(box(BLUE, 0, 14));
                db[i].setTextColor(DARK);
            } else {
                db[i].setBackground(box(BTN, STROKE, 14));
                db[i].setTextColor(Color.WHITE);
            }
        }
        if (btnMapColor != null) {
            if (MirrorService.mapColor) {
                btnMapColor.setBackground(box(BLUE, 0, 14));
                btnMapColor.setTextColor(DARK);
                btnMapColor.setText("Peta berwarna (layar TFT): hidup");
            } else {
                btnMapColor.setBackground(box(BTN, STROKE, 14));
                btnMapColor.setTextColor(Color.WHITE);
                btnMapColor.setText("Peta berwarna (layar TFT): mati");
            }
        }
        if (MirrorService.color) {
            btnColor.setBackground(box(BLUE, 0, 14));
            btnColor.setTextColor(DARK);
            btnColor.setText("Warna (layar TFT): hidup");
        } else {
            btnColor.setBackground(box(BTN, STROKE, 14));
            btnColor.setTextColor(Color.WHITE);
            btnColor.setText("Warna (layar TFT): mati");
        }
        if (MirrorService.invert) {
            btnInv.setBackground(box(BLUE, 0, 14));
            btnInv.setTextColor(DARK);
            btnInv.setText("Balik warna: hidup");
        } else {
            btnInv.setBackground(box(BTN, STROKE, 14));
            btnInv.setTextColor(Color.WHITE);
            btnInv.setText("Balik warna: mati");
        }
    }

    /** Hubungkan W-Smart Rider bila belum, lalu minta izin rekam layar. */
    private void startMirror() {
        if (MirrorService.active) {
            toast("Screen Mirror sudah aktif");
            return;
        }
        if (!NavService.active) startNav(false);
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), 3);
    }

    private boolean notifAccess() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void styleWxButtons() {
        boolean man = WeatherLoc.manual(prefs());
        if (man) toggle(btnWxManual, btnWxAuto);
        else toggle(btnWxAuto, btnWxManual);
        wxEdit.setVisibility((man || wxEditing) ? View.VISIBLE : View.GONE);
    }

    private String wxInfoText() {
        SharedPreferences p = prefs();
        if (WeatherLoc.manual(p)) {
            String n = WeatherLoc.manualName(p);
            return "Lokasi tetap: " + (n.isEmpty() ? "tempat pilihanmu" : n)
                    + ". Tidak mengikuti GPS; tekan \"Ikuti GPS\" untuk kembali otomatis.";
        }
        String c = Weather.uiCity;
        return "Mengikuti GPS HP. Daerah: " + (c.isEmpty() ? "menunggu GPS..." : c)
                + ". Cuaca dan nama daerah di W-Smart Rider berganti otomatis saat kamu berpindah sekitar 1 km.";
    }

    private void applyWxPlace() {
        final String q = etWx.getText().toString().trim();
        if (q.isEmpty()) {
            toast("Ketik nama daerah dulu");
            return;
        }
        Location l = actLoc;
        final double la = l != null ? l.getLatitude() : -6.2;
        final double lo = l != null ? l.getLongitude() : 106.8;
        toast("Mencari " + q + "...");
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final double[] p = Geo.geocode(q, la, lo);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            WeatherLoc.setManual(prefs(), p[0], p[1], q);
                            Weather.uiAt = 0;
                            wxEditing = false;
                            styleWxButtons();
                            toast("Lokasi cuaca diatur ke " + q);
                        }
                    });
                } catch (Exception e) {
                    final String m = (e.getMessage() != null && e.getMessage().contains("tidak ditemukan"))
                            ? "Daerah tidak ditemukan, coba tulis lebih lengkap" : "Gagal mencari: " + e.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toast(m);
                        }
                    });
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void maybeWeather() {
        if (wxBusy) return;
        long now = System.currentTimeMillis();
        double[] wp = WeatherLoc.pick(prefs(), actLoc);
        if (wp == null) return;
        boolean due = now - Weather.uiAt > 1800000L
                || wxVerUi != WeatherLoc.ver
                || (now - Weather.uiAt > 120000L && WeatherLoc.moved(wp[0], wp[1], 1000));
        if (!due) return;
        wxVerUi = WeatherLoc.ver;
        wxBusy = true;
        WeatherLoc.mark(wp[0], wp[1]);
        final double la = wp[0], lo = wp[1];
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Weather.fetch(la, lo);
                    Weather.city(la, lo);
                } catch (Exception e) {
                    Weather.uiAt = System.currentTimeMillis() - 1500000L;
                } finally {
                    wxBusy = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void refresh() {
        // mode peta/belokan bisa diganti dari sensor sentuh W-Smart Rider
        if (NavService.active && NavService.turnFlag != turnNav) {
            turnNav = NavService.turnFlag;
            styleNavButtons();
        }
        // koneksi
        if (!NavService.active) {
            tvPill.setText("\u25CF  Belum dimulai");
            tvPill.setTextColor(GRAY);
        } else if (NavService.espIp == null) {
            tvPill.setText("\u25CF  Mencari W-Smart Rider...");
            tvPill.setTextColor(AMBER);
        } else {
            tvPill.setText("\u25CF  Terhubung: W-Smart Rider (" + NavService.espIp + ")");
            tvPill.setTextColor(GREEN);
        }

        // kecepatan & jarak
        double kmh = NavService.active ? NavService.kmhNow : actKmh;
        tvSpeed.setText(String.format(Locale.getDefault(), "%.0f", kmh));
        tvTrip.setText(String.format(Locale.getDefault(), "%.2f km", Trip.km));
        if (tvPark != null) {
            String pt = prefs().getString("park_lat", "");
            if (pt.isEmpty()) {
                tvPark.setText("Belum ada lokasi parkir. Tekan \"Tandai parkir di sini\" saat turun dari motor, lalu lihat petanya di HP kapan saja.");
            } else {
                try {
                    double pla = Double.parseDouble(pt), plo = Double.parseDouble(prefs().getString("park_lon", "0"));
                    long ptime = prefs().getLong("park_time", 0);
                    String info = "Parkir ditandai " + new java.text.SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new java.util.Date(ptime));
                    Location cl = actLoc;
                    if (cl != null) {
                        float[] res = new float[1];
                        Location.distanceBetween(cl.getLatitude(), cl.getLongitude(), pla, plo, res);
                        info += res[0] >= 1000 ? String.format(Locale.getDefault(), " \u2022 %.1f km dari kamu", res[0] / 1000f)
                                : String.format(Locale.getDefault(), " \u2022 %.0f m dari kamu", res[0]);
                    }
                    tvPark.setText(info);
                } catch (Exception e) {
                    tvPark.setText("Data parkir tidak valid");
                }
            }
        }
        if (tvOil != null) {
            int oi = prefs().getInt("oil_int", 0);
            double ol = 0;
            try { ol = Double.parseDouble(prefs().getString("oil_last", "0")); } catch (Exception ignored) { }
            tvOil.setText(oi > 0 ? String.format(Locale.getDefault(), "Odometer total %.1f km \u2022 sisa sebelum ganti oli %.0f km", Trip.total, oi - (Trip.total - ol))
                    : String.format(Locale.getDefault(), "Odometer total %.1f km \u2022 pengingat oli nonaktif", Trip.total));
        }

        // cuaca
        maybeWeather();
        tvTemp.setText(Weather.uiTemp);
        String ws = Weather.uiDesc;
        if (!Weather.uiCity.isEmpty()) ws = ws.isEmpty() ? Weather.uiCity : ws + " \u2022 " + Weather.uiCity;
        tvWeatherSub.setText(ws.isEmpty() ? "Memuat cuaca..." : ws);
        tvWxInfo.setText(wxInfoText());

        // navigasi
        tvRemain.setText(NavService.remainTxt);
        tvEta.setText(NavService.etaTxt);

        // notifikasi & musik
        boolean na = notifAccess();
        tvAccess.setText(na ? "Akses notifikasi: aktif"
                : "Akses notifikasi belum aktif (perlu untuk notifikasi WA dan musik)");
        tvAccess.setTextColor(na ? GREEN : AMBER);
        tvConnState.setText(NavService.active
                ? (NavService.espIp == null ? "Menunggu W-Smart Rider... (jalan di latar belakang)"
                : "Tersambung. Tetap jalan walau aplikasi ditutup.")
                : "Belum tersambung. Tekan Sambungkan untuk notifikasi, telepon, musik, cuaca, dan jam.");
        tvConnState.setTextColor(NavService.active ? (NavService.espIp == null ? AMBER : GREEN) : GRAY);
        try {
            PowerManager pwm = (PowerManager) getSystemService(POWER_SERVICE);
            boolean ign = pwm != null && pwm.isIgnoringBatteryOptimizations(getPackageName());
            tvBg.setText((ign ? "Optimasi baterai: dilewati (bagus)" : "Optimasi baterai: belum dilewati")
                    + "\nXiaomi/HyperOS: aktifkan \"Tampilkan pop-up saat berjalan di latar belakang\" dan \"Mulai otomatis\" "
                    + "agar tombol Angkat/Tolak WhatsApp bekerja ketika aplikasi tidak dibuka.");
            tvBg.setTextColor(ign ? GREEN : AMBER);
        } catch (Throwable ignored) {
        }
        boolean ov = Settings.canDrawOverlays(this);
        tvOverlay.setText(ov ? "Tampil di atas aplikasi lain: aktif (angkat telepon WhatsApp)"
                : "Belum aktif: izinkan agar tombol angkat telepon WhatsApp dari W-Smart Rider bisa bekerja");
        tvOverlay.setTextColor(ov ? GREEN : AMBER);
        if (MirrorService.active) {
            tvMirror.setText("Aktif \u2022 " + MirrorService.fps + " gambar/detik"
                    + (MirrorService.via.isEmpty() ? "" : " \u2022 lewat " + MirrorService.via)
                    + (NavService.espIp == null && MirrorService.via.isEmpty() ? "\nMenunggu W-Smart Rider terhubung..." : ""));
            tvMirror.setTextColor(GREEN);
        } else {
            tvMirror.setText(MirrorService.status.equals("Mati")
                    ? "Mati. Tekan Mulai untuk menampilkan layar HP di OLED." : MirrorService.status);
            tvMirror.setTextColor(GRAY);
        }
        long now = System.currentTimeMillis();
        if (now - tMusicUi > 1000L) {
            tMusicUi = now;
            if (!na) {
                tvMusic.setText("Aktifkan akses notifikasi untuk melihat musik");
            } else {
                Phone.MusicInfo m = Phone.music(this);
                if (m == null || (m.title.isEmpty() && m.artist.isEmpty())) {
                    tvMusic.setText("Tidak ada musik yang diputar");
                } else {
                    tvMusic.setText((m.playing ? "\u25B6  " : "\u275A\u275A  ") + m.title
                            + (m.artist.isEmpty() ? "" : "\n" + m.artist));
                }
            }
        }
        tvDetail.setText(NavService.status);
    }

    // ===================== izin & mulai =====================
    private ArrayList<String> missingPerms() {
        ArrayList<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ANSWER_PHONE_CALLS);
        }
        return need;
    }

    private void startNav(boolean connectOnly) {
        ArrayList<String> need = missingPerms();
        if (!need.isEmpty() && !askedPerms) {
            askedPerms = true;
            pendingStart = true;
            pendingConnectOnly = connectOnly;
            requestPermissions(need.toArray(new String[0]), 100);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tvDetail.setText("Izin lokasi diperlukan agar peta bisa berjalan.");
            return;
        }
        String dest = connectOnly ? "" : etDest.getText().toString().trim();
        String ip = etIp.getText().toString().trim();
        if (!connectOnly) prefs().edit().putString("dest", dest).putString("ip", ip)
                .putString("tt_key", etTt.getText().toString().trim()).apply();

        Intent i = new Intent(this, NavService.class);
        i.putExtra("dest", dest);
        i.putExtra("ip", ip);
        i.putExtra("mode", modeBle ? "ble" : "wifi");
        i.putExtra("nav", turnNav ? "turn" : "map");
        if (!connectOnly && !Double.isNaN(pickLat) && dest.equals(pickLabel)) {
            i.putExtra("dlat", pickLat);
            i.putExtra("dlon", pickLon);
        }
        startForegroundService(i);
    }

    // ===== izin latar belakang =====
    private void openAppDetails() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {
        }
    }

    private void requestIgnoreBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            return;
        } catch (Exception ignored) {
        }
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            return;
        } catch (Exception ignored) {
        }
        openAppDetails();
    }

    private void openMiuiPermissions() {
        String[] cls = {"com.miui.permcenter.permissions.PermissionsEditorActivity",
                "com.miui.permcenter.permissions.AppPermissionsEditorActivity"};
        for (String c : cls) {
            try {
                Intent i = new Intent("miui.intent.action.APP_PERM_EDITOR");
                i.setClassName("com.miui.securitycenter", c);
                i.putExtra("extra_pkgname", getPackageName());
                startActivity(i);
                return;
            } catch (Exception ignored) {
            }
        }
        toast("Buka: Izin lainnya > Tampilkan pop-up saat berjalan di latar belakang > Izinkan");
        openAppDetails();
    }

    private void openAutostart() {
        try {
            Intent i = new Intent();
            i.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            startActivity(i);
            return;
        } catch (Exception ignored) {
        }
        openAppDetails();
    }

    // ---------------- auto rute (2 tujuan favorit, dipanggil dari sensor sentuh) ----------------
    private void refreshAuto() {
        for (int i = 1; i <= 2; i++) {
            TextView t = tvAuto[i - 1];
            if (t == null) continue;
            String la = prefs().getString("ar" + i + "_lat", ""), lo = prefs().getString("ar" + i + "_lon", "");
            if (la.isEmpty() || lo.isEmpty()) {
                t.setText("Lokasi belum diatur");
            } else {
                try {
                    t.setText(String.format(Locale.US, "Lokasi tersimpan: %.5f, %.5f", Double.parseDouble(la), Double.parseDouble(lo)));
                } catch (Exception e) {
                    t.setText("Lokasi belum diatur");
                }
            }
        }
    }

    private void addAutoSlot(LinearLayout c, final int slot, String defName, String taps) {
        c.addView(text("Tujuan " + slot + " \u2022 ketuk sensor " + taps + " di layar peta", 12f, GRAY, false), lp(6));
        final EditText en = new EditText(this);
        en.setSingleLine(true);
        en.setHint("Nama tujuan");
        en.setText(prefs().getString("ar" + slot + "_name", defName));
        styleInput(en);
        en.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c2) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c2) {
                prefs().edit().putString("ar" + slot + "_name", s.toString().trim()).apply();
            }

            @Override
            public void afterTextChanged(android.text.Editable e) {
            }
        });
        c.addView(en, lp(8));
        TextView st = text("", 12f, GRAY, false);
        tvAuto[slot - 1] = st;
        c.addView(st, lp(4));
        Button pick = button("Pilih dari peta", BTN, STROKE, Color.WHITE);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPicker(10 + slot);
            }
        });
        Button here = button("Pakai lokasi saya", BTN, STROKE, Color.WHITE);
        here.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Location l = actLoc;
                if (l == null) {
                    toast("GPS belum dapat lokasi. Coba lagi sebentar.");
                    return;
                }
                prefs().edit().putString("ar" + slot + "_lat", String.valueOf(l.getLatitude()))
                        .putString("ar" + slot + "_lon", String.valueOf(l.getLongitude())).apply();
                toast("Lokasi tujuan " + slot + " disimpan");
                refreshAuto();
            }
        });
        c.addView(row(pick, here, 12), lp(8));
        Button del = button("Hapus tujuan " + slot, 0xFF3A2A38, 0xFFFF6B6B, 0xFFFF6B6B);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs().edit().remove("ar" + slot + "_lat").remove("ar" + slot + "_lon").apply();
                refreshAuto();
            }
        });
        c.addView(del, lp(12));
    }

    private void openPicker() {
        openPicker(2);
    }

    private void openPicker(int req) {
        Intent i = new Intent(this, MapPickerActivity.class);
        try {
            Location l = actLoc;
            if (l == null) l = locMgr.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null) l = locMgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null) {
                i.putExtra("lat", l.getLatitude());
                i.putExtra("lon", l.getLongitude());
                i.putExtra("has", true);
            }
        } catch (Exception ignored) {
        }
        startActivityForResult(i, req);
    }

    // ---------------- wallpaper jam ----------------
    private void updateWpPreview() {
        if (tvWpDim != null) tvWpDim.setText("Peredupan foto: " + wpDim + "%  (makin tinggi, jam makin terbaca)");
        if (ivWp == null) return;
        if (wpBase != null) {
            ivWp.setImageBitmap(wpBase);
            ivWp.setColorFilter(new PorterDuffColorFilter(Color.argb(wpDim * 255 / 100, 0, 0, 0), PorterDuff.Mode.SRC_ATOP));
        } else {
            ivWp.setImageDrawable(null);
        }
    }

    /** Baca foto, putar sesuai EXIF, potong persegi dari tengah, skala ke 240x240. */
    private Bitmap loadSquare(Uri uri) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(in, null, o);
        if (in != null) in.close();
        int ss = 1;
        while (o.outWidth / (ss * 2) >= 480 && o.outHeight / (ss * 2) >= 480) ss *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = ss;
        in = getContentResolver().openInputStream(uri);
        Bitmap src = BitmapFactory.decodeStream(in, null, o);
        if (in != null) in.close();
        if (src == null) throw new Exception("Gambar tidak bisa dibaca");
        int rot = 0;
        try {
            in = getContentResolver().openInputStream(uri);
            android.media.ExifInterface ex = new android.media.ExifInterface(in);
            int ori = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL);
            if (ori == android.media.ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
            else if (ori == android.media.ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
            else if (ori == android.media.ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
            if (in != null) in.close();
        } catch (Exception ignored) {
        }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            src = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
        }
        int side = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - side) / 2, (src.getHeight() - side) / 2, side, side);
        return Bitmap.createScaledBitmap(sq, 240, 240, true);
    }

    /** 240x240 -> RGB565 little-endian (115200 byte), sekaligus meredupkan foto. */
    private byte[] toRgb565(Bitmap b, int dimPct) {
        int[] px = new int[240 * 240];
        b.getPixels(px, 0, 240, 0, 0, 240, 240);
        int k = 100 - dimPct;
        byte[] out = new byte[240 * 240 * 2];
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            int r = ((p >> 16) & 0xFF) * k / 100;
            int g = ((p >> 8) & 0xFF) * k / 100;
            int bl = (p & 0xFF) * k / 100;
            int c = ((r >> 3) << 11) | ((g >> 2) << 5) | (bl >> 3);
            out[2 * i] = (byte) (c & 0xFF);
            out[2 * i + 1] = (byte) (c >> 8);
        }
        return out;
    }

    private void sendWallpaper(final boolean delete) {
        final NavService svc = NavService.inst;
        if (svc == null || !NavService.active) {
            tvWpInfo.setText("Belum terhubung. Tekan Sambungkan di tab Beranda dulu.");
            return;
        }
        if (!delete && wpBase == null) {
            tvWpInfo.setText("Pilih foto dulu.");
            return;
        }
        final byte[] data = delete ? null : toRgb565(wpBase, wpDim);
        tvWpInfo.setText(delete ? "Menghapus wallpaper..." : "Mengirim wallpaper...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String via = svc.sendWallpaper(data);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (via.startsWith("!")) tvWpInfo.setText(via.substring(1));
                        else if (delete) tvWpInfo.setText("Perintah hapus dikirim lewat " + via + ".");
                        else tvWpInfo.setText("Terkirim lewat " + via + (via.equals("Bluetooth")
                                ? " (sekitar 20-40 detik). Layar jam berganti otomatis setelah selesai."
                                : ". Layar jam berganti otomatis dalam beberapa detik."));
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 4) {
            if (res == RESULT_OK && data != null && data.getData() != null) {
                final Uri uri = data.getData();
                tvWpInfo.setText("Memproses foto...");
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            final Bitmap bm = loadSquare(uri);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    wpBase = bm;
                                    updateWpPreview();
                                    if (wpAutoSend) {
                                        wpAutoSend = false;
                                        sendWallpaper(false);          // langsung kirim lewat Bluetooth / Wi-Fi
                                    } else {
                                        tvWpInfo.setText("Foto siap. Atur peredupan, lalu tekan Kirim.");
                                    }
                                }
                            });
                        } catch (final Exception e) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    tvWpInfo.setText("Gagal membaca foto: " + e.getMessage());
                                }
                            });
                        }
                    }
                }).start();
            }
            return;
        }
        if (req == 3) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, MirrorService.class);
                i.putExtra("code", res);
                i.putExtra("data", data);
                startForegroundService(i);
            } else {
                toast("Izin rekam layar ditolak");
            }
            return;
        }
        if ((req == 11 || req == 12) && res == RESULT_OK && data != null) {     // auto rute: titik dari peta
            double pla = data.getDoubleExtra("lat", Double.NaN), plo = data.getDoubleExtra("lon", Double.NaN);
            if (!Double.isNaN(pla) && !Double.isNaN(plo)) {
                int sl = req - 10;
                prefs().edit().putString("ar" + sl + "_lat", String.valueOf(pla)).putString("ar" + sl + "_lon", String.valueOf(plo)).apply();
                toast("Lokasi tujuan " + sl + " disimpan");
                refreshAuto();
            }
            return;
        }
        if (req == 2 && res == RESULT_OK && data != null) {
            pickLat = data.getDoubleExtra("lat", Double.NaN);
            pickLon = data.getDoubleExtra("lon", Double.NaN);
            if (!Double.isNaN(pickLat) && !Double.isNaN(pickLon)) {
                pickLabel = String.format(Locale.US, "Titik peta: %.5f, %.5f", pickLat, pickLon);
                etDest.setText(pickLabel);
                prefs().edit().putString("plat", String.valueOf(pickLat))
                        .putString("plon", String.valueOf(pickLon)).apply();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (built) startGps();
        if (pendingStart) {
            pendingStart = false;
            startNav(pendingConnectOnly);
        }
    }
}
