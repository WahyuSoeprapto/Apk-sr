package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Locale;

public class NavService extends Service {
    static volatile String status = "Berhenti";

    private static final int PORT_ESP = 4210;    // ESP32 menerima peta di sini
    private static final int PORT_HELLO = 4211;  // ESP32 mengumumkan diri ke sini
    private static final int HDR = 36;
    private static final int FRAME = 1024;

    private volatile boolean running = false;
    private DatagramSocket sock;
    private volatile InetAddress espAddr;
    private volatile String manualIp = "";
    private volatile long lastHello = 0;

    private LocationManager lm;
    private LocationListener listener;
    private volatile Location loc;
    private PowerManager.WakeLock wl;

    private volatile String destText = "";
    private volatile double[] destPt = null;
    private volatile Route route = null;
    private volatile boolean routing = false;
    private volatile long routeFailAt = 0;
    private volatile String routeErr = null;
    private long lastReroute = 0;
    private int offCnt = 0;

    private volatile RoadSet roads = null;
    private volatile boolean roadsLoading = false;
    private volatile long roadsFailAt = 0;
    private volatile String roadsErr = null;

    private final Renderer renderer = new Renderer();
    private double heading = 0;
    private boolean headingInit = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startAsForeground();

        if (intent != null) {
            String d = intent.getStringExtra("dest");
            String ip = intent.getStringExtra("ip");
            destText = d == null ? "" : d.trim();
            manualIp = ip == null ? "" : ip.trim();
            destPt = null;
            route = null;
            routeErr = null;
            routeFailAt = 0;
            if (intent.hasExtra("dlat") && intent.hasExtra("dlon")) {
                destPt = new double[]{intent.getDoubleExtra("dlat", 0), intent.getDoubleExtra("dlon", 0)};
            }
        }

        if (!running) {
            running = true;
            startLocation();
            startNetwork();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("nav", "Navigasi", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);
        Intent stop = new Intent(this, NavService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "nav")
                .setContentTitle("W-Smart Rider Map")
                .setContentText("Mengirim peta ke W-Smart Rider")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }
    }

    private void startLocation() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wsr:nav");
            wl.acquire();
        } catch (Exception ignored) {
        }
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                loc = l;
            }

            @Override
            public void onStatusChanged(String provider, int st, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper());
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null && loc == null) loc = last;
        } catch (SecurityException e) {
            status = "Izin lokasi ditolak";
        } catch (Exception e) {
            status = "GPS error: " + e.getMessage();
        }
    }

    private void startNetwork() {
        try {
            sock = new DatagramSocket(null);
            sock.setReuseAddress(true);
            sock.bind(new InetSocketAddress(PORT_HELLO));
            sock.setBroadcast(true);
        } catch (Exception e) {
            status = "Socket gagal: " + e.getMessage();
            running = false;
            stopSelf();
            return;
        }

        // penerima "hello" dari ESP32 -> tahu alamat IP-nya
        Thread rx = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] b = new byte[64];
                DatagramPacket p = new DatagramPacket(b, b.length);
                while (running) {
                    try {
                        p.setLength(b.length);
                        sock.receive(p);
                        if (p.getLength() >= 4 && b[0] == 'W' && b[1] == 'S' && b[2] == 'R' && b[3] == '1') {
                            lastHello = System.currentTimeMillis();
                            if (manualIp.isEmpty()) espAddr = p.getAddress();
                        }
                    } catch (Exception e) {
                        if (!running) break;
                    }
                }
            }
        });
        rx.setDaemon(true);
        rx.start();

        Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                while (running) {
                    long t0 = System.currentTimeMillis();
                    try {
                        tick();
                    } catch (Throwable e) {
                        status = "Error: " + e;
                    }
                    long dt = System.currentTimeMillis() - t0;
                    try {
                        Thread.sleep(Math.max(50L, 500L - dt));
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }
        });
        worker.setDaemon(true);
        worker.start();
    }

    private static double distM(double la1, double lo1, double la2, double lo2) {
        double dx = (lo2 - lo1) * 111320.0 * Math.cos(Math.toRadians(la1));
        double dy = (la2 - la1) * 110540.0;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static double smoothAngle(double old, double nw) {
        double diff = ((nw - old + 540.0) % 360.0) - 180.0;
        return (old + diff * 0.6 + 360.0) % 360.0;
    }

    private static float angleFor(String mod) {
        switch (mod) {
            case "uturn": return 180f;
            case "sharp right": return 135f;
            case "right": return 90f;
            case "slight right": return 45f;
            case "slight left": return -45f;
            case "left": return -90f;
            case "sharp left": return -135f;
            default: return 0f;
        }
    }

    private void requestRoute(final double la, final double lo) {
        if (routing) return;
        routing = true;
        final String dd = destText;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    double[] dp = destPt;
                    if (dp == null) {
                        dp = Geo.geocode(dd, la, lo);
                        destPt = dp;
                    }
                    Route r = Geo.route(la, lo, dp[0], dp[1]);
                    route = r;
                    routeErr = null;
                } catch (Exception e) {
                    routeErr = String.valueOf(e.getMessage());
                    routeFailAt = System.currentTimeMillis();
                } finally {
                    routing = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void loadRoads(final double la, final double lo) {
        if (roadsLoading) return;
        roadsLoading = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    roads = Geo.roads(la, lo);
                    roadsErr = null;
                } catch (Exception e) {
                    roadsErr = String.valueOf(e.getMessage());
                    roadsFailAt = System.currentTimeMillis();
                } finally {
                    roadsLoading = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void tick() throws Exception {
        // alamat ESP32 manual (jika diisi)
        String mip = manualIp;
        if (!mip.isEmpty()) {
            InetAddress cur = espAddr;
            if (cur == null || !mip.equals(cur.getHostAddress())) {
                try {
                    espAddr = InetAddress.getByName(mip);
                } catch (Exception ignored) {
                }
            }
        }

        Location l = loc;
        if (l == null) {
            status = "Menunggu sinyal GPS...\n(coba di luar ruangan)";
            return;
        }
        final double la = l.getLatitude(), lo = l.getLongitude();
        long now = System.currentTimeMillis();

        // ---- data jalan ----
        RoadSet rs = roads;
        if (!roadsLoading && (rs == null || distM(la, lo, rs.cLat, rs.cLon) > 300.0)
                && now - roadsFailAt > 20000L) {
            loadRoads(la, lo);
        }

        // ---- rute ----
        String dt = destText;
        boolean wantRoute = dt != null && !dt.isEmpty();
        Route rt = route;
        if (wantRoute && rt == null && !routing && now - routeFailAt > 10000L) {
            requestRoute(la, lo);
        }

        double progress = 0;
        int curSeg = 0;
        int flags = 0;
        int arrowKind = 0;
        float arrowAngle = 0f;
        int distNext = 0, eta = 0, remain10 = 0;
        String name = "";
        double remaining = 0;

        if (rt != null) {
            double p = rt.project(la, lo, false);
            if (rt.offDist > 60.0) p = rt.project(la, lo, true);
            if (rt.offDist > 60.0) offCnt++;
            else offCnt = 0;
            if (offCnt >= 4 && !routing && now - lastReroute > 15000L) {
                offCnt = 0;
                lastReroute = now;
                requestRoute(la, lo);
            }
            progress = p;
            curSeg = rt.curSeg;
            remaining = Math.max(0, rt.totalDist - p);

            int next = -1;
            for (int i = 0; i < rt.nSteps; i++) {
                if (rt.stepDist[i] > p + 8.0) {
                    next = i;
                    break;
                }
            }
            if (remaining < 25.0 || next < 0) {
                flags |= 1;                  // tiba
                arrowKind = 2;
                name = "Tujuan";
            } else {
                String type = rt.stepType[next];
                if ("arrive".equals(type)) {
                    arrowKind = 2;
                    name = rt.stepName[next].isEmpty() ? "Tujuan" : rt.stepName[next];
                } else {
                    arrowKind = 1;
                    arrowAngle = angleFor(rt.stepMod[next]);
                    name = rt.stepName[next];
                }
                distNext = (int) Math.max(0, Math.min(65535, rt.stepDist[next] - p));
            }
            eta = (int) Math.min(65535, Math.round(rt.totalDur * (remaining / rt.totalDist) / 60.0));
            remain10 = (int) Math.min(65535, remaining / 10.0);
        } else {
            flags |= 2;                      // sembunyikan jarak belokan
            if (!wantRoute) name = "Mode peta";
            else if (routing) name = "Mencari rute...";
            else if (routeErr != null) name = "Rute gagal";
            else name = "Mencari rute...";
        }

        // ---- arah & skala ----
        double spd = l.hasSpeed() ? l.getSpeed() : 0.0;
        if (spd > 1.5 && l.hasBearing()) {
            heading = headingInit ? smoothAngle(heading, l.getBearing()) : l.getBearing();
            headingInit = true;
        } else if (rt != null) {
            double rb = rt.bearing(curSeg);
            heading = headingInit ? smoothAngle(heading, rb) : rb;
            headingInit = true;
        }
        double kmh = spd * 3.6;
        double scale = kmh < 20 ? 3.0 : (kmh < 45 ? 5.0 : (kmh < 70 ? 7.0 : 10.0));

        // ---- gambar & kirim ----
        byte[] frame = renderer.render(la, lo, heading, scale, roads, rt, curSeg, progress, arrowKind, arrowAngle);
        byte[] pkt = new byte[HDR + FRAME];
        pkt[0] = 'M';
        pkt[1] = 'P';
        pkt[2] = (byte) flags;
        pkt[3] = 0;
        pkt[4] = (byte) (distNext & 0xFF);
        pkt[5] = (byte) ((distNext >> 8) & 0xFF);
        pkt[6] = (byte) Math.min(255, (int) Math.round(kmh));
        pkt[8] = (byte) (eta & 0xFF);
        pkt[9] = (byte) ((eta >> 8) & 0xFF);
        pkt[10] = (byte) (remain10 & 0xFF);
        pkt[11] = (byte) ((remain10 >> 8) & 0xFF);
        String nm = Geo.clean(name);
        for (int i = 0; i < nm.length() && i < 23; i++) pkt[12 + i] = (byte) nm.charAt(i);
        System.arraycopy(frame, 0, pkt, HDR, FRAME);

        InetAddress a = espAddr;
        boolean sent = false;
        if (a != null) {
            try {
                sock.send(new DatagramPacket(pkt, pkt.length, a, PORT_ESP));
                sent = true;
            } catch (Exception ignored) {
            }
        }

        // ---- status untuk layar HP ----
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.US, "GPS OK (%.0f km/jam)\n", kmh));
        if (a == null) sb.append("W-Smart Rider: belum terdeteksi\n(sambungkan W-Smart Rider ke hotspot HP)\n");
        else sb.append("W-Smart Rider: ").append(a.getHostAddress()).append(sent ? " (terkirim)\n" : " (gagal kirim)\n");
        if (rt != null) {
            sb.append(String.format(Locale.US, "Rute: sisa %.1f km, %d menit\n", remaining / 1000.0, eta));
        } else if (wantRoute) {
            sb.append(routing ? "Rute: mencari...\n" : "Rute: " + routeErr + "\n");
        } else {
            sb.append("Mode peta saja (tanpa tujuan)\n");
        }
        RoadSet cur = roads;
        if (cur != null) sb.append("Peta: ").append(cur.major.size() + cur.minor.size()).append(" jalan\n");
        else sb.append(roadsLoading ? "Peta: mengunduh...\n" : "Peta: " + roadsErr + "\n");
        status = sb.toString();
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (lm != null && listener != null) lm.removeUpdates(listener);
        } catch (Exception ignored) {
        }
        try {
            if (sock != null) sock.close();
        } catch (Exception ignored) {
        }
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) {
        }
        status = "Berhenti";
        super.onDestroy();
    }
}
