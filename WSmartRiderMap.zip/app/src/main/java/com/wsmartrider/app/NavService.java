package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.os.PowerManager;
import android.telephony.TelephonyManager;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NavService extends Service {
    static volatile String status = "Berhenti";
    static volatile boolean active = false;
    static volatile boolean gpsOk = false;
    static volatile int kmhNow = 0;
    static volatile String espIp = null;      // nama/alamat W-Smart Rider jika terhubung
    static volatile String remainTxt = "-";
    static volatile String etaTxt = "-";
    static volatile String roadsTxt = "-";
    static volatile String musicText = "";
    static volatile NavService inst;            // dipakai Screen Mirror untuk memakai jalur kirim yang sama
    static volatile boolean turnFlag = false;   // true = mode belokan demi belokan (untuk layar HP)

    private static final int PORT_ESP = 4210;    // W-Smart Rider menerima peta (Wi-Fi) di sini
    private static final int PORT_HELLO = 4211;  // W-Smart Rider mengumumkan diri ke sini (Wi-Fi)
    private static final int HDR = 60;     // nama jalan sampai 47 karakter
    private static final int FRAME = 1024;

    private volatile boolean running = false;
    private volatile boolean bleMode = true;
    private BleLink ble;
    private DatagramSocket sock;
    private volatile InetAddress espAddr;
    private volatile String manualIp = "";
    private volatile long lastHello = 0;

    private LocationManager lm;
    private LocationListener listener;
    private volatile Location loc;
    private PowerManager.WakeLock wl;

    private volatile String destText = "";
    private volatile double[] destPt = null;
    private volatile Route route = null;
    private volatile boolean routing = false;
    private volatile long routeFailAt = 0;
    private volatile String routeErr = null;
    private long lastReroute = 0;
    private int offCnt = 0;

    private volatile RoadSet roads = null;
    private volatile Traffic traffic = null;
    private volatile boolean trafBusy = false;
    private volatile String trafErr = null;
    private long trafAt = 0;
    private long slowSince = 0;
    private volatile boolean detour = false;        // sedang menuju SPBU
    private volatile String detourName = null;
    private String savedDest = "";
    private double[] savedPt = null;
    private volatile boolean fuelBusy = false;
    private long altAt = 0;
    private long tSpd = 0;
    private long tAr = 0;
    private double oilNotifKm = -1e9;                 // sejak kapan kecepatan rendah (untuk deteksi macet)
    private volatile boolean roadsLoading = false;
    private volatile long roadsFailAt = 0;
    private volatile String roadsErr = null;

    private final Renderer renderer = new Renderer();
    private double heading = 0;
    private boolean headingInit = false;

    // ---- navigasi belokan demi belokan (gaya Chronos) ----
    private volatile boolean turnMode = false;
    private int lastIconCrc = 0;
    private boolean navActiveSent = false;
    private long tNav = 0;
    private long tTrip = 0;
    private byte[] arrowCache = null;
    private int arrowKey = -99999;

    // ---- fitur HP (mode Bluetooth) ----
    private boolean wasReady = false;
    private long tTime = 0, tBat = 0, tMusic = 0, tWeather = 0;
    private String lastMusicKey = "";
    private boolean ringingSent = false;
    private volatile boolean weatherBusy = false;
    private int wxVer = -1;
    private volatile String weatherErr = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && "STOPNAV".equals(intent.getAction())) {
            // hanya hentikan navigasi (rute); sambungan ke W-Smart Rider tetap hidup
            destText = "";
            destPt = null;
            detour = false;
            detourName = null;
            route = null;
            routeErr = null;
            routeFailAt = 0;
            tNav = 0;
            return START_NOT_STICKY;
        }
        startAsForeground();
        inst = this;
        showOverlayKeeper();

        if (intent != null) {
            String d = intent.getStringExtra("dest");
            String ip = intent.getStringExtra("ip");
            destText = d == null ? "" : d.trim();
            manualIp = ip == null ? "" : ip.trim();
            Renderer.zoomOut = getSharedPreferences("wsr", MODE_PRIVATE).getBoolean("zoom_out", true) ? 1.5 : 1.0;
            bleMode = !"wifi".equals(intent.getStringExtra("mode"));
            turnMode = "turn".equals(intent.getStringExtra("nav"));
            turnFlag = turnMode;
            navActiveSent = false;
            lastIconCrc = 0;
            destPt = null;
            route = null;
            routeErr = null;
            routeFailAt = 0;
            if (intent.hasExtra("dlat") && intent.hasExtra("dlon")) {
                destPt = new double[]{intent.getDoubleExtra("dlat", 0), intent.getDoubleExtra("dlon", 0)};
            }
        }

        if (!running) {
            running = true;
            active = true;
            startLocation();
            startNetwork();
        }
        applyTransport();
        return START_NOT_STICKY;
    }

    /** Hidupkan Bluetooth atau matikan sesuai mode yang dipilih. */
    private void applyTransport() {
        if (bleMode && ble == null) {
            ble = new BleLink(this, new BleLink.Listener() {
                @Override
                public void onCommand(byte[] d) {
                    onBleCommand(d);
                }
            });
            ble.start();
            NotifService.sink = new NotifService.Sink() {
                @Override
                public void onNotif(int icon, String title, String text) {
                    BleLink b = ble;
                    if (b != null) b.send(Proto.notification(icon, title, text));
                }

                @Override
                public void onWaCall(boolean ringing, boolean video, String name) {
                    BleLink b = ble;
                    if (b == null) return;
                    // penanda WA| / WAV| di depan nama dibaca oleh sketch untuk menampilkan layar panggilan WhatsApp
                    if (ringing) b.send(Proto.ringer(true, (video ? "WAV|" : "WA|") + name));
                    else b.send(Proto.ringer(false, ""));
                }

                @Override
                public void onWaOngoing(boolean active, boolean video, String name) {
                    BleLink b = ble;
                    if (b == null) return;
                    // WAC| / WACV| = panggilan WhatsApp sedang berlangsung (layar "BERLANGSUNG" + tahan untuk akhiri)
                    if (active) b.send(Proto.ringer(true, (video ? "WACV|" : "WAC|") + name));
                    else b.send(Proto.ringer(false, ""));
                }
            };
            wasReady = false;
        } else if (!bleMode && ble != null) {
            NotifService.sink = null;
            ble.stop();
            ble = null;
        }
    }

    // ===== jendela penjaga (1x1 piksel, tak terlihat) =====
    // Tombol "Jawab" WhatsApp membuka layar panggilan (activity). Android hanya mengizinkannya dari latar belakang
    // bila aplikasi punya jendela yang terlihat; jendela overlay 1 piksel ini memenuhi syarat itu (perlu izin
    // "tampil di atas aplikasi lain").
    private View overlayView;
    private long tOverlay = 0;
    private final Handler mainH = new Handler(Looper.getMainLooper());

    private void showOverlayKeeper() {
        if (overlayView != null || Build.VERSION.SDK_INT < 26) return;
        try {
            if (!Settings.canDrawOverlays(this)) return;
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            View v = new View(this);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.TOP | Gravity.START;
            wm.addView(v, p);
            overlayView = v;
        } catch (Throwable ignored) {
        }
    }

    private void hideOverlayKeeper() {
        View v = overlayView;
        overlayView = null;
        if (v == null) return;
        try {
            ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(v);
        } catch (Throwable ignored) {
        }
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("nav", "Navigasi", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);
        Intent stop = new Intent(this, NavService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "nav")
                .setContentTitle("W-Smart Rider")
                .setContentText("Terhubung ke W-Smart Rider")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }
    }

    private void startLocation() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wsr:nav");
            wl.acquire();
        } catch (Exception ignored) {
        }
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                loc = l;
                SpeedCalc.feed(l);
                Trip.update(l);
            }

            @Override
            public void onStatusChanged(String provider, int st, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper());
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null && loc == null) loc = last;
        } catch (SecurityException e) {
            status = "Izin lokasi ditolak";
        } catch (Exception e) {
            status = "GPS error: " + e.getMessage();
        }
    }

    private void startNetwork() {
        try {
            sock = new DatagramSocket(null);
            sock.setReuseAddress(true);
            sock.bind(new InetSocketAddress(PORT_HELLO));
            sock.setBroadcast(true);
        } catch (Exception e) {
            status = "Socket gagal: " + e.getMessage();
            running = false;
            stopSelf();
            return;
        }

        // penerima "hello" dari W-Smart Rider (mode Wi-Fi)
        Thread rx = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] b = new byte[64];
                DatagramPacket p = new DatagramPacket(b, b.length);
                while (running) {
                    try {
                        p.setLength(b.length);
                        sock.receive(p);
                        if (p.getLength() >= 4 && b[0] == 'W' && b[1] == 'S' && b[2] == 'R' && b[3] == '1') {
                            lastHello = System.currentTimeMillis();
                            if (manualIp.isEmpty()) espAddr = p.getAddress();
                        }
                    } catch (Exception e) {
                        if (!running) break;
                    }
                }
            }
        });
        rx.setDaemon(true);
        rx.start();

        Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                while (running) {
                    long t0 = System.currentTimeMillis();
                    try {
                        phoneTick();
                        tick();
                    } catch (Throwable e) {
                        status = "Error: " + e;
                    }
                    long dt = System.currentTimeMillis() - t0;
                    try {
                        Thread.sleep(Math.max(50L, 500L - dt));
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }
        });
        worker.setDaemon(true);
        worker.start();
    }

    // ===================== fitur HP lewat Bluetooth =====================

    private void onBleCommand(byte[] d) {
        if (d == null || d.length < 7) return;
        if ((d[0] & 0xFF) != 0xAB || (d[3] & 0xFF) != 0xFF) return;
        int c4 = d[4] & 0xFF, c5 = d[5] & 0xFF, c6 = d[6] & 0xFF;
        if (c4 == 0xC6) {
            handleCall(c6 == 0x01);
        } else if (c4 == 0xC7) {
            setTurnFromDevice(c6 == 0x01);                // tahan sensor di layar Maps: peta <-> belokan
        } else if (c4 == 0xCC) {
            startAutoRoute(c6);                           // ketuk 5x / 6x di peta: auto rute ke tujuan favorit 1 / 2
        } else if (c4 == 0xCA) {
            toggleFuel();                                 // ketuk 4x di peta: SPBU terdekat <-> kembali ke rute awal
        } else if (c4 == 0xC9) {
            boolean out = c6 == 0x01;                     // ketuk 2x di peta = zoom semula, 3x = zoom out
            Renderer.zoomOut = out ? 1.5 : 1.0;
            getSharedPreferences("wsr", MODE_PRIVATE).edit().putBoolean("zoom_out", out).apply();
        } else if (c4 == 0x9D && c5 == 0x80) {
            Phone.musicControl(this, c6);                 // 0 putar, 1 jeda, 2 sebelumnya, 3 berikutnya
        } else if (c4 == 0x99 && c5 == 0x80) {
            if (c6 == 0x00) Phone.musicControl(this, 4);  // putar/jeda
            else if (c6 == 0xA1) Phone.volume(this, 1, 0);
            else if (c6 == 0xA2) Phone.volume(this, 2, 0);
            else if (c6 == 0xA3) Phone.volume(this, 3, 0);
            else if (c6 == 0xA0 && d.length >= 8) Phone.volume(this, 0, d[7] & 0xFF);
        }
    }

    private void notifyEsp(String title, String text) {
        BleLink b = ble;
        if (b != null) {
            try {
                b.send(Proto.notification(0, title, text));
            } catch (Exception ignored) {
            }
        }
    }

    /** Kirim nama dua tujuan favorit ke W-Smart Rider (untuk menu pop-up). */
    private void sendAutoNames(BleLink b) {
        android.content.SharedPreferences sp = getSharedPreferences("wsr", MODE_PRIVATE);
        for (int sl = 1; sl <= 2; sl++) {
            String nm = sp.getString("ar" + sl + "_name", sl == 1 ? "Rumah" : "Tempat kerja");
            if (nm == null || nm.trim().isEmpty()) nm = sl == 1 ? "Rumah" : "Tempat kerja";
            nm = Geo.clean(nm);
            if (nm.length() > 14) nm = nm.substring(0, 14);
            boolean set = !sp.getString("ar" + sl + "_lat", "").isEmpty();
            byte[] nb = nm.getBytes(java.nio.charset.StandardCharsets.US_ASCII);
            byte[] pl = new byte[2 + nb.length];
            pl[0] = (byte) sl;
            pl[1] = (byte) (set ? 1 : 0);
            System.arraycopy(nb, 0, pl, 2, nb.length);
            try {
                b.send(Proto.ab(0xCD, 0x80, pl));
            } catch (Exception ignored) {
            }
        }
    }

    /** Mulai rute otomatis ke tujuan favorit nomor slot (1 atau 2) yang disimpan di aplikasi. */
    private void startAutoRoute(int slot) {
        if (slot < 1 || slot > 2) return;
        android.content.SharedPreferences sp = getSharedPreferences("wsr", MODE_PRIVATE);
        String name = sp.getString("ar" + slot + "_name", slot == 1 ? "Rumah" : "Tempat kerja");
        if (name.isEmpty()) name = slot == 1 ? "Rumah" : "Tempat kerja";
        String la = sp.getString("ar" + slot + "_lat", ""), lo = sp.getString("ar" + slot + "_lon", "");
        if (la.isEmpty() || lo.isEmpty()) {
            notifyEsp("Auto rute " + slot, "Belum diatur di aplikasi");
            return;
        }
        try {
            double[] pt = new double[]{Double.parseDouble(la), Double.parseDouble(lo)};
            detour = false;
            detourName = null;
            savedDest = "";
            savedPt = null;
            destPt = pt;
            destText = name;
            route = null;
            traffic = null;
            trafAt = 0;
            routeErr = null;
            routeFailAt = 0;
            notifyEsp("Auto rute", "Menuju " + name);
        } catch (Exception e) {
            notifyEsp("Auto rute " + slot, "Lokasi tidak valid");
        }
    }

    /** Ketuk 4x di peta: cari SPBU terdekat dan arahkan ke sana; ketuk lagi = kembali ke tujuan semula. */
    private void toggleFuel() {
        if (detour) {
            endDetour();
            notifyEsp("Rute awal", savedDest.isEmpty() ? "Mode peta" : savedDest);
            return;
        }
        final Location l = loc;
        if (l == null || fuelBusy) return;
        fuelBusy = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String[] f = Geo.fuelNear(l.getLatitude(), l.getLongitude());
                    savedDest = destText;
                    savedPt = destPt;
                    destPt = new double[]{Double.parseDouble(f[0]), Double.parseDouble(f[1])};
                    destText = "SPBU";
                    detourName = f[2];
                    detour = true;
                    route = null;
                    traffic = null;
                    trafAt = 0;
                    routeErr = null;
                    routeFailAt = 0;
                    notifyEsp("SPBU terdekat", f[2] + " " + f[3] + " m");
                } catch (Exception e) {
                    notifyEsp("SPBU", "Tidak ditemukan dalam 6 km");
                } finally {
                    fuelBusy = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    /** Batalkan rute SPBU dan kembali ke tujuan semula (atau mode peta bila sebelumnya tanpa tujuan). */
    private void endDetour() {
        detour = false;
        detourName = null;
        destPt = savedPt;
        destText = savedDest == null ? "" : savedDest;
        route = null;
        traffic = null;
        trafAt = 0;
        routeErr = null;
        routeFailAt = 0;
    }

    /** Cari jalur alternatif yang tidak melewati bagian rute yang macet. */
    private void tryAlternative(final double la, final double lo, final Route rt, final double jFrom, final double jTo,
                                final double remaining) {
        final double[] dp = destPt;
        if (dp == null || routing) return;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<Route> alts = Geo.routes(la, lo, dp[0], dp[1]);
                    // titik-titik macet di rute sekarang
                    java.util.ArrayList<double[]> jp = new java.util.ArrayList<>();
                    for (int i = 0; i < rt.cum.length; i++) {
                        if (rt.cum[i] >= jFrom && rt.cum[i] <= jTo && (jp.isEmpty() || i % 3 == 0)) {
                            jp.add(new double[]{rt.lat[i], rt.lon[i]});
                        }
                    }
                    if (jp.isEmpty()) return;
                    double curRemain = rt.totalDur * (remaining / rt.totalDist);
                    Route best = null;
                    for (Route a : alts) {
                        boolean hits = false;
                        for (double[] q : jp) {
                            if (Geo.distToRoute(a, q[0], q[1]) < 40.0) { hits = true; break; }
                        }
                        if (hits) continue;
                        if (a.totalDur > curRemain * 1.6 + 180.0) continue;
                        if (best == null || a.totalDur < best.totalDur) best = a;
                    }
                    if (best != null) {
                        route = best;
                        traffic = null;
                        trafAt = 0;
                        notifyEsp("Macet di depan", "Pindah ke jalur alternatif");
                    }
                } catch (Exception ignored) {
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    /** Dipanggil saat sensor sentuh W-Smart Rider ditahan di layar Maps. Rute tidak diulang. */
    private void setTurnFromDevice(boolean turn) {
        if (turn == turnMode) return;
        turnMode = turn;
        turnFlag = turn;
        navActiveSent = false;     // ikon panah dikirim ulang
        lastIconCrc = 0;
        tNav = 0;                  // kirim data belokan segera
        getSharedPreferences("wsr", MODE_PRIVATE).edit().putString("nav", turn ? "turn" : "map").apply();
    }

    private boolean phoneOngoing = false;
    private String lastPhoneCaller = "";

    private void handleCall(boolean answer) {
        if (NotifService.waOngoing != null) {              // panggilan WhatsApp berlangsung: sentuhan tahan = akhiri
            if (!answer) {
                boolean ok = NotifService.hangupWa(this);
                if (!ok) Phone.reject(this);
            }
            return;
        }
        if (phoneOngoing) {                                // panggilan telepon biasa berlangsung
            if (!answer) Phone.reject(this);
            return;
        }
        if (ringingSent) {
            if (answer) Phone.answer(this);
            else Phone.reject(this);
        } else if (NotifService.waCall != null) {
            NotifService.actWaCall(this, answer);
        } else {
            if (answer) Phone.answer(this);
            else Phone.reject(this);
        }
    }

    /** Bluetooth sanggup membawa frame warna (butuh MTU besar). */
    boolean colorOk() {
        BleLink b = ble;
        return bleMode && b != null && b.ready && b.mtu() >= 120;
    }

    /**
     * W-Smart Rider terhubung ke hotspot HP dan baru saja mengumumkan diri (hello) -> Screen Mirror boleh lewat Wi-Fi,
     * walau fitur lain (notifikasi, telepon, musik, belokan) tetap lewat Bluetooth.
     */
    boolean wifiMirrorOk() {
        return sock != null && espAddr != null && System.currentTimeMillis() - lastHello < 6000L;
    }

    /** MTU Bluetooth saat ini (0 bila belum tersambung). */
    int bleMtu() {
        BleLink b = ble;
        return b == null ? 0 : b.mtu();
    }

    /** Gambar warna bisa dikirim lewat Wi-Fi atau Bluetooth. */
    boolean colorAvailable() {
        return wifiMirrorOk() || colorOk();
    }

    private int udpFrame = 0;

    /** Kirim lewat UDP; paket besar dipotong 1200 byte karena ESP32 tidak menyusun ulang paket IP yang terpecah. */
    private boolean sendUdp(byte[] pkt, InetAddress a) throws Exception {
        DatagramSocket sk = sock;
        if (a == null || sk == null) return false;
        if (pkt.length <= 1400) {
            sk.send(new DatagramPacket(pkt, pkt.length, a, PORT_ESP));
            return true;
        }
        udpFrame = (udpFrame + 1) & 0xFF;
        java.util.List<byte[]> ch = Proto.mapChunksPer(pkt, 1200, udpFrame);
        int i = 0;
        for (byte[] c : ch) {
            sk.send(new DatagramPacket(c, c.length, a, PORT_ESP));
            if (++i % 3 == 0) Thread.sleep(1);       // jeda kecil agar antrean terima ESP32 tidak meluap
        }
        return true;
    }

    /** Kirim wallpaper jam (data = 240x240 RGB565 little-endian, 115200 byte) atau hapus (data = null).
     *  Hasil: "Wi-Fi" / "Bluetooth" bila terkirim, atau pesan yang diawali "!" bila gagal. Panggil dari thread latar. */
    String sendWallpaper(byte[] data) {
        final boolean del = data == null;
        final int sess = (int) ((System.currentTimeMillis() / 1000L) & 0xFF);
        try {
            InetAddress a = espAddr;
            DatagramSocket sk = sock;
            if (wifiMirrorOk() && a != null && sk != null) {
                java.util.List<byte[]> ch = del ? java.util.Collections.singletonList(Proto.wallDelete())
                        : Proto.wallChunks(data, 220, sess);
                for (int pass = 0; pass < (del ? 3 : 2); pass++) {       // dua putaran: potongan yang hilang terisi
                    for (byte[] c : ch) {
                        sk.send(new DatagramPacket(c, c.length, a, PORT_ESP));
                        Thread.sleep(4);
                    }
                }
                return "Wi-Fi";
            }
        } catch (Exception ignored) {
        }
        BleLink b = ble;
        if (bleMode && b != null && b.ready) {
            int per = Math.min(220, b.mtu() - 15);
            if (per < 29) return "!MTU Bluetooth terlalu kecil (" + b.mtu() + ")";
            b.sendQueued(del ? java.util.Collections.singletonList(Proto.wallDelete()) : Proto.wallChunks(data, per, sess));
            return "Bluetooth";
        }
        return "!Belum terhubung ke W-Smart Rider (tekan Sambungkan dulu)";
    }

    /** Kirim paket peta lewat Bluetooth; frame warna besar otomatis lewat Wi-Fi bila tersedia. */
    private void sendMapPkt(byte[] pkt, BleLink b) {
        if (pkt == null) return;
        try {
            if (pkt.length > 4000 && wifiMirrorOk()) {
                sendUdp(pkt, espAddr);
                return;
            }
        } catch (Exception ignored) {
        }
        b.sendMap(pkt);
    }

    /** Lewat mana frame mirror dikirim saat ini: "Wi-Fi", "Bluetooth" atau "". */
    String mirrorVia() {
        if (wifiMirrorOk()) return "Wi-Fi";
        BleLink b = ble;
        if (bleMode && b != null && b.ready) return "Bluetooth";
        if (!bleMode && espAddr != null) return "Wi-Fi";
        return "";
    }

    /** Dipanggil MirrorService: kirim satu frame Screen Mirror lewat Bluetooth atau Wi-Fi. */
    boolean pushMirror(byte[] pkt) {
        try {
            // 1) otomatis lewat Wi-Fi bila ESP32 terhubung ke hotspot HP (lebih cepat, bisa 240x240)
            if (wifiMirrorOk()) return sendUdp(pkt, espAddr);
            // 2) kalau tidak ada Wi-Fi: Bluetooth (hanya untuk mirror; fitur lain tidak terpengaruh)
            if (bleMode) {
                BleLink b = ble;
                if (b == null || !b.ready) return false;
                b.sendMap(pkt);
                return true;
            }
            // 3) mode Wi-Fi penuh (tanpa Bluetooth) dengan IP manual
            return sendUdp(pkt, espAddr);
        } catch (Exception e) {
            return false;
        }
    }

    private void phoneTick() {
        final BleLink b = ble;
        if (!bleMode || b == null) return;
        if (!b.ready) {
            wasReady = false;
            return;
        }
        long now = System.currentTimeMillis();
        if (!wasReady) {
            wasReady = true;
            tTime = 0;
            tBat = 0;
            tMusic = 0;
            tWeather = 0;
            lastMusicKey = "";
            ringingSent = false;
            phoneOngoing = false;
        }
        if (now - tTime > 600000L) {
            tTime = now;
            b.send(Proto.time());
        }
        if (now - tBat > 60000L) {
            tBat = now;
            int[] bat = Phone.battery(this);
            b.send(Proto.battery(bat[0], bat[1] == 1));
        }
        if (now - tMusic > 1000L) {
            tMusic = now;
            pollMusic(b);
        }
        pollCall(b);

        double[] wp = WeatherLoc.pick(getSharedPreferences("wsr", MODE_PRIVATE), loc);
        boolean wxDue = false;
        if (wp != null) {
            if (wxVer != WeatherLoc.ver) {                 // pengaturan lokasi cuaca berubah / diminta perbarui
                wxDue = true;
            } else if (now - tWeather > 1800000L) {
                wxDue = true;
            } else if (now - tWeather > 120000L && WeatherLoc.moved(wp[0], wp[1], 1000)) {
                wxDue = true;                              // berpindah sekitar 1 km: daerah dan cuaca ikut berganti
            }
        }
        if (wxDue && !weatherBusy) {
            tWeather = now;
            wxVer = WeatherLoc.ver;
            weatherBusy = true;
            final double la = wp[0], lo = wp[1];
            WeatherLoc.mark(la, lo);
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        List<byte[]> list = Weather.fetch(la, lo);
                        String city = Weather.city(la, lo);
                        if (!city.isEmpty()) b.send(Proto.city(city));
                        for (byte[] p : list) b.send(p);
                        weatherErr = null;
                    } catch (Exception e) {
                        weatherErr = String.valueOf(e.getMessage());
                        tWeather = System.currentTimeMillis() - 1500000L; // coba lagi sekitar 5 menit
                    } finally {
                        weatherBusy = false;
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        }
    }

    private void pollMusic(BleLink b) {
        Phone.MusicInfo m = Phone.music(this);
        String key = m == null ? "" : (m.title + "|" + m.artist + "|" + m.playing + "|" + m.pkg);
        if (key.equals(lastMusicKey)) return;
        lastMusicKey = key;
        musicText = m == null ? "" : (m.title + (m.artist.isEmpty() ? "" : " - " + m.artist));
        if (m != null) {
            b.send(Proto.musicInfo(m.playing ? 1 : 0, m.app, m.pkg));
            b.send(Proto.musicTitle(m.title));
            b.send(Proto.musicArtist(m.artist));
        } else {
            b.send(Proto.musicInfo(0, "", ""));
            b.send(Proto.musicTitle(""));
            b.send(Proto.musicArtist(""));
        }
    }

    private void pollCall(BleLink b) {
        int st = Phone.callState(this);
        if (st == TelephonyManager.CALL_STATE_RINGING) {
            if (!ringingSent) {
                ringingSent = true;
                phoneOngoing = false;
                boolean fresh = System.currentTimeMillis() - NotifService.lastCallTitleAt < 15000L
                        && !NotifService.lastCallTitle.isEmpty();
                lastPhoneCaller = fresh ? NotifService.lastCallTitle : "Panggilan masuk";
                b.send(Proto.ringer(true, lastPhoneCaller));
            }
        } else if (st == TelephonyManager.CALL_STATE_OFFHOOK) {
            // panggilan telepon biasa sedang berlangsung (diangkat dari HP atau dari sensor)
            if (!phoneOngoing && NotifService.waOngoing == null) {
                phoneOngoing = true;
                ringingSent = false;
                b.send(Proto.ringer(true, "PC|" + (lastPhoneCaller.isEmpty() ? "Panggilan" : lastPhoneCaller)));
            }
        } else {
            if (ringingSent || phoneOngoing) {
                ringingSent = false;
                phoneOngoing = false;
                lastPhoneCaller = "";
                b.send(Proto.ringer(false, ""));
            }
        }
    }

    // ===================== peta & navigasi =====================

    private static double distM(double la1, double lo1, double la2, double lo2) {
        double dx = (lo2 - lo1) * 111320.0 * Math.cos(Math.toRadians(la1));
        double dy = (la2 - la1) * 110540.0;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static double smoothAngle(double old, double nw) {
        double diff = ((nw - old + 540.0) % 360.0) - 180.0;
        return (old + diff * 0.6 + 360.0) % 360.0;
    }

    private static float angleFor(String mod) {
        switch (mod) {
            case "uturn": return 180f;
            case "sharp right": return 135f;
            case "right": return 90f;
            case "slight right": return 45f;
            case "slight left": return -45f;
            case "left": return -90f;
            case "sharp left": return -135f;
            default: return 0f;
        }
    }

    private void requestRoute(final double la, final double lo) {
        if (routing) return;
        routing = true;
        final String dd = destText;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    double[] dp = destPt;
                    if (dp == null) {
                        dp = Geo.geocode(dd, la, lo);
                        destPt = dp;
                    }
                    Route r = Geo.route(la, lo, dp[0], dp[1]);
                    route = r;
                    traffic = null;
                    trafAt = 0;
                    routeErr = null;
                } catch (Exception e) {
                    routeErr = String.valueOf(e.getMessage());
                    routeFailAt = System.currentTimeMillis();
                } finally {
                    routing = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    /** Ambil kepadatan lalu lintas di beberapa titik rute di depan (TomTom), lalu simpan per potongan rute. */
    private void loadTraffic(final Route rt, final double progress, final String key) {
        if (trafBusy) return;
        trafBusy = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    double[] offs = {100, 250, 400, 550, 700};
                    double[] cen = new double[offs.length];
                    float[] rat = new float[offs.length];
                    int k = 0;
                    for (double off : offs) {
                        double d = progress + off;
                        if (d >= rt.totalDist) break;
                        int i = 0;
                        while (i < rt.cum.length - 1 && rt.cum[i] < d) i++;
                        double r = Geo.traffic(rt.lat[i], rt.lon[i], key);
                        if (r < 0) continue;
                        cen[k] = d;
                        rat[k] = (float) r;
                        k++;
                    }
                    if (k == 0) {
                        traffic = null;
                    } else {
                        Traffic tr = new Traffic();
                        tr.from = new double[k];
                        tr.to = new double[k];
                        tr.ratio = new float[k];
                        for (int j = 0; j < k; j++) {
                            tr.from[j] = j == 0 ? progress : (cen[j - 1] + cen[j]) / 2.0;
                            tr.to[j] = j == k - 1 ? cen[j] + 75.0 : (cen[j] + cen[j + 1]) / 2.0;
                            tr.ratio[j] = rat[j];
                        }
                        traffic = tr;
                    }
                    trafErr = null;
                } catch (Exception e) {
                    trafErr = String.valueOf(e.getMessage());
                } finally {
                    trafBusy = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void loadRoads(final double la, final double lo) {
        if (roadsLoading) return;
        roadsLoading = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    roads = Geo.roads(la, lo);
                    roadsErr = null;
                } catch (Exception e) {
                    roadsErr = String.valueOf(e.getMessage());
                    roadsFailAt = System.currentTimeMillis();
                } finally {
                    roadsLoading = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void tick() throws Exception {
        if (overlayView == null && System.currentTimeMillis() - tOverlay > 5000L) {   // izin baru diberikan -> pasang jendela penjaga
            tOverlay = System.currentTimeMillis();
            mainH.post(new Runnable() {
                @Override
                public void run() {
                    showOverlayKeeper();
                }
            });
        }
        String mip = manualIp;
        if (!bleMode && !mip.isEmpty()) {
            InetAddress cur0 = espAddr;
            if (cur0 == null || !mip.equals(cur0.getHostAddress())) {
                try {
                    espAddr = InetAddress.getByName(mip);
                } catch (Exception ignored) {
                }
            }
        }

        BleLink b = ble;
        boolean bleUp = bleMode && b != null && b.ready;
        final boolean mirror = MirrorService.active;      // saat Screen Mirror aktif, peta/belokan tidak dikirim
        final boolean needMap = !(bleMode && turnMode) && !mirror;

        Location l = loc;
        if (l == null) {
            StringBuilder s0 = new StringBuilder("Menunggu sinyal GPS...\n(coba di luar ruangan)");
            if (bleMode && b != null) s0.append("\n").append(b.state);
            status = s0.toString();
            gpsOk = false;
            kmhNow = 0;
            espIp = bleUp ? b.name : null;
            return;
        }
        final double la = l.getLatitude(), lo = l.getLongitude();
        long now = System.currentTimeMillis();

        // ---- data jalan ----
        RoadSet rs = roads;
        if (needMap && !roadsLoading && (rs == null || distM(la, lo, rs.cLat, rs.cLon) > 250.0)
                && now - roadsFailAt > 20000L) {
            loadRoads(la, lo);
        }

        // ---- rute ----
        String dt = destText;
        boolean wantRoute = dt != null && !dt.isEmpty();
        Route rt = route;
        if (wantRoute && rt == null && !routing && now - routeFailAt > 10000L) {
            requestRoute(la, lo);
        }

        double progress = 0;
        int curSeg = 0;
        int flags = 0;
        int arrowKind = 0;
        float arrowAngle = 0f;
        int distNext = 0, eta = 0, remain10 = 0;
        String name = "";
        double remaining = 0;

        if (rt != null) {
            double p = rt.project(la, lo, false);
            if (rt.offDist > 60.0) p = rt.project(la, lo, true);
            if (rt.offDist > 60.0) offCnt++;
            else offCnt = 0;
            if (offCnt >= 4 && !routing && now - lastReroute > 15000L) {
                offCnt = 0;
                lastReroute = now;
                requestRoute(la, lo);
            }
            progress = p;
            curSeg = rt.curSeg;
            remaining = Math.max(0, rt.totalDist - p);

            int next = -1;
            for (int i = 0; i < rt.nSteps; i++) {
                if (rt.stepDist[i] > p + 8.0) {
                    next = i;
                    break;
                }
            }
            if (remaining < 25.0 || next < 0) {
                flags |= 1;
                arrowKind = 2;
                name = "Tujuan";
            } else {
                String type = rt.stepType[next];
                if ("arrive".equals(type)) {
                    arrowKind = 2;
                    name = rt.stepName[next].isEmpty() ? "Tujuan" : rt.stepName[next];
                } else {
                    arrowKind = 1;
                    arrowAngle = angleFor(rt.stepMod[next]);
                    name = rt.stepName[next];
                }
                distNext = (int) Math.max(0, Math.min(65535, rt.stepDist[next] - p));
            }
            eta = (int) Math.min(65535, Math.round(rt.totalDur * (remaining / rt.totalDist) / 60.0));
            remain10 = (int) Math.min(65535, remaining / 10.0);
        } else {
            flags |= 2;
            if (!wantRoute) name = "Mode peta";
            else if (routing) name = "Mencari rute...";
            else if (routeErr != null) name = "Rute gagal";
            else name = "Mencari rute...";
        }

        // ---- arah & skala ----
        double spd = SpeedCalc.kmh(l) / 3.6;     // m/detik; dihitung dari jarak bila GPS tidak melaporkan kecepatan
        if (spd > 1.5 && l.hasBearing()) {
            heading = headingInit ? smoothAngle(heading, l.getBearing()) : l.getBearing();
            headingInit = true;
        } else if (rt != null) {
            double rb = rt.bearing(curSeg);
            heading = headingInit ? smoothAngle(heading, rb) : rb;
            headingInit = true;
        }
        double kmh = spd * 3.6;
        // lalu lintas asli (TomTom) bila kunci API diisi di aplikasi
        final String ttKey = getSharedPreferences("wsr", MODE_PRIVATE).getString("tt_key", "").trim();
        if (rt != null && needMap && !ttKey.isEmpty() && !trafBusy && now - trafAt > 90000L) {
            trafAt = now;
            loadTraffic(rt, progress, ttKey);
        }
        final Traffic traf = ttKey.isEmpty() ? null : traffic;
        // jalur alternatif otomatis (butuh data TomTom) bila ada macet parah di ~1,2 km ke depan
        if (rt != null && traf != null && !routing && now - altAt > 180000L
                && getSharedPreferences("wsr", MODE_PRIVATE).getBoolean("alt_on", false)) {
            for (int q = 0; q < traf.ratio.length; q++) {
                if (traf.ratio[q] < 0.4f && traf.from[q] - progress < 1200.0 && traf.to[q] > progress) {
                    altAt = now;
                    tryAlternative(la, lo, rt, traf.from[q], traf.to[q], remaining);
                    break;
                }
            }
        }
        // tiba di SPBU: otomatis kembali ke tujuan semula
        if (detour && rt != null && remaining < 30.0) {
            endDetour();
            notifyEsp("Rute awal", savedDest == null || savedDest.isEmpty() ? "Mode peta" : savedDest);
        }
        // deteksi macet (perkiraan dari kecepatanmu): pelan < 12 km/j lebih dari 20 detik saat sedang menavigasi
        if (rt != null && kmh < 12.0) { if (slowSince == 0) slowSince = now; } else slowSince = 0;
        final boolean jam = traf == null && slowSince != 0 && now - slowSince > 20000L && remaining > 150.0;
        double scale = kmh < 20 ? 3.0 : (kmh < 45 ? 5.0 : (kmh < 70 ? 7.0 : 10.0));

        // ---- gambar & kirim ----
        byte[] pkt = null;
        if (needMap) {
            boolean colMap = MirrorService.mapColor && colorAvailable();
            int side = colMap ? MirrorService.effectiveSide(this) : 0;
            byte[] frame = colMap
                    ? renderer.renderColor(side, la, lo, heading, scale, roads, rt, curSeg, progress, arrowKind, arrowAngle,
                            distNext, name, eta, remain10, (int) Math.min(255, Math.round(kmh)), flags, jam, traf, detour ? detourName : null)
                    : renderer.render(la, lo, heading, scale, roads, rt, curSeg, progress, arrowKind, arrowAngle);
            pkt = new byte[HDR + frame.length];
            pkt[0] = 'M';
            pkt[1] = 'P';
            pkt[2] = (byte) (flags | (colMap ? 8 : 0));      // bit3 = gambar berwarna
            pkt[3] = (byte) side;
            pkt[4] = (byte) (distNext & 0xFF);
            pkt[5] = (byte) ((distNext >> 8) & 0xFF);
            pkt[6] = (byte) Math.min(255, (int) Math.round(kmh));
            pkt[8] = (byte) (eta & 0xFF);
            pkt[9] = (byte) ((eta >> 8) & 0xFF);
            pkt[10] = (byte) (remain10 & 0xFF);
            pkt[11] = (byte) ((remain10 >> 8) & 0xFF);
            String nm = Geo.clean(name);
            for (int i = 0; i < nm.length() && i < 47; i++) pkt[12 + i] = (byte) nm.charAt(i);
            System.arraycopy(frame, 0, pkt, HDR, frame.length);
        }

        boolean sent = false;
        boolean espUp;
        InetAddress a = espAddr;
        if (bleMode) {
            espUp = bleUp;
            if (bleUp) {
                if (mirror) {
                    // frame dikirim oleh MirrorService
                } else if (turnMode) {
                    sendTurn(b, rt, arrowKind, arrowAngle, distNext, eta, remaining, name, kmh, (flags & 1) != 0);
                } else {
                    if (navActiveSent) {
                        b.send(Proto.navOff());
                        navActiveSent = false;
                    }
                    sendMapPkt(pkt, b);
                }
                if (now - tAr > 10000L) {      // nama tujuan favorit untuk menu pop-up di W-Smart Rider
                    tAr = now;
                    sendAutoNames(b);
                }
                if (now - tSpd > 1000L) {      // kecepatan GPS HP selalu dikirim, walau tanpa rute
                    tSpd = now;
                    b.send(Proto.ab(0xCB, 0x80, new byte[]{(byte) Math.min(255, (int) Math.round(kmh))}));
                }
                sent = true;
            }
        } else {
            espUp = a != null && (!manualIp.isEmpty() || System.currentTimeMillis() - lastHello < 8000L);
            if (mirror) sent = true;
            if (a != null && pkt != null) {
                try {
                    sendUdp(pkt, a);
                    sent = true;
                } catch (Exception ignored) {
                }
            }
        }

        if (now - tTrip > 30000L) {
            tTrip = now;
            android.content.SharedPreferences spo = getSharedPreferences("wsr", MODE_PRIVATE);
            Trip.save(spo);
            int oilInt = spo.getInt("oil_int", 0);
            if (oilInt > 0 && bleUp) {
                double last = 0;
                try { last = Double.parseDouble(spo.getString("oil_last", "0")); } catch (Exception ignored) { }
                double sisa = oilInt - (Trip.total - last);
                if (sisa <= 100.0 && Trip.total - oilNotifKm >= 25.0) {
                    oilNotifKm = Trip.total;
                    notifyEsp("Servis oli", sisa > 0 ? "Ganti oli sisa " + (int) sisa + " km" : "Sudah waktunya ganti oli (lewat " + (int) (-sisa) + " km)");
                }
            }
        }

        // ---- status untuk layar HP ----
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.US, "GPS OK (%.0f km/jam)\n", kmh));
        if (bleMode) {
            sb.append(b != null ? b.state : "Bluetooth belum aktif").append("\n");
        } else if (!espUp) {
            sb.append("W-Smart Rider: belum terdeteksi\n(sambungkan W-Smart Rider ke hotspot HP)\n");
        } else {
            sb.append("W-Smart Rider (Wi-Fi): ").append(a.getHostAddress())
                    .append(sent ? " (terkirim)\n" : " (gagal kirim)\n");
        }
        if (rt != null) {
            sb.append(String.format(Locale.US, "Rute: sisa %.1f km, %d menit\n", remaining / 1000.0, eta));
        } else if (wantRoute) {
            sb.append(routing ? "Rute: mencari...\n" : "Rute: " + routeErr + "\n");
        } else {
            sb.append("Mode peta saja (tanpa tujuan)\n");
        }
        RoadSet cur = roads;
        if (cur != null) sb.append("Peta: ").append(cur.major.size() + cur.minor.size() + cur.alley.size()).append(" jalan\n");
        else sb.append(roadsLoading ? "Peta: mengunduh...\n" : "Peta: " + roadsErr + "\n");
        if (!ttKey.isEmpty()) sb.append(trafErr != null ? "Macet: " + trafErr + "\n" : (traf != null ? "Macet: data TomTom aktif\n" : "Macet: menunggu data...\n"));
        if (bleMode && weatherErr != null) sb.append("Cuaca: ").append(weatherErr).append("\n");
        status = sb.toString();

        gpsOk = true;
        kmhNow = (int) Math.round(kmh);
        if (bleMode) espIp = bleUp ? b.name : null;
        else espIp = espUp ? a.getHostAddress() : null;
        remainTxt = rt != null ? String.format(Locale.US, "%.1f km", remaining / 1000.0) : "-";
        etaTxt = rt != null ? (eta + " mnt") : "-";
        roadsTxt = cur != null ? ((cur.major.size() + cur.minor.size() + cur.alley.size()) + " jalan")
                : (roadsLoading ? "mengunduh..." : "-");
    }

    // ===================== belokan demi belokan (gaya Chronos) =====================

    private static String fmtDist(int m) {
        if (m < 1000) return m + " m";
        return String.format(Locale.US, "%.1f km", m / 1000.0);
    }

    private byte[] arrowIcon(int kind, float angle) {
        int key = kind * 1000 + (int) angle;
        if (key != arrowKey || arrowCache == null) {
            arrowCache = NavIcon.arrow((int) angle, kind == 2);
            arrowKey = key;
        }
        return arrowCache;
    }

    private byte[] arrowFromText(String text) {
        String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
        int ang = 0;
        if (t.contains("putar balik") || t.contains("u-turn") || t.contains("u turn")) ang = 180;
        else if (t.contains("kanan") || t.contains("right")) {
            ang = (t.contains("tajam") || t.contains("sharp")) ? 135
                    : ((t.contains("sedikit") || t.contains("slight")) ? 45 : 90);
        } else if (t.contains("kiri") || t.contains("left")) {
            ang = (t.contains("tajam") || t.contains("sharp")) ? -135
                    : ((t.contains("sedikit") || t.contains("slight")) ? -45 : -90);
        }
        return NavIcon.arrow(ang, false);
    }

    /** Kirim data navigasi format Chronos agar layar navigasi bawaan sketch tampil. */
    private void sendTurn(BleLink b, Route rt, int arrowKind, float arrowAngle, int distNext, int eta,
                          double remaining, String name, double kmh, boolean arrived) {
        long now = System.currentTimeMillis();
        if (now - tNav < 1000L) return;
        tNav = now;

        String dist, dur, total, etaClock, street;
        byte[] icon;
        if (rt != null) {
            dist = arrived ? "0 m" : fmtDist(distNext);
            dur = eta + " mnt";
            total = fmtDist((int) remaining);
            Calendar c = Calendar.getInstance();
            c.add(Calendar.MINUTE, eta);
            etaClock = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
            street = name;
            icon = arrowIcon(arrowKind, arrowAngle);
        } else {
            NotifService.GNav g = NotifService.gnav;
            if (g != null && now - g.at < 30000L) {
                dist = g.dist;
                dur = g.duration;
                total = g.total;
                etaClock = g.eta;
                street = g.directions;
                icon = g.icon != null ? g.icon : arrowFromText(g.directions + " " + g.dist);
            } else {
                if (navActiveSent) {
                    b.send(Proto.navOff());
                    navActiveSent = false;
                }
                return;
            }
        }
        int crc = NavIcon.crc(icon);
        if (crc != lastIconCrc || !navActiveSent) {
            for (byte[] p : Proto.navIcon(icon, crc)) b.send(p);
            lastIconCrc = crc;
        }
        b.send(Proto.navData(true, crc, dist, dur, total, etaClock, street, Math.round((float) kmh) + " km/h"));
        navActiveSent = true;
    }

    @Override
    public void onDestroy() {
        hideOverlayKeeper();
        Trip.save(getSharedPreferences("wsr", MODE_PRIVATE));
        running = false;
        inst = null;
        NotifService.sink = null;
        try {
            if (ble != null) ble.stop();
        } catch (Exception ignored) {
        }
        ble = null;
        try {
            if (lm != null && listener != null) lm.removeUpdates(listener);
        } catch (Exception ignored) {
        }
        try {
            if (sock != null) sock.close();
        } catch (Exception ignored) {
        }
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) {
        }
        status = "Berhenti";
        active = false;
        gpsOk = false;
        kmhNow = 0;
        espIp = null;
        remainTxt = "-";
        etaTxt = "-";
        roadsTxt = "-";
        super.onDestroy();
    }
}
