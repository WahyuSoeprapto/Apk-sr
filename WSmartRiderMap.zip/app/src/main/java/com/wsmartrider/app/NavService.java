package com.wsmartrider.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.telephony.TelephonyManager;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NavService extends Service {
    static volatile String status = "Berhenti";
    static volatile boolean active = false;
    static volatile boolean gpsOk = false;
    static volatile int kmhNow = 0;
    static volatile String espIp = null;      // nama/alamat W-Smart Rider jika terhubung
    static volatile String remainTxt = "-";
    static volatile String etaTxt = "-";
    static volatile String roadsTxt = "-";
    static volatile String musicText = "";

    private static final int PORT_ESP = 4210;    // W-Smart Rider menerima peta (Wi-Fi) di sini
    private static final int PORT_HELLO = 4211;  // W-Smart Rider mengumumkan diri ke sini (Wi-Fi)
    private static final int HDR = 36;
    private static final int FRAME = 1024;

    private volatile boolean running = false;
    private volatile boolean bleMode = true;
    private BleLink ble;
    private DatagramSocket sock;
    private volatile InetAddress espAddr;
    private volatile String manualIp = "";
    private volatile long lastHello = 0;

    private LocationManager lm;
    private LocationListener listener;
    private volatile Location loc;
    private PowerManager.WakeLock wl;

    private volatile String destText = "";
    private volatile double[] destPt = null;
    private volatile Route route = null;
    private volatile boolean routing = false;
    private volatile long routeFailAt = 0;
    private volatile String routeErr = null;
    private long lastReroute = 0;
    private int offCnt = 0;

    private volatile RoadSet roads = null;
    private volatile boolean roadsLoading = false;
    private volatile long roadsFailAt = 0;
    private volatile String roadsErr = null;

    private final Renderer renderer = new Renderer();
    private double heading = 0;
    private boolean headingInit = false;

    // ---- navigasi belokan demi belokan (gaya Chronos) ----
    private volatile boolean turnMode = false;
    private int lastIconCrc = 0;
    private boolean navActiveSent = false;
    private long tNav = 0;
    private long tTrip = 0;
    private byte[] arrowCache = null;
    private int arrowKey = -99999;

    // ---- fitur HP (mode Bluetooth) ----
    private boolean wasReady = false;
    private long tTime = 0, tBat = 0, tMusic = 0, tWeather = 0;
    private String lastMusicKey = "";
    private boolean ringingSent = false;
    private volatile boolean weatherBusy = false;
    private volatile String weatherErr = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startAsForeground();

        if (intent != null) {
            String d = intent.getStringExtra("dest");
            String ip = intent.getStringExtra("ip");
            destText = d == null ? "" : d.trim();
            manualIp = ip == null ? "" : ip.trim();
            bleMode = !"wifi".equals(intent.getStringExtra("mode"));
            turnMode = "turn".equals(intent.getStringExtra("nav"));
            navActiveSent = false;
            lastIconCrc = 0;
            destPt = null;
            route = null;
            routeErr = null;
            routeFailAt = 0;
            if (intent.hasExtra("dlat") && intent.hasExtra("dlon")) {
                destPt = new double[]{intent.getDoubleExtra("dlat", 0), intent.getDoubleExtra("dlon", 0)};
            }
        }

        if (!running) {
            running = true;
            active = true;
            startLocation();
            startNetwork();
        }
        applyTransport();
        return START_NOT_STICKY;
    }

    /** Hidupkan Bluetooth atau matikan sesuai mode yang dipilih. */
    private void applyTransport() {
        if (bleMode && ble == null) {
            ble = new BleLink(this, new BleLink.Listener() {
                @Override
                public void onCommand(byte[] d) {
                    onBleCommand(d);
                }
            });
            ble.start();
            NotifService.sink = new NotifService.Sink() {
                @Override
                public void onNotif(int icon, String title, String text) {
                    BleLink b = ble;
                    if (b != null) b.send(Proto.notification(icon, title, text));
                }
            };
            wasReady = false;
        } else if (!bleMode && ble != null) {
            NotifService.sink = null;
            ble.stop();
            ble = null;
        }
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("nav", "Navigasi", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);
        Intent stop = new Intent(this, NavService.class);
        stop.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "nav")
                .setContentTitle("W-Smart Rider")
                .setContentText("Terhubung ke W-Smart Rider")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }
    }

    private void startLocation() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wsr:nav");
            wl.acquire();
        } catch (Exception ignored) {
        }
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                loc = l;
                Trip.update(l);
            }

            @Override
            public void onStatusChanged(String provider, int st, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper());
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null && loc == null) loc = last;
        } catch (SecurityException e) {
            status = "Izin lokasi ditolak";
        } catch (Exception e) {
            status = "GPS error: " + e.getMessage();
        }
    }

    private void startNetwork() {
        try {
            sock = new DatagramSocket(null);
            sock.setReuseAddress(true);
            sock.bind(new InetSocketAddress(PORT_HELLO));
            sock.setBroadcast(true);
        } catch (Exception e) {
            status = "Socket gagal: " + e.getMessage();
            running = false;
            stopSelf();
            return;
        }

        // penerima "hello" dari W-Smart Rider (mode Wi-Fi)
        Thread rx = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] b = new byte[64];
                DatagramPacket p = new DatagramPacket(b, b.length);
                while (running) {
                    try {
                        p.setLength(b.length);
                        sock.receive(p);
                        if (p.getLength() >= 4 && b[0] == 'W' && b[1] == 'S' && b[2] == 'R' && b[3] == '1') {
                            lastHello = System.currentTimeMillis();
                            if (manualIp.isEmpty()) espAddr = p.getAddress();
                        }
                    } catch (Exception e) {
                        if (!running) break;
                    }
                }
            }
        });
        rx.setDaemon(true);
        rx.start();

        Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                while (running) {
                    long t0 = System.currentTimeMillis();
                    try {
                        phoneTick();
                        tick();
                    } catch (Throwable e) {
                        status = "Error: " + e;
                    }
                    long dt = System.currentTimeMillis() - t0;
                    try {
                        Thread.sleep(Math.max(50L, 500L - dt));
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }
        });
        worker.setDaemon(true);
        worker.start();
    }

    // ===================== fitur HP lewat Bluetooth =====================

    private void onBleCommand(byte[] d) {
        if (d == null || d.length < 7) return;
        if ((d[0] & 0xFF) != 0xAB || (d[3] & 0xFF) != 0xFF) return;
        int c4 = d[4] & 0xFF, c5 = d[5] & 0xFF, c6 = d[6] & 0xFF;
        if (c4 == 0xC6) {
            handleCall(c6 == 0x01);
        } else if (c4 == 0x9D && c5 == 0x80) {
            Phone.musicControl(this, c6);                 // 0 putar, 1 jeda, 2 sebelumnya, 3 berikutnya
        } else if (c4 == 0x99 && c5 == 0x80) {
            if (c6 == 0x00) Phone.musicControl(this, 4);  // putar/jeda
            else if (c6 == 0xA1) Phone.volume(this, 1, 0);
            else if (c6 == 0xA2) Phone.volume(this, 2, 0);
            else if (c6 == 0xA3) Phone.volume(this, 3, 0);
            else if (c6 == 0xA0 && d.length >= 8) Phone.volume(this, 0, d[7] & 0xFF);
        }
    }

    private void handleCall(boolean answer) {
        if (ringingSent) {
            if (answer) Phone.answer(this);
            else Phone.reject(this);
        } else if (NotifService.waCall != null) {
            NotifService.actWaCall(answer);
        } else {
            if (answer) Phone.answer(this);
            else Phone.reject(this);
        }
    }

    private void phoneTick() {
        final BleLink b = ble;
        if (!bleMode || b == null) return;
        if (!b.ready) {
            wasReady = false;
            return;
        }
        long now = System.currentTimeMillis();
        if (!wasReady) {
            wasReady = true;
            tTime = 0;
            tBat = 0;
            tMusic = 0;
            tWeather = 0;
            lastMusicKey = "";
            ringingSent = false;
        }
        if (now - tTime > 600000L) {
            tTime = now;
            b.send(Proto.time());
        }
        if (now - tBat > 60000L) {
            tBat = now;
            int[] bat = Phone.battery(this);
            b.send(Proto.battery(bat[0], bat[1] == 1));
        }
        if (now - tMusic > 1000L) {
            tMusic = now;
            pollMusic(b);
        }
        pollCall(b);

        Location l = loc;
        if (l != null && !weatherBusy && now - tWeather > 1800000L) {
            tWeather = now;
            weatherBusy = true;
            final double la = l.getLatitude(), lo = l.getLongitude();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        List<byte[]> list = Weather.fetch(la, lo);
                        String city = Weather.city(la, lo);
                        if (!city.isEmpty()) b.send(Proto.city(city));
                        for (byte[] p : list) b.send(p);
                        weatherErr = null;
                    } catch (Exception e) {
                        weatherErr = String.valueOf(e.getMessage());
                        tWeather = System.currentTimeMillis() - 1500000L; // coba lagi sekitar 5 menit
                    } finally {
                        weatherBusy = false;
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        }
    }

    private void pollMusic(BleLink b) {
        Phone.MusicInfo m = Phone.music(this);
        String key = m == null ? "" : (m.title + "|" + m.artist + "|" + m.playing + "|" + m.pkg);
        if (key.equals(lastMusicKey)) return;
        lastMusicKey = key;
        musicText = m == null ? "" : (m.title + (m.artist.isEmpty() ? "" : " - " + m.artist));
        if (m != null) {
            b.send(Proto.musicInfo(m.playing ? 1 : 0, m.app, m.pkg));
            b.send(Proto.musicTitle(m.title));
            b.send(Proto.musicArtist(m.artist));
        } else {
            b.send(Proto.musicInfo(0, "", ""));
            b.send(Proto.musicTitle(""));
            b.send(Proto.musicArtist(""));
        }
    }

    private void pollCall(BleLink b) {
        int st = Phone.callState(this);
        if (st == TelephonyManager.CALL_STATE_RINGING) {
            if (!ringingSent) {
                ringingSent = true;
                boolean fresh = System.currentTimeMillis() - NotifService.lastCallTitleAt < 15000L
                        && !NotifService.lastCallTitle.isEmpty();
                b.send(Proto.ringer(true, fresh ? NotifService.lastCallTitle : "Panggilan masuk"));
            }
        } else if (ringingSent) {
            ringingSent = false;
            b.send(Proto.ringer(false, ""));
        }
    }

    // ===================== peta & navigasi =====================

    private static double distM(double la1, double lo1, double la2, double lo2) {
        double dx = (lo2 - lo1) * 111320.0 * Math.cos(Math.toRadians(la1));
        double dy = (la2 - la1) * 110540.0;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private static double smoothAngle(double old, double nw) {
        double diff = ((nw - old + 540.0) % 360.0) - 180.0;
        return (old + diff * 0.6 + 360.0) % 360.0;
    }

    private static float angleFor(String mod) {
        switch (mod) {
            case "uturn": return 180f;
            case "sharp right": return 135f;
            case "right": return 90f;
            case "slight right": return 45f;
            case "slight left": return -45f;
            case "left": return -90f;
            case "sharp left": return -135f;
            default: return 0f;
        }
    }

    private void requestRoute(final double la, final double lo) {
        if (routing) return;
        routing = true;
        final String dd = destText;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    double[] dp = destPt;
                    if (dp == null) {
                        dp = Geo.geocode(dd, la, lo);
                        destPt = dp;
                    }
                    Route r = Geo.route(la, lo, dp[0], dp[1]);
                    route = r;
                    routeErr = null;
                } catch (Exception e) {
                    routeErr = String.valueOf(e.getMessage());
                    routeFailAt = System.currentTimeMillis();
                } finally {
                    routing = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void loadRoads(final double la, final double lo) {
        if (roadsLoading) return;
        roadsLoading = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    roads = Geo.roads(la, lo);
                    roadsErr = null;
                } catch (Exception e) {
                    roadsErr = String.valueOf(e.getMessage());
                    roadsFailAt = System.currentTimeMillis();
                } finally {
                    roadsLoading = false;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void tick() throws Exception {
        String mip = manualIp;
        if (!bleMode && !mip.isEmpty()) {
            InetAddress cur0 = espAddr;
            if (cur0 == null || !mip.equals(cur0.getHostAddress())) {
                try {
                    espAddr = InetAddress.getByName(mip);
                } catch (Exception ignored) {
                }
            }
        }

        BleLink b = ble;
        boolean bleUp = bleMode && b != null && b.ready;
        final boolean needMap = !(bleMode && turnMode);

        Location l = loc;
        if (l == null) {
            StringBuilder s0 = new StringBuilder("Menunggu sinyal GPS...\n(coba di luar ruangan)");
            if (bleMode && b != null) s0.append("\n").append(b.state);
            status = s0.toString();
            gpsOk = false;
            kmhNow = 0;
            espIp = bleUp ? b.name : null;
            return;
        }
        final double la = l.getLatitude(), lo = l.getLongitude();
        long now = System.currentTimeMillis();

        // ---- data jalan ----
        RoadSet rs = roads;
        if (needMap && !roadsLoading && (rs == null || distM(la, lo, rs.cLat, rs.cLon) > 300.0)
                && now - roadsFailAt > 20000L) {
            loadRoads(la, lo);
        }

        // ---- rute ----
        String dt = destText;
        boolean wantRoute = dt != null && !dt.isEmpty();
        Route rt = route;
        if (wantRoute && rt == null && !routing && now - routeFailAt > 10000L) {
            requestRoute(la, lo);
        }

        double progress = 0;
        int curSeg = 0;
        int flags = 0;
        int arrowKind = 0;
        float arrowAngle = 0f;
        int distNext = 0, eta = 0, remain10 = 0;
        String name = "";
        double remaining = 0;

        if (rt != null) {
            double p = rt.project(la, lo, false);
            if (rt.offDist > 60.0) p = rt.project(la, lo, true);
            if (rt.offDist > 60.0) offCnt++;
            else offCnt = 0;
            if (offCnt >= 4 && !routing && now - lastReroute > 15000L) {
                offCnt = 0;
                lastReroute = now;
                requestRoute(la, lo);
            }
            progress = p;
            curSeg = rt.curSeg;
            remaining = Math.max(0, rt.totalDist - p);

            int next = -1;
            for (int i = 0; i < rt.nSteps; i++) {
                if (rt.stepDist[i] > p + 8.0) {
                    next = i;
                    break;
                }
            }
            if (remaining < 25.0 || next < 0) {
                flags |= 1;
                arrowKind = 2;
                name = "Tujuan";
            } else {
                String type = rt.stepType[next];
                if ("arrive".equals(type)) {
                    arrowKind = 2;
                    name = rt.stepName[next].isEmpty() ? "Tujuan" : rt.stepName[next];
                } else {
                    arrowKind = 1;
                    arrowAngle = angleFor(rt.stepMod[next]);
                    name = rt.stepName[next];
                }
                distNext = (int) Math.max(0, Math.min(65535, rt.stepDist[next] - p));
            }
            eta = (int) Math.min(65535, Math.round(rt.totalDur * (remaining / rt.totalDist) / 60.0));
            remain10 = (int) Math.min(65535, remaining / 10.0);
        } else {
            flags |= 2;
            if (!wantRoute) name = "Mode peta";
            else if (routing) name = "Mencari rute...";
            else if (routeErr != null) name = "Rute gagal";
            else name = "Mencari rute...";
        }

        // ---- arah & skala ----
        double spd = l.hasSpeed() ? l.getSpeed() : 0.0;
        if (spd > 1.5 && l.hasBearing()) {
            heading = headingInit ? smoothAngle(heading, l.getBearing()) : l.getBearing();
            headingInit = true;
        } else if (rt != null) {
            double rb = rt.bearing(curSeg);
            heading = headingInit ? smoothAngle(heading, rb) : rb;
            headingInit = true;
        }
        double kmh = spd * 3.6;
        double scale = kmh < 20 ? 3.0 : (kmh < 45 ? 5.0 : (kmh < 70 ? 7.0 : 10.0));

        // ---- gambar & kirim ----
        byte[] pkt = null;
        if (needMap) {
            byte[] frame = renderer.render(la, lo, heading, scale, roads, rt, curSeg, progress, arrowKind, arrowAngle);
            pkt = new byte[HDR + FRAME];
            pkt[0] = 'M';
            pkt[1] = 'P';
            pkt[2] = (byte) flags;
            pkt[3] = 0;
            pkt[4] = (byte) (distNext & 0xFF);
            pkt[5] = (byte) ((distNext >> 8) & 0xFF);
            pkt[6] = (byte) Math.min(255, (int) Math.round(kmh));
            pkt[8] = (byte) (eta & 0xFF);
            pkt[9] = (byte) ((eta >> 8) & 0xFF);
            pkt[10] = (byte) (remain10 & 0xFF);
            pkt[11] = (byte) ((remain10 >> 8) & 0xFF);
            String nm = Geo.clean(name);
            for (int i = 0; i < nm.length() && i < 23; i++) pkt[12 + i] = (byte) nm.charAt(i);
            System.arraycopy(frame, 0, pkt, HDR, FRAME);
        }

        boolean sent = false;
        boolean espUp;
        InetAddress a = espAddr;
        if (bleMode) {
            espUp = bleUp;
            if (bleUp) {
                if (turnMode) {
                    sendTurn(b, rt, arrowKind, arrowAngle, distNext, eta, remaining, name, kmh, (flags & 1) != 0);
                } else {
                    if (navActiveSent) {
                        b.send(Proto.navOff());
                        navActiveSent = false;
                    }
                    b.sendMap(pkt);
                }
                sent = true;
            }
        } else {
            espUp = a != null && (!manualIp.isEmpty() || System.currentTimeMillis() - lastHello < 8000L);
            if (a != null) {
                try {
                    sock.send(new DatagramPacket(pkt, pkt.length, a, PORT_ESP));
                    sent = true;
                } catch (Exception ignored) {
                }
            }
        }

        if (now - tTrip > 30000L) {
            tTrip = now;
            Trip.save(getSharedPreferences("wsr", MODE_PRIVATE));
        }

        // ---- status untuk layar HP ----
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.US, "GPS OK (%.0f km/jam)\n", kmh));
        if (bleMode) {
            sb.append(b != null ? b.state : "Bluetooth belum aktif").append("\n");
        } else if (!espUp) {
            sb.append("W-Smart Rider: belum terdeteksi\n(sambungkan W-Smart Rider ke hotspot HP)\n");
        } else {
            sb.append("W-Smart Rider (Wi-Fi): ").append(a.getHostAddress())
                    .append(sent ? " (terkirim)\n" : " (gagal kirim)\n");
        }
        if (rt != null) {
            sb.append(String.format(Locale.US, "Rute: sisa %.1f km, %d menit\n", remaining / 1000.0, eta));
        } else if (wantRoute) {
            sb.append(routing ? "Rute: mencari...\n" : "Rute: " + routeErr + "\n");
        } else {
            sb.append("Mode peta saja (tanpa tujuan)\n");
        }
        RoadSet cur = roads;
        if (cur != null) sb.append("Peta: ").append(cur.major.size() + cur.minor.size()).append(" jalan\n");
        else sb.append(roadsLoading ? "Peta: mengunduh...\n" : "Peta: " + roadsErr + "\n");
        if (bleMode && weatherErr != null) sb.append("Cuaca: ").append(weatherErr).append("\n");
        status = sb.toString();

        gpsOk = true;
        kmhNow = (int) Math.round(kmh);
        if (bleMode) espIp = bleUp ? b.name : null;
        else espIp = espUp ? a.getHostAddress() : null;
        remainTxt = rt != null ? String.format(Locale.US, "%.1f km", remaining / 1000.0) : "-";
        etaTxt = rt != null ? (eta + " mnt") : "-";
        roadsTxt = cur != null ? ((cur.major.size() + cur.minor.size()) + " jalan")
                : (roadsLoading ? "mengunduh..." : "-");
    }

    // ===================== belokan demi belokan (gaya Chronos) =====================

    private static String fmtDist(int m) {
        if (m < 1000) return m + " m";
        return String.format(Locale.US, "%.1f km", m / 1000.0);
    }

    private byte[] arrowIcon(int kind, float angle) {
        int key = kind * 1000 + (int) angle;
        if (key != arrowKey || arrowCache == null) {
            arrowCache = NavIcon.arrow((int) angle, kind == 2);
            arrowKey = key;
        }
        return arrowCache;
    }

    private byte[] arrowFromText(String text) {
        String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
        int ang = 0;
        if (t.contains("putar balik") || t.contains("u-turn") || t.contains("u turn")) ang = 180;
        else if (t.contains("kanan") || t.contains("right")) {
            ang = (t.contains("tajam") || t.contains("sharp")) ? 135
                    : ((t.contains("sedikit") || t.contains("slight")) ? 45 : 90);
        } else if (t.contains("kiri") || t.contains("left")) {
            ang = (t.contains("tajam") || t.contains("sharp")) ? -135
                    : ((t.contains("sedikit") || t.contains("slight")) ? -45 : -90);
        }
        return NavIcon.arrow(ang, false);
    }

    /** Kirim data navigasi format Chronos agar layar navigasi bawaan sketch tampil. */
    private void sendTurn(BleLink b, Route rt, int arrowKind, float arrowAngle, int distNext, int eta,
                          double remaining, String name, double kmh, boolean arrived) {
        long now = System.currentTimeMillis();
        if (now - tNav < 1000L) return;
        tNav = now;

        String dist, dur, total, etaClock, street;
        byte[] icon;
        if (rt != null) {
            dist = arrived ? "0 m" : fmtDist(distNext);
            dur = eta + " mnt";
            total = fmtDist((int) remaining);
            Calendar c = Calendar.getInstance();
            c.add(Calendar.MINUTE, eta);
            etaClock = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
            street = name;
            icon = arrowIcon(arrowKind, arrowAngle);
        } else {
            NotifService.GNav g = NotifService.gnav;
            if (g != null && now - g.at < 30000L) {
                dist = g.dist;
                dur = g.duration;
                total = g.total;
                etaClock = g.eta;
                street = g.directions;
                icon = g.icon != null ? g.icon : arrowFromText(g.directions + " " + g.dist);
            } else {
                if (navActiveSent) {
                    b.send(Proto.navOff());
                    navActiveSent = false;
                }
                return;
            }
        }
        int crc = NavIcon.crc(icon);
        if (crc != lastIconCrc || !navActiveSent) {
            for (byte[] p : Proto.navIcon(icon, crc)) b.send(p);
            lastIconCrc = crc;
        }
        b.send(Proto.navData(true, crc, dist, dur, total, etaClock, street, Math.round((float) kmh) + " km/h"));
        navActiveSent = true;
    }

    @Override
    public void onDestroy() {
        Trip.save(getSharedPreferences("wsr", MODE_PRIVATE));
        running = false;
        NotifService.sink = null;
        try {
            if (ble != null) ble.stop();
        } catch (Exception ignored) {
        }
        ble = null;
        try {
            if (lm != null && listener != null) lm.removeUpdates(listener);
        } catch (Exception ignored) {
        }
        try {
            if (sock != null) sock.close();
        } catch (Exception ignored) {
        }
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) {
        }
        status = "Berhenti";
        active = false;
        gpsOk = false;
        kmhNow = 0;
        espIp = null;
        remainTxt = "-";
        etaTxt = "-";
        roadsTxt = "-";
        super.onDestroy();
    }
}
